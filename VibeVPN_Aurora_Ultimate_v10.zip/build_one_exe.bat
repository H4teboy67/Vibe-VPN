@echo off
setlocal
cd /d "%~dp0"
py -m pip install --upgrade pyinstaller pillow
if errorlevel 1 (
  echo Failed to install PyInstaller/Pillow. Check Python and internet access.
  pause
  exit /b 1
)
py -m PyInstaller --noconfirm --clean --onefile --windowed --name "VibeVPN" --icon "icons\vibe_classic.ico" --add-binary "EULA.exe;." --add-data "icons;icons" launcher_unified.py
if errorlevel 1 (
  echo Build failed. See the error above.
  pause
  exit /b 1
)
echo.
echo Done. Output: dist\VibeVPN.exe
echo The globe uses Pillow raster rendering for smoother resize and rotation.
pause
