from PIL import Image, ImageDraw, ImageFont, ImageFilter
from pathlib import Path
out=Path(__file__).parent/'icons'; out.mkdir(exist_ok=True)
styles={
 'vibe_classic':('#102536','#83b9e8','V','classic'),
 'vibi_fox':('#102536','#9dd1fa','V','fox'),
 'halloween':('#25152c','#ff974d','☾','halloween'),
 'winter_glow':('#102a42','#b9e9ff','✦','winter'),
 'holographic':('#271f4a','#e2b8ff','◇','holo'),
 'cyber_neon':('#071c1b','#00ffcc','V','cyber'),
 'spring_bloom':('#153328','#ff9fcf','✿','spring'),
 'lunar_eclipse':('#151827','#b6b8ff','☾','lunar'),
 'solar_flare':('#2e1d17','#ffcc66','☼','solar'),
 'aurora':('#10252d','#72f1cd','✧','aurora'),
}
def font(size, bold=True):
    candidates=['/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf']
    for p in candidates:
        try:return ImageFont.truetype(p,size)
        except:pass
    return ImageFont.load_default()
for name,(bg,accent,glyph,kind) in styles.items():
    S=512; im=Image.new('RGBA',(S,S),(0,0,0,0)); p=im.load()
    # square tile with dark colored radial gradient
    cx=cy=S/2
    br,bg2,bb=int(bg[1:3],16),int(bg[3:5],16),int(bg[5:7],16)
    ar,ag,ab=int(accent[1:3],16),int(accent[3:5],16),int(accent[5:7],16)
    for y in range(S):
        for x in range(S):
            # rounded-square mask is drawn later; gradient makes the icon feel layered
            d=min(1,((x-cx)**2+(y-cy)**2)**.5/(S*.75))
            glow=max(0,1-(((x-S*.30)**2+(y-S*.22)**2)**.5)/(S*.72))*.22
            p[x,y]=(int(br*(1-d)+ar*d*.20+ar*glow),int(bg2*(1-d)+ag*d*.20+ag*glow),int(bb*(1-d)+ab*d*.20+ab*glow),255)
    draw=ImageDraw.Draw(im)
    # rounded square, ring and inner disc
    mask=Image.new('L',(S,S),0); md=ImageDraw.Draw(mask); md.rounded_rectangle((12,12,S-12,S-12),radius=112,fill=255)
    im.putalpha(mask); draw=ImageDraw.Draw(im)
    draw.rounded_rectangle((24,24,S-24,S-24),radius=100,outline=accent,width=12)
    draw.ellipse((88,88,S-88,S-88),fill=(ar,ag,ab,32),outline=(ar,ag,ab,180),width=8)
    # thematic details
    if kind=='halloween':
        draw.ellipse((145,190,205,250),fill=accent); draw.ellipse((307,190,367,250),fill=accent)
        draw.arc((175,250,340,350),0,180,fill=accent,width=14)
        draw.polygon([(256,70),(282,128),(345,132),(297,174),(310,234),(256,202),(202,234),(215,174),(167,132),(230,128)], fill=(255,170,85,230))
    elif kind=='winter':
        for ang in range(0,180,60):
            import math
            a=math.radians(ang); x1=256+152*math.cos(a);y1=256+152*math.sin(a);x2=256-152*math.cos(a);y2=256-152*math.sin(a)
            draw.line((x1,y1,x2,y2),fill=accent,width=12)
            for k in (-1,1):
                for endx,endy,sgn in ((x1,y1,-1),(x2,y2,1)):
                    baseang=a+(math.pi if sgn==1 else 0)+k*.55
                    draw.line((endx,endy,endx+38*math.cos(baseang),endy+38*math.sin(baseang)),fill=accent,width=9)
    elif kind=='holo':
        draw.arc((60,70,450,450),20,310,fill='#ff9ad5',width=14); draw.arc((85,95,420,420),200,500,fill='#6df6ef',width=12)
    elif kind=='cyber':
        draw.line((120,360,200,280,256,330,370,180),fill=accent,width=20,joint='curve')
        draw.ellipse((350,145,395,190),fill='#ffffff')
    elif kind=='spring':
        import math
        for angle in range(0,360,72):
            a=math.radians(angle); x=256+65*math.cos(a);y=256+65*math.sin(a)
            draw.ellipse((x-38,y-38,x+38,y+38),fill=accent)
        draw.ellipse((230,230,282,282),fill='#ffe7a6')
    elif kind=='lunar':
        draw.ellipse((140,118,372,350),fill=accent)
        draw.ellipse((205,80,410,310),fill=bg)
        draw.ellipse((302,330,326,354),fill='#ffffff')
    elif kind=='solar':
        import math
        draw.ellipse((176,176,336,336),fill=accent)
        for a in range(0,360,30):
            r1,r2=95,145;rad=math.radians(a)
            draw.line((256+r1*math.cos(rad),256+r1*math.sin(rad),256+r2*math.cos(rad),256+r2*math.sin(rad)),fill=accent,width=12)
    elif kind=='aurora':
        draw.arc((70,70,440,430),190,350,fill='#72f1cd',width=22)
        draw.arc((60,130,450,470),190,350,fill='#6da9ff',width=16)
    elif kind=='fox':
        draw.polygon([(135,180),(165,95),(225,164),(287,164),(347,95),(377,180),(360,300),(256,385),(152,300)],fill='#dbe9f4',outline=accent)
        draw.ellipse((192,224,220,252),fill='#152232');draw.ellipse((292,224,320,252),fill='#152232')
        draw.polygon([(242,270),(270,270),(256,288)],fill='#5f8eb4')
    # central glyph where it makes sense
    if kind in ('classic','halloween','winter','holo','cyber','spring','lunar','solar','aurora'):
        try:
            f=font(188)
            bbox=draw.textbbox((0,0),glyph,font=f,stroke_width=0)
            tw,th=bbox[2]-bbox[0],bbox[3]-bbox[1]
            draw.text((256-tw/2,245-th/2-bbox[1]),glyph,font=f,fill=accent,stroke_width=3,stroke_fill=bg)
        except: pass
    # export multi-resolution ICO
    im.save(out/(name+'.ico'),format='ICO',sizes=[(16,16),(24,24),(32,32),(48,48),(64,64),(128,128),(256,256)])
print('created',len(styles),'ico files')
