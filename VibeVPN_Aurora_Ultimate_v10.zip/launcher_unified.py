"""
Single-exe launcher:
1) runs the existing, unchanged EULA.exe from PyInstaller's temporary bundle;
2) waits for EULA.exe to close;
3) starts the VPN GUI in this same application process.
The EULA binary itself is not modified.
"""
import os, sys, subprocess, tempfile
from pathlib import Path

def bundled_path(name):
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, name)

def main():
    eula = bundled_path("EULA.exe")
    if not os.path.isfile(eula):
        import tkinter as tk
        from tkinter import messagebox
        root=tk.Tk();root.withdraw()
        messagebox.showerror("Vibe VPN", "Не удалось найти встроенный EULA.exe.")
        root.destroy()
        return
    # Run EULA on every app launch, without editing its binary.
    result = subprocess.run([eula], check=False)
    # Existing behavior was "wait then launch app"; preserve that ordering.
    # If EULA uses a non-zero code for an accepted/closed dialog, do not block
    # launch on its exit code; the original launcher also ignored it.
    from App import HorizonVPN
    HorizonVPN().mainloop()

if __name__ == "__main__":
    main()
