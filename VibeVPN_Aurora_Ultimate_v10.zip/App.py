"""
Vibe VPN — premium desktop UI
Python 3.10+ / Tkinter only.

The interface is inspired by the supplied reference: dark graphite panels,
soft blue-grey accents, a dotted world map, location list, connection panel,
animated connect pulse, animated map routes, and hover states.

IMPORTANT: This is a GUI prototype. Connect/disconnect currently changes the
visual demo state only. It does not create a VPN tunnel, block traffic, or
measure real ping/traffic. Integrate your VPN backend before presenting it as
a functioning VPN.
"""
import math
import random
import json
import os
import re
import sys
import time
import webbrowser
import tkinter as tk
import tkinter.font as tkfont
from pathlib import Path
from tkinter import ttk, messagebox, filedialog, simpledialog

# Pillow rasterizes the globe into one bitmap instead of creating thousands of Tk Canvas items.
# A Canvas fallback remains available if Pillow is missing, but the provided build script installs it.
try:
    from PIL import Image, ImageDraw, ImageTk
    PIL_AVAILABLE = True
except ImportError:
    Image = ImageDraw = ImageTk = None
    PIL_AVAILABLE = False

# --------------------------- Theme -----------------------------------------
BG = "#11151b"
BG2 = "#171c24"
SIDEBAR = "#10141a"
PANEL = "#1a2029"
PANEL2 = "#202833"
PANEL_HOVER = "#283341"
BORDER = "#2b3542"
TEXT = "#edf2f8"
MUTED = "#8c9aaa"
DIM = "#657384"
BLUE = "#83b9e8"
BLUE_BRIGHT = "#9dd1fa"
BLUE_DARK = "#263e52"
CYAN = "#6ed7d4"
GREEN = "#76d6bd"
ORANGE = "#e6c58b"
RED = "#e78e9a"

GEO_CITY_DATA = [
    # Country, city, code, flag, latitude, longitude, region. The first eight preserve the existing demo ordering.
    ("Netherlands","Amsterdam","NL-AMS","🇳🇱",52.37,4.90,"Europe"),
    ("Singapore","Singapore","SG-SIN","🇸🇬",1.35,103.82,"Asia Pacific"),
    ("Germany","Frankfurt","DE-FRA","🇩🇪",50.11,8.68,"Europe"),
    ("France","Paris","FR-PAR","🇫🇷",48.86,2.35,"Europe"),
    ("Sweden","Stockholm","SE-STO","🇸🇪",59.33,18.07,"Europe"),
    ("United States","New York","US-NYC","🇺🇸",40.71,-74.01,"Americas"),
    ("Finland","Helsinki","FI-HEL","🇫🇮",60.17,24.94,"Europe"),
    ("Japan","Tokyo","JP-TYO","🇯🇵",35.68,139.69,"Asia Pacific"),
    ("United Kingdom","London","GB-LON","🇬🇧",51.51,-0.13,"Europe"),
    ("Ireland","Dublin","IE-DUB","🇮🇪",53.35,-6.26,"Europe"),
    ("United Kingdom","Manchester","GB-MAN","🇬🇧",53.48,-2.24,"Europe"),
    ("United Kingdom","Edinburgh","GB-EDI","🇬🇧",55.95,-3.19,"Europe"),
    ("Belgium","Brussels","BE-BRU","🇧🇪",50.85,4.35,"Europe"),
    ("Luxembourg","Luxembourg City","LU-LUX","🇱🇺",49.61,6.13,"Europe"),
    ("Switzerland","Zurich","CH-ZRH","🇨🇭",47.38,8.54,"Europe"),
    ("Switzerland","Geneva","CH-GVA","🇨🇭",46.20,6.14,"Europe"),
    ("Austria","Vienna","AT-VIE","🇦🇹",48.21,16.37,"Europe"),
    ("Czechia","Prague","CZ-PRG","🇨🇿",50.08,14.44,"Europe"),
    ("Poland","Warsaw","PL-WAW","🇵🇱",52.23,21.01,"Europe"),
    ("Poland","Krakow","PL-KRK","🇵🇱",50.06,19.94,"Europe"),
    ("Hungary","Budapest","HU-BUD","🇭🇺",47.50,19.04,"Europe"),
    ("Romania","Bucharest","RO-BUH","🇷🇴",44.43,26.10,"Europe"),
    ("Bulgaria","Sofia","BG-SOF","🇧🇬",42.70,23.32,"Europe"),
    ("Greece","Athens","GR-ATH","🇬🇷",37.98,23.73,"Europe"),
    ("Türkiye","Istanbul","TR-IST","🇹🇷",41.01,28.98,"Europe"),
    ("Norway","Oslo","NO-OSL","🇳🇴",59.91,10.75,"Europe"),
    ("Denmark","Copenhagen","DK-CPH","🇩🇰",55.68,12.57,"Europe"),
    ("Iceland","Reykjavik","IS-REK","🇮🇸",64.15,-21.94,"Europe"),
    ("Estonia","Tallinn","EE-TLL","🇪🇪",59.44,24.75,"Europe"),
    ("Latvia","Riga","LV-RIX","🇱🇻",56.95,24.11,"Europe"),
    ("Lithuania","Vilnius","LT-VNO","🇱🇹",54.69,25.28,"Europe"),
    ("Ukraine","Kyiv","UA-KBP","🇺🇦",50.45,30.52,"Europe"),
    ("Portugal","Lisbon","PT-LIS","🇵🇹",38.72,-9.14,"Europe"),
    ("Spain","Madrid","ES-MAD","🇪🇸",40.42,-3.70,"Europe"),
    ("Spain","Barcelona","ES-BCN","🇪🇸",41.39,2.17,"Europe"),
    ("Spain","Valencia","ES-VLC","🇪🇸",39.47,-0.38,"Europe"),
    ("Italy","Milan","IT-MIL","🇮🇹",45.46,9.19,"Europe"),
    ("Italy","Rome","IT-ROM","🇮🇹",41.90,12.50,"Europe"),
    ("Italy","Naples","IT-NAP","🇮🇹",40.85,14.27,"Europe"),
    ("Italy","Turin","IT-TRN","🇮🇹",45.07,7.69,"Europe"),
    ("Germany","Munich","DE-MUC","🇩🇪",48.14,11.58,"Europe"),
    ("Germany","Hamburg","DE-HAM","🇩🇪",53.55,9.99,"Europe"),
    ("Germany","Berlin","DE-BER","🇩🇪",52.52,13.41,"Europe"),
    ("Germany","Dusseldorf","DE-DUS","🇩🇪",51.23,6.78,"Europe"),
    ("Germany","Stuttgart","DE-STR","🇩🇪",48.78,9.18,"Europe"),
    ("Germany","Cologne","DE-CGN","🇩🇪",50.94,6.96,"Europe"),
    ("Switzerland","Basel","CH-BSL","🇨🇭",47.56,7.59,"Europe"),
    ("Serbia","Belgrade","RS-BEG","🇷🇸",44.79,20.45,"Europe"),
    ("Croatia","Zagreb","HR-ZAG","🇭🇷",45.81,15.98,"Europe"),
    ("Slovenia","Ljubljana","SI-LJU","🇸🇮",46.06,14.51,"Europe"),
    ("Bosnia and Herzegovina","Sarajevo","BA-SJJ","🇧🇦",43.86,18.41,"Europe"),
    ("Albania","Tirana","AL-TIA","🇦🇱",41.33,19.82,"Europe"),
    ("North Macedonia","Skopje","MK-SKP","🇲🇰",41.998,21.425,"Europe"),
    ("Montenegro","Podgorica","ME-TGD","🇲🇪",42.43,19.26,"Europe"),
    ("Moldova","Chisinau","MD-KIV","🇲🇩",47.01,28.86,"Europe"),
    ("Portugal","Porto","PT-OPO","🇵🇹",41.16,-8.63,"Europe"),
    ("Spain","Malaga","ES-AGP","🇪🇸",36.72,-4.42,"Europe"),
    ("Spain","Bilbao","ES-BIO","🇪🇸",43.26,-2.93,"Europe"),
    ("France","Bordeaux","FR-BOD","🇫🇷",44.84,-0.58,"Europe"),
    ("France","Lyon","FR-LYS","🇫🇷",45.76,4.84,"Europe"),
    ("France","Marseille","FR-MRS","🇫🇷",43.30,5.37,"Europe"),
    ("France","Nice","FR-NCE","🇫🇷",43.71,7.26,"Europe"),
    ("Netherlands","Rotterdam","NL-RTM","🇳🇱",51.92,4.48,"Europe"),
    ("Netherlands","The Hague","NL-HAG","🇳🇱",52.08,4.31,"Europe"),
    ("Netherlands","Eindhoven","NL-EIN","🇳🇱",51.44,5.48,"Europe"),
    ("Belgium","Antwerp","BE-ANR","🇧🇪",51.22,4.40,"Europe"),
    ("Sweden","Gothenburg","SE-GOT","🇸🇪",57.71,11.97,"Europe"),
    ("Norway","Bergen","NO-BGO","🇳🇴",60.39,5.32,"Europe"),
    ("Denmark","Aarhus","DK-AAR","🇩🇰",56.16,10.20,"Europe"),
    ("Poland","Gdansk","PL-GDN","🇵🇱",54.35,18.65,"Europe"),
    ("Poland","Lodz","PL-LDZ","🇵🇱",51.76,19.46,"Europe"),
    ("Poland","Wroclaw","PL-WRO","🇵🇱",51.11,17.04,"Europe"),
    ("Romania","Cluj-Napoca","RO-CLJ","🇷🇴",46.77,23.59,"Europe"),
    ("Romania","Timisoara","RO-TSR","🇷🇴",45.75,21.23,"Europe"),
    ("Canada","Toronto","CA-YYZ","🇨🇦",43.65,-79.38,"Americas"),
    ("Canada","Vancouver","CA-YVR","🇨🇦",49.28,-123.12,"Americas"),
    ("Canada","Montreal","CA-YUL","🇨🇦",45.50,-73.57,"Americas"),
    ("Canada","Ottawa","CA-YOW","🇨🇦",45.42,-75.70,"Americas"),
    ("Canada","Calgary","CA-YYC","🇨🇦",51.05,-114.07,"Americas"),
    ("United States","Los Angeles","US-LAX","🇺🇸",34.05,-118.24,"Americas"),
    ("United States","San Francisco","US-SFO","🇺🇸",37.77,-122.42,"Americas"),
    ("United States","Chicago","US-CHI","🇺🇸",41.88,-87.63,"Americas"),
    ("United States","Dallas","US-DFW","🇺🇸",32.78,-96.80,"Americas"),
    ("United States","Seattle","US-SEA","🇺🇸",47.61,-122.33,"Americas"),
    ("United States","Miami","US-MIA","🇺🇸",25.76,-80.19,"Americas"),
    ("United States","Atlanta","US-ATL","🇺🇸",33.75,-84.39,"Americas"),
    ("United States","Denver","US-DEN","🇺🇸",39.74,-104.99,"Americas"),
    ("United States","Boston","US-BOS","🇺🇸",42.36,-71.06,"Americas"),
    ("United States","Washington DC","US-IAD","🇺🇸",38.91,-77.04,"Americas"),
    ("Mexico","Mexico City","MX-MEX","🇲🇽",19.43,-99.13,"Americas"),
    ("Mexico","Guadalajara","MX-GDL","🇲🇽",20.67,-103.35,"Americas"),
    ("Mexico","Monterrey","MX-MTY","🇲🇽",25.69,-100.32,"Americas"),
    ("Guatemala","Guatemala City","GT-GUA","🇬🇹",14.63,-90.51,"Americas"),
    ("Costa Rica","San Jose","CR-SJO","🇨🇷",9.93,-84.08,"Americas"),
    ("Panama","Panama City","PA-PTY","🇵🇦",8.98,-79.52,"Americas"),
    ("Cuba","Havana","CU-HAV","🇨🇺",23.11,-82.37,"Americas"),
    ("Dominican Republic","Santo Domingo","DO-SDQ","🇩🇴",18.49,-69.93,"Americas"),
    ("Jamaica","Kingston","JM-KIN","🇯🇲",17.97,-76.79,"Americas"),
    ("Trinidad and Tobago","Port of Spain","TT-POS","🇹🇹",10.67,-61.52,"Americas"),
    ("Colombia","Bogota","CO-BOG","🇨🇴",4.71,-74.07,"Americas"),
    ("Colombia","Medellin","CO-MDE","🇨🇴",6.25,-75.56,"Americas"),
    ("Venezuela","Caracas","VE-CCS","🇻🇪",10.48,-66.90,"Americas"),
    ("Ecuador","Quito","EC-UIO","🇪🇨",-0.18,-78.47,"Americas"),
    ("Ecuador","Guayaquil","EC-GYE","🇪🇨",-2.17,-79.92,"Americas"),
    ("Peru","Lima","PE-LIM","🇵🇪",-12.05,-77.04,"Americas"),
    ("Chile","Santiago","CL-SCL","🇨🇱",-33.45,-70.67,"Americas"),
    ("Argentina","Buenos Aires","AR-BUE","🇦🇷",-34.60,-58.38,"Americas"),
    ("Argentina","Cordoba","AR-COR","🇦🇷",-31.42,-64.18,"Americas"),
    ("Uruguay","Montevideo","UY-MVD","🇺🇾",-34.90,-56.16,"Americas"),
    ("Paraguay","Asuncion","PY-ASU","🇵🇾",-25.26,-57.58,"Americas"),
    ("Bolivia","La Paz","BO-LPB","🇧🇴",-16.49,-68.12,"Americas"),
    ("Brazil","Sao Paulo","BR-SAO","🇧🇷",-23.55,-46.63,"Americas"),
    ("Brazil","Rio de Janeiro","BR-RIO","🇧🇷",-22.91,-43.17,"Americas"),
    ("Brazil","Brasilia","BR-BSB","🇧🇷",-15.79,-47.88,"Americas"),
    ("Brazil","Recife","BR-REC","🇧🇷",-8.05,-34.88,"Americas"),
    ("Brazil","Porto Alegre","BR-POA","🇧🇷",-30.03,-51.23,"Americas"),
    ("South Korea","Seoul","KR-SEL","🇰🇷",37.57,126.98,"Asia Pacific"),
    ("South Korea","Busan","KR-PUS","🇰🇷",35.18,129.08,"Asia Pacific"),
    ("Japan","Osaka","JP-OSA","🇯🇵",34.69,135.50,"Asia Pacific"),
    ("Japan","Nagoya","JP-NGO","🇯🇵",35.18,136.91,"Asia Pacific"),
    ("Japan","Sapporo","JP-SPK","🇯🇵",43.06,141.35,"Asia Pacific"),
    ("Taiwan","Taipei","TW-TPE","🇹🇼",25.03,121.57,"Asia Pacific"),
    ("Hong Kong","Hong Kong","HK-HKG","🇭🇰",22.32,114.17,"Asia Pacific"),
    ("China","Beijing","CN-PEK","🇨🇳",39.90,116.40,"Asia Pacific"),
    ("China","Shanghai","CN-PVG","🇨🇳",31.23,121.47,"Asia Pacific"),
    ("China","Shenzhen","CN-SZX","🇨🇳",22.54,114.06,"Asia Pacific"),
    ("China","Guangzhou","CN-CAN","🇨🇳",23.13,113.26,"Asia Pacific"),
    ("China","Chengdu","CN-CTU","🇨🇳",30.57,104.07,"Asia Pacific"),
    ("Thailand","Bangkok","TH-BKK","🇹🇭",13.76,100.50,"Asia Pacific"),
    ("Malaysia","Kuala Lumpur","MY-KUL","🇲🇾",3.14,101.69,"Asia Pacific"),
    ("Indonesia","Jakarta","ID-CGK","🇮🇩",-6.21,106.85,"Asia Pacific"),
    ("Philippines","Manila","PH-MNL","🇵🇭",14.60,120.98,"Asia Pacific"),
    ("Vietnam","Hanoi","VN-HAN","🇻🇳",21.03,105.85,"Asia Pacific"),
    ("Vietnam","Ho Chi Minh City","VN-SGN","🇻🇳",10.82,106.63,"Asia Pacific"),
    ("Cambodia","Phnom Penh","KH-PNH","🇰🇭",11.56,104.93,"Asia Pacific"),
    ("Laos","Vientiane","LA-VTE","🇱🇦",17.98,102.63,"Asia Pacific"),
    ("Myanmar","Yangon","MM-RGN","🇲🇲",16.87,96.20,"Asia Pacific"),
    ("Bangladesh","Dhaka","BD-DAC","🇧🇩",23.81,90.41,"Asia Pacific"),
    ("Nepal","Kathmandu","NP-KTM","🇳🇵",27.72,85.32,"Asia Pacific"),
    ("Sri Lanka","Colombo","LK-CMB","🇱🇰",6.93,79.85,"Asia Pacific"),
    ("Pakistan","Karachi","PK-KHI","🇵🇰",24.86,67.01,"Asia Pacific"),
    ("Pakistan","Lahore","PK-LHE","🇵🇰",31.52,74.36,"Asia Pacific"),
    ("Pakistan","Islamabad","PK-ISB","🇵🇰",33.69,73.06,"Asia Pacific"),
    ("India","Mumbai","IN-BOM","🇮🇳",19.08,72.88,"Asia Pacific"),
    ("India","New Delhi","IN-DEL","🇮🇳",28.61,77.21,"Asia Pacific"),
    ("India","Bengaluru","IN-BLR","🇮🇳",12.97,77.59,"Asia Pacific"),
    ("India","Chennai","IN-MAA","🇮🇳",13.08,80.27,"Asia Pacific"),
    ("India","Hyderabad","IN-HYD","🇮🇳",17.39,78.49,"Asia Pacific"),
    ("United Arab Emirates","Dubai","AE-DXB","🇦🇪",25.20,55.27,"Middle East"),
    ("United Arab Emirates","Abu Dhabi","AE-AUH","🇦🇪",24.45,54.65,"Middle East"),
    ("Qatar","Doha","QA-DOH","🇶🇦",25.29,51.53,"Middle East"),
    ("Saudi Arabia","Riyadh","SA-RUH","🇸🇦",24.71,46.67,"Middle East"),
    ("Saudi Arabia","Jeddah","SA-JED","🇸🇦",21.49,39.19,"Middle East"),
    ("Oman","Muscat","OM-MCT","🇴🇲",23.59,58.41,"Middle East"),
    ("Kuwait","Kuwait City","KW-KWI","🇰🇼",29.38,47.99,"Middle East"),
    ("Israel","Tel Aviv","IL-TLV","🇮🇱",32.09,34.78,"Middle East"),
    ("Jordan","Amman","JO-AMM","🇯🇴",31.95,35.93,"Middle East"),
    ("Lebanon","Beirut","LB-BEY","🇱🇧",33.89,35.50,"Middle East"),
    ("Georgia","Tbilisi","GE-TBS","🇬🇪",41.72,44.79,"Middle East"),
    ("Armenia","Yerevan","AM-EVN","🇦🇲",40.18,44.51,"Middle East"),
    ("Azerbaijan","Baku","AZ-BAK","🇦🇿",40.41,49.87,"Middle East"),
    ("Kazakhstan","Almaty","KZ-ALA","🇰🇿",43.24,76.95,"Middle East"),
    ("Uzbekistan","Tashkent","UZ-TAS","🇺🇿",41.30,69.24,"Middle East"),
    ("Kyrgyzstan","Bishkek","KG-FRU","🇰🇬",42.87,74.59,"Middle East"),
    ("Mongolia","Ulaanbaatar","MN-ULN","🇲🇳",47.92,106.92,"Asia Pacific"),
    ("Egypt","Cairo","EG-CAI","🇪🇬",30.04,31.24,"Africa"),
    ("Morocco","Casablanca","MA-CAS","🇲🇦",33.57,-7.59,"Africa"),
    ("Morocco","Rabat","MA-RBA","🇲🇦",34.02,-6.84,"Africa"),
    ("Tunisia","Tunis","TN-TUN","🇹🇳",36.81,10.18,"Africa"),
    ("Algeria","Algiers","DZ-ALG","🇩🇿",36.75,3.06,"Africa"),
    ("Nigeria","Lagos","NG-LOS","🇳🇬",6.52,3.38,"Africa"),
    ("Ghana","Accra","GH-ACC","🇬🇭",5.60,-0.19,"Africa"),
    ("Ivory Coast","Abidjan","CI-ABJ","🇨🇮",5.36,-4.01,"Africa"),
    ("Senegal","Dakar","SN-DKR","🇸🇳",14.72,-17.47,"Africa"),
    ("Kenya","Nairobi","KE-NBO","🇰🇪",-1.29,36.82,"Africa"),
    ("Ethiopia","Addis Ababa","ET-ADD","🇪🇹",8.98,38.76,"Africa"),
    ("Uganda","Kampala","UG-KLA","🇺🇬",0.35,32.58,"Africa"),
    ("Rwanda","Kigali","RW-KGL","🇷🇼",-1.94,30.06,"Africa"),
    ("Tanzania","Dar es Salaam","TZ-DAR","🇹🇿",-6.79,39.21,"Africa"),
    ("South Africa","Johannesburg","ZA-JNB","🇿🇦",-26.20,28.04,"Africa"),
    ("South Africa","Cape Town","ZA-CPT","🇿🇦",-33.92,18.42,"Africa"),
    ("South Africa","Durban","ZA-DUR","🇿🇦",-29.86,31.02,"Africa"),
    ("Zambia","Lusaka","ZM-LUN","🇿🇲",-15.39,28.32,"Africa"),
    ("Zimbabwe","Harare","ZW-HRE","🇿🇼",-17.83,31.05,"Africa"),
    ("Mozambique","Maputo","MZ-MPM","🇲🇿",-25.97,32.58,"Africa"),
    ("Angola","Luanda","AO-LAD","🇦🇴",-8.84,13.23,"Africa"),
    ("Australia","Sydney","AU-SYD","🇦🇺",-33.87,151.21,"Oceania"),
    ("Australia","Melbourne","AU-MEL","🇦🇺",-37.81,144.96,"Oceania"),
    ("Australia","Brisbane","AU-BNE","🇦🇺",-27.47,153.03,"Oceania"),
    ("Australia","Perth","AU-PER","🇦🇺",-31.95,115.86,"Oceania"),
    ("Australia","Adelaide","AU-ADL","🇦🇺",-34.93,138.60,"Oceania"),
    ("New Zealand","Auckland","NZ-AKL","🇳🇿",-36.85,174.76,"Oceania"),
    ("New Zealand","Wellington","NZ-WLG","🇳🇿",-41.29,174.78,"Oceania"),
    ("New Zealand","Christchurch","NZ-CHC","🇳🇿",-43.53,172.64,"Oceania"),
    ("Fiji","Suva","FJ-SUV","🇫🇯",-18.14,178.44,"Oceania"),
    ("Papua New Guinea","Port Moresby","PG-POM","🇵🇬",-9.44,147.18,"Oceania"),
]

# These are selectable preview locations, not claims that VPN servers are already deployed there.
SERVERS = []
for _idx, (_country, _city, _code, _flag, _lat, _lon, _region) in enumerate(GEO_CITY_DATA):
    _demo_ping = 16 + int((abs(_lat) * 1.31 + abs(_lon) * 0.27 + _idx * 7) % 112)
    SERVERS.append({
        "country": _country, "city": _city, "code": _code, "flag": _flag,
        "lat": _lat, "lon": _lon, "region": _region,
        "ping": f"{_demo_ping} ms", "ping_is_demo": True,
    })


# Coarse, hand-authored continent silhouettes used to draw a dotted map.
# Coordinates are normalized to the map canvas.
LAND_SHAPES = [
    [(0.08,.20),(.16,.12),(.25,.13),(.31,.20),(.28,.28),(.23,.31),(.22,.40),(.16,.42),(.13,.34),(.08,.30)],
    [(.24,.42),(.30,.43),(.34,.52),(.32,.63),(.28,.77),(.24,.70),(.22,.57)],
    [(.43,.19),(.50,.15),(.58,.18),(.63,.24),(.60,.31),(.53,.33),(.50,.42),(.45,.36),(.42,.28)],
    [(.47,.40),(.55,.39),(.59,.48),(.56,.63),(.51,.75),(.47,.65),(.44,.52)],
    [(.60,.22),(.70,.17),(.81,.20),(.91,.27),(.88,.37),(.79,.39),(.73,.33),(.67,.34),(.63,.29)],
    [(.78,.54),(.87,.53),(.91,.61),(.86,.70),(.79,.67)],
    [(.88,.76),(.91,.74),(.94,.79),(.91,.83)],
]

def point_in_poly(x, y, poly):
    inside = False
    j = len(poly) - 1
    for i in range(len(poly)):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if ((yi > y) != (yj > y)) and (x < (xj - xi) * (y - yi) / ((yj - yi) or 1e-9) + xi):
            inside = not inside
        j = i
    return inside


# Precompute the map's normalized land dots once. Redrawing/resizing only scales
# these coordinates, avoiding expensive polygon calculations during window drag.
MAP_DOT_POINTS = []
_map_y = 0.105
_map_row = 0
while _map_y <= 0.855:
    _map_x = 0.045 + (0.0045 if _map_row % 2 else 0.0)
    while _map_x <= 0.955:
        if any(point_in_poly(_map_x, _map_y, shape) for shape in LAND_SHAPES):
            MAP_DOT_POINTS.append((_map_x, _map_y))
        _map_x += 0.0105
    _map_y += 0.0115
    _map_row += 1

# Positions are normalized to the stylized map canvas, in the same order as SERVERS.
SERVER_MAP_POSITIONS = [
    (0.515, 0.305),  # Netherlands
    (0.765, 0.575),  # Singapore
    (0.535, 0.315),  # Germany
    (0.495, 0.335),  # France
    (0.545, 0.235),  # Sweden
    (0.245, 0.345),  # United States
    (0.565, 0.225),  # Finland
    (0.845, 0.365),  # Japan
]
NETWORK_NODES = [
    (0.16, 0.36), (0.245, 0.345), (0.27, 0.49), (0.31, 0.59),
    (0.40, 0.31), (0.48, 0.42), (0.515, 0.305), (0.535, 0.315),
    (0.545, 0.235), (0.565, 0.225), (0.60, 0.42), (0.67, 0.40),
    (0.735, 0.50), (0.765, 0.575), (0.81, 0.34), (0.845, 0.365),
    (0.83, 0.61), (0.90, 0.70), (0.54, 0.60), (0.51, 0.68)
]

# Projectable latitude/longitude samples are precomputed once, not during mouse drag.
GLOBE_LAND_POINTS = [((0.5 - ny) * 150.0, (nx - 0.5) * 360.0) for nx, ny in MAP_DOT_POINTS]
GLOBE_LAND_POINTS.extend(((-78 + (row % 3) * 2, lon) for row, lon in enumerate(range(-175, 176, 5))))


def _globe_trig(lat_deg, lon_deg):
    lat = math.radians(lat_deg)
    lon = math.radians(lon_deg)
    return (math.sin(lat), math.cos(lat), math.sin(lon), math.cos(lon))

GLOBE_LAND_TRIG = tuple(_globe_trig(lat, lon) for lat, lon in GLOBE_LAND_POINTS)
SERVER_GLOBE_TRIG = tuple(_globe_trig(s["lat"], s["lon"]) for s in SERVERS)
GLOBE_GRID_CURVES = []
for _lat in (-60, -30, 0, 30, 60):
    GLOBE_GRID_CURVES.append(tuple(_globe_trig(_lat, _lon) for _lon in range(-180, 181, 6)))
for _lon in range(-150, 181, 30):
    GLOBE_GRID_CURVES.append(tuple(_globe_trig(_lat, _lon) for _lat in range(-86, 87, 5)))



APP_CONFIG_DIR = Path(os.environ.get("APPDATA", str(Path.home()))) / "VibeVPN"
PREFERENCES_FILE = APP_CONFIG_DIR / "preferences.json"

PREFERENCE_DEFAULTS = {
    # Brand, appearance, and profile
    'theme': 'Vibe Aurora',
    'accent_color': 'Ice Blue',
    'app_icon': 'Vibe Classic',
    'telegram_bot_username': '',
    'font_family': 'Segoe UI',
    'font_size': 'Standard',
    'ui_scale': '100%',
    'density': 'Comfortable',
    'high_contrast': False,
    'compact_server_cards': False,
    'show_mascot': True,
    'remember_window_size': True,
    'large_text': False,
    'compact_mode': False,
    'show_status_bar': True,
    'keep_on_top': False,
    # World map and navigation
    'animations': True,
    'reduced_motion': False,
    'animation_quality': 'Balanced',
    'map_dots': True,
    'map_grid': True,
    'map_routes': True,
    'map_glow': True,
    'map_labels': True,
    'map_density': 'High',
    'map_zoom': '100%',
    'traffic_graph': True,
    'show_server_nodes': True,
    'show_home_marker': True,
    'server_sort_order': 'Recommended',
    'favorite_servers_first': True,
    'default_location_region': 'All regions',
    'location_results_per_page': '24',
    'remember_location_search': True,
    'location_show_flags': True,
    'location_show_country': True,
    'location_show_server_code': True,
    'location_show_region': False,
    'search_server_code': True,
    'location_return_to_overview': False,
    'globe_rotate_sensitivity': 'Normal',
    'globe_zoom_sensitivity': 'Normal',
    'globe_auto_rotate': False,
    'globe_auto_rotate_speed': 'Slow',
    'globe_marker_size': 'Normal',
    'globe_show_coordinates': False,
    'globe_show_stars': True,
    'globe_show_equator': True,
    'globe_simplified_drag': True,
    'globe_remember_view': True,
    'show_copy_location_button': True,
    'location_search_delay': 'Balanced',
    'globe_center_selected': True,
    'show_advanced_settings': False,
    # Connection and security
    'preferred_protocol': 'Automatic',
    'auto_connect': False,
    'auto_best_server': False,
    'reconnect_on_drop': True,
    'protocol_fallback': True,
    'remember_last_server': True,
    'minimize_on_connect': False,
    'keep_on_top': False,
    'ask_before_disconnect': True,
    'confirm_server_switch': True,
    'kill_switch': False,
    'dns_protection': True,
    'ipv6_protection': True,
    'malware_block': False,
    'ad_block': False,
    'tracker_block': False,
    'split_tunneling': False,
    'allow_lan': True,
    'dns_mode': 'Automatic',
    'custom_dns': '1.1.1.1',
    'block_suspicious': False,
    'secure_dns_fallback': True,
    # Local data and profile
    'save_server_history': True,
    'remember_favorites': True,
    'hide_ip_address': True,
    'auto_save_settings': True,
    # Display, access and performance
    'show_ping': True,
    'show_speed_stats': True,
    'show_session_timer': True,
    'show_server_load': True,
    'keyboard_shortcuts': True,
    'confirm_exit': False,
    'cpu_saver': False,
    'scroll_sensitivity': 'Normal',
    'dashboard_start_page': 'Overview',
    'local_activity_history': True,
}

THEME_PALETTES = {
    "Midnight Blue": {
        "BG":"#11151b","BG2":"#171c24","SIDEBAR":"#10141a","PANEL":"#1a2029",
        "PANEL2":"#202833","PANEL_HOVER":"#283341","BORDER":"#2b3542",
        "TEXT":"#edf2f8","MUTED":"#8c9aaa","DIM":"#657384",
        "BLUE":"#83b9e8","BLUE_BRIGHT":"#9dd1fa","BLUE_DARK":"#263e52",
        "CYAN":"#6ed7d4","GREEN":"#76d6bd","ORANGE":"#e6c58b","RED":"#e78e9a"
    },
    "OLED Black": {
        "BG":"#05070a","BG2":"#0a0d12","SIDEBAR":"#07090c","PANEL":"#0e1218",
        "PANEL2":"#151b23","PANEL_HOVER":"#202a35","BORDER":"#27323f",
        "TEXT":"#f6fbff","MUTED":"#9aaabd","DIM":"#687b90",
        "BLUE":"#83b9e8","BLUE_BRIGHT":"#9dd1fa","BLUE_DARK":"#263e52",
        "CYAN":"#6ed7d4","GREEN":"#76d6bd","ORANGE":"#e6c58b","RED":"#e78e9a"
    },
    "Graphite": {
        "BG":"#191b20","BG2":"#22252b","SIDEBAR":"#17191e","PANEL":"#292c33",
        "PANEL2":"#333740","PANEL_HOVER":"#414652","BORDER":"#454b56",
        "TEXT":"#f0f1f4","MUTED":"#b0b6c0","DIM":"#838b98",
        "BLUE":"#8ebfea","BLUE_BRIGHT":"#b1d9ff","BLUE_DARK":"#35495e",
        "CYAN":"#70d8d6","GREEN":"#81d8bd","ORANGE":"#eed49c","RED":"#f19aa3"
    },
    "Arctic Light": {
        "BG":"#e9eef5","BG2":"#f3f6fa","SIDEBAR":"#dce5ef","PANEL":"#ffffff",
        "PANEL2":"#eef3f8","PANEL_HOVER":"#e1eaf4","BORDER":"#ced9e6",
        "TEXT":"#192534","MUTED":"#526579","DIM":"#73869b",
        "BLUE":"#377fb9","BLUE_BRIGHT":"#256caa","BLUE_DARK":"#d3e8f8",
        "CYAN":"#238e9b","GREEN":"#197c65","ORANGE":"#98630c","RED":"#b74255"
    },
    "Violet Night": {
        "BG":"#12101b","BG2":"#1a1727","SIDEBAR":"#110f1a","PANEL":"#201c2e",
        "PANEL2":"#2b263c","PANEL_HOVER":"#39324d","BORDER":"#3b354e",
        "TEXT":"#f2efff","MUTED":"#aaa2c5","DIM":"#77708f",
        "BLUE":"#a99aff","BLUE_BRIGHT":"#c6bcff","BLUE_DARK":"#393254",
        "CYAN":"#8cceff","GREEN":"#7ddcbe","ORANGE":"#e7c58d","RED":"#ed91b1"
    },
}
ACCENT_PALETTES = {
    "Ice Blue": ("#83b9e8","#9dd1fa","#263e52","#6ed7d4"),
    "Mint": ("#63d8c2","#9cf5e4","#1c4944","#70ead1"),
    "Neon Green": ("#22c55e","#86efac","#174b2b","#5bf59d"),
    "Violet": ("#a99aff","#c6bcff","#393254","#b6a6ff"),
    "Arctic Cyan": ("#65cbe8","#a4e9ff","#214653","#64dbe8"),
    "Rose": ("#f08ca7","#ffc0d0","#5a2b3b","#f6a9bd"),
    "Amber": ("#e5b65c","#ffdc8a","#514023","#f1c76b"),
}

# Fifteen complete one-click color systems (five original + ten new presets).
EXTRA_THEME_PRESETS = {
    "Ocean Glass": ("Midnight Blue", "Ice Blue"),
    "Cyber Mint": ("OLED Black", "Neon Green"),
    "Sakura Dusk": ("Violet Night", "Rose"),
    "Halloween Circuit": ("OLED Black", "Amber"),
    "Winter Frost": ("Midnight Blue", "Arctic Cyan"),
    "Holographic Prism": ("OLED Black", "Violet"),
    "Solar Flare": ("Graphite", "Amber"),
    "Aurora Night": ("Midnight Blue", "Mint"),
    "Retro Terminal": ("OLED Black", "Neon Green"),
    "Rose Quartz": ("Arctic Light", "Rose"),
}
for _theme_name, (_base_name, _accent_name) in EXTRA_THEME_PRESETS.items():
    _theme_palette = dict(THEME_PALETTES[_base_name])
    _accent = ACCENT_PALETTES[_accent_name]
    _theme_palette["BLUE"], _theme_palette["BLUE_BRIGHT"], _theme_palette["BLUE_DARK"], _theme_palette["CYAN"] = _accent
    THEME_PALETTES[_theme_name] = _theme_palette

THEME_DEFAULT_ACCENTS = {
    "Midnight Blue": "Ice Blue", "OLED Black": "Ice Blue", "Graphite": "Ice Blue",
    "Arctic Light": "Arctic Cyan", "Violet Night": "Violet",
    **{name: accent for name, (base, accent) in EXTRA_THEME_PRESETS.items()},
}

# V9 visual direction: Aurora Glass — deep ink surfaces, electric ice highlights,
# restrained mint status color and layered blue depth. Existing user preferences remain valid.
VIBE_AURORA_PALETTE = {
    "BG":"#080D14", "BG2":"#0E1621", "SIDEBAR":"#090F18", "PANEL":"#111D2A",
    "PANEL2":"#18293A", "PANEL_HOVER":"#21394B", "BORDER":"#263C4C",
    "TEXT":"#F2F7FC", "MUTED":"#9BADBF", "DIM":"#637B90",
    "BLUE":"#65B9F4", "BLUE_BRIGHT":"#A4DEFF", "BLUE_DARK":"#163B52",
    "CYAN":"#54E4D4", "GREEN":"#71E7B7", "ORANGE":"#F0C47E", "RED":"#F18D9C"
}
THEME_PALETTES["Midnight Blue"] = dict(VIBE_AURORA_PALETTE)
THEME_PALETTES["Vibe Aurora"] = dict(VIBE_AURORA_PALETTE)
THEME_PALETTES["Vibe Aurora"]["BLUE"] = "#5AC6F4"
THEME_PALETTES["Vibe Aurora"]["BLUE_BRIGHT"] = "#C0F0FF"
THEME_PALETTES["Vibe Aurora"]["BLUE_DARK"] = "#173D51"
THEME_PALETTES["Vibe Aurora"]["CYAN"] = "#59F0D7"
THEME_DEFAULT_ACCENTS["Vibe Aurora"] = "Arctic Cyan"

APP_ICON_STYLES = {
    "Vibe Classic": ("vibe_classic.ico", "V", "#102536", "#83b9e8"),
    "Vibi Fox": ("vibi_fox.ico", "◈", "#102536", "#9dd1fa"),
    "Halloween": ("halloween.ico", "☾", "#25152c", "#ff974d"),
    "Winter Glow": ("winter_glow.ico", "✦", "#102a42", "#b9e9ff"),
    "Holographic": ("holographic.ico", "◇", "#271f4a", "#e2b8ff"),
    "Cyber Neon": ("cyber_neon.ico", "V", "#071c1b", "#00ffcc"),
    "Spring Bloom": ("spring_bloom.ico", "✿", "#153328", "#ff9fcf"),
    "Lunar Eclipse": ("lunar_eclipse.ico", "☾", "#151827", "#b6b8ff"),
    "Solar Flare": ("solar_flare.ico", "☼", "#2e1d17", "#ffcc66"),
    "Aurora": ("aurora.ico", "✧", "#10252d", "#72f1cd"),
}
PALETTE_KEYS = ("BG","BG2","SIDEBAR","PANEL","PANEL2","PANEL_HOVER","BORDER",
                "TEXT","MUTED","DIM","BLUE","BLUE_BRIGHT","BLUE_DARK","CYAN","GREEN","ORANGE","RED")


class RoundedButton(tk.Canvas):
    """Soft, anti-aliased-feeling pill button, drawn on Canvas without native square edges."""
    def __init__(self, parent, text, command, bg=None, fg=None, hover=None,
                 padx=13, pady=8, font_size=9, anchor="center", **kwargs):
        self._button_text = str(text)
        self._button_anchor = anchor
        self._button_command = command
        self._button_bg = bg or PANEL2
        self._button_fg = fg or TEXT
        self._button_hover = hover or PANEL_HOVER
        self._button_active_fg = self._button_fg
        self._button_font_size = int(font_size)
        self._button_font = ("Segoe UI", self._button_font_size, "bold")
        self._button_padx = int(padx)
        self._button_pady = int(pady)
        self._hovering = False
        self._pressed = False
        self._enabled = True
        self._custom_state = "normal"
        actual_parent_bg = self._parent_bg(parent)
        width = self._measure_width(parent)
        height = max(31, self._button_font_size + self._button_pady * 2 + 12)
        cursor = kwargs.pop("cursor", "hand2")
        super().__init__(parent, bg=actual_parent_bg, highlightthickness=0, bd=0,
                         cursor=cursor, width=width, height=height, **kwargs)
        self.bind("<Configure>", self._draw_button, add="+")
        self.bind("<Enter>", self._on_enter, add="+")
        self.bind("<Leave>", self._on_leave, add="+")
        self.bind("<ButtonPress-1>", self._on_press, add="+")
        self.bind("<ButtonRelease-1>", self._on_release, add="+")
        self._draw_button()

    @staticmethod
    def _parent_bg(parent):
        try: return parent.cget("bg")
        except (tk.TclError, TypeError): return BG

    def _font_object(self):
        try:
            family, size, weight = self._button_font[:3]
            return tkfont.Font(root=self, family=family, size=int(size), weight=weight)
        except Exception:
            return tkfont.Font(root=self, family="Segoe UI", size=self._button_font_size, weight="bold")

    def _measure_width(self, parent=None):
        try:
            font = tkfont.Font(root=parent or self, family=self._button_font[0],
                               size=int(self._button_font[1]), weight=self._button_font[2])
            return max(64, font.measure(self._button_text) + self._button_padx * 2 + 24)
        except Exception:
            return max(88, len(self._button_text) * 7 + self._button_padx * 2 + 20)

    def winfo_class(self):
        # Keep theme mapping and font preference code treating this as a Button.
        return "Button"

    def cget(self, key):
        key = str(key).lstrip("-")
        mapping = {
            "text": self._button_text, "command": self._button_command,
            "bg": self._button_bg, "background": self._button_bg,
            "fg": self._button_fg, "foreground": self._button_fg,
            "activebackground": self._button_hover,
            "activeforeground": self._button_active_fg,
            "font": self._button_font, "state": self._custom_state,
        }
        if key in mapping: return mapping[key]
        return super().cget(key)

    def configure(self, cnf=None, **kwargs):
        if isinstance(cnf, dict): kwargs.update(cnf)
        elif isinstance(cnf, str) and not kwargs: return self.cget(cnf)
        if not kwargs: return super().configure()
        redraw = False
        for key, value in list(kwargs.items()):
            norm = key.lstrip("-")
            if norm in ("text",): self._button_text = str(value); redraw = True
            elif norm in ("command",): self._button_command = value
            elif norm in ("bg", "background"):
                self._button_bg = value
                try: super().configure(bg=self._parent_bg(self.master))
                except tk.TclError: pass
                redraw = True
            elif norm in ("fg", "foreground"):
                self._button_fg = value; redraw = True
            elif norm == "activebackground": self._button_hover = value; redraw = True
            elif norm == "activeforeground": self._button_active_fg = value; redraw = True
            elif norm == "anchor":
                self._button_anchor = str(value); redraw = True
            elif norm == "font":
                self._button_font = value
                try:
                    parsed = tkfont.Font(root=self, font=value).actual()
                    self._button_font_size = abs(int(parsed.get("size", self._button_font_size)))
                except Exception: pass
                redraw = True
            elif norm == "state":
                self._custom_state = str(value)
                self._enabled = self._custom_state != "disabled"
                try: super().configure(cursor="hand2" if self._enabled else "arrow")
                except tk.TclError: pass
                redraw = True
            elif norm in ("padx",): self._button_padx = int(value); redraw = True
            elif norm in ("pady",): self._button_pady = int(value); redraw = True
            else:
                try: super().configure(**{norm: value})
                except tk.TclError: pass
        if redraw:
            try:
                if self.winfo_exists(): self.configure(width=self._measure_width(), height=max(31, self._button_font_size + self._button_pady * 2 + 12))
            except tk.TclError: pass
            self._draw_button()

    config = configure

    @staticmethod
    def _darken(hex_color, factor=.82):
        try:
            color = hex_color.lstrip("#")
            rgb = [int(color[i:i+2], 16) for i in (0, 2, 4)]
            return "#" + "".join(f"{max(0,min(255,int(ch*factor))):02x}" for ch in rgb)
        except Exception:
            return hex_color

    def _round_rect(self, x1, y1, x2, y2, radius, fill, outline="", width=1):
        width_px = max(1, x2-x1); height_px = max(1, y2-y1)
        r = max(2, min(radius, width_px/2, height_px/2))
        points = [x1+r,y1, x2-r,y1, x2,y1, x2,y1+r,
                  x2,y2-r, x2,y2, x2-r,y2, x1+r,y2,
                  x1,y2, x1,y2-r, x1,y1+r, x1,y1]
        return self.create_polygon(points, smooth=True, splinesteps=20, fill=fill,
                                   outline=outline, width=width)

    def _draw_button(self, _event=None):
        try:
            if not self.winfo_exists(): return
            self.delete("all")
            w = max(38, self.winfo_width(), int(float(self.cget("width"))))
            h = max(30, self.winfo_height(), int(float(self.cget("height"))))
            try: super().configure(bg=self._parent_bg(self.master))
            except tk.TclError: pass
            disabled = not self._enabled
            fill = PANEL2 if disabled else (self._button_hover if (self._hovering or self._pressed) else self._button_bg)
            fg = DIM if disabled else (self._button_active_fg if self._hovering else self._button_fg)
            # A quiet shadow and 1px top highlight make the button feel layered rather than flat.
            if not disabled:
                self._round_rect(3, 4, w-2, h-1, 13, self._darken(fill, .58))
            self._round_rect(2, 1, w-3, h-4, 12, fill, outline=self._darken(fill, .78), width=1)
            if fill in (BLUE, BLUE_BRIGHT, GREEN, CYAN) or self._button_bg in (BLUE, BLUE_BRIGHT, GREEN, CYAN):
                self.create_line(14, 5, max(15, w-15), 5, fill=self._darken(fill, .9), width=1, capstyle="round")
            try:
                font = self._font_object()
                if self._button_anchor in ("w", "left"):
                    text_x, text_anchor = 14, "w"
                elif self._button_anchor in ("e", "right"):
                    text_x, text_anchor = w-14, "e"
                else:
                    text_x, text_anchor = w/2, "center"
                self.create_text(text_x, h/2-1, text=self._button_text, fill=fg,
                                 font=font, width=max(20, w-28), justify="left" if text_anchor == "w" else "center",
                                 anchor=text_anchor)
            except tk.TclError: pass
        except tk.TclError:
            pass

    def _on_enter(self, _event):
        if self._enabled:
            self._hovering = True
            self._draw_button()

    def _on_leave(self, _event):
        self._hovering = False
        self._pressed = False
        self._draw_button()

    def _on_press(self, event):
        if self._enabled:
            self._pressed = True
            self._draw_button()

    def _on_release(self, event):
        should_run = self._enabled and self._pressed
        self._pressed = False
        self._draw_button()
        if should_run and 0 <= event.x <= self.winfo_width() and 0 <= event.y <= self.winfo_height():
            try:
                if callable(self._button_command): self._button_command()
            except tk.TclError:
                pass


class HorizonVPN(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Vibe VPN — Aurora Edition")
        self.geometry("1280x820")
        self.minsize(1040, 680)
        self.configure(bg=BG)
        self.prefs = self._load_preferences()
        self._base_fonts = {}
        self._setting_vars = {}
        self._setting_status = None
        saved_geometry = self.prefs.get("_window_geometry")
        if self.prefs.get("remember_window_size") and isinstance(saved_geometry, str):
            try:
                if re.fullmatch(r"\d+x\d+(?:[+-]\d+[+-]\d+)?", saved_geometry):
                    self.geometry(saved_geometry)
            except tk.TclError:
                pass
        self.connected = False
        try:
            remember_view = self.prefs.get("globe_remember_view", True)
            self.globe_lon = float(self.prefs.get("_globe_lon", 0.0)) if remember_view else 0.0
            self.globe_lat = float(self.prefs.get("_globe_lat", 0.10)) if remember_view else 0.10
            default_zoom = {"80%": .80, "100%": 1.0, "120%": 1.20}.get(self.prefs.get("map_zoom"), 1.0)
            self.globe_zoom = float(self.prefs.get("_globe_zoom", default_zoom)) if remember_view else default_zoom
            self.globe_lon %= (2 * math.pi)
            self.globe_lat = max(-1.38, min(1.38, self.globe_lat))
            self.globe_zoom = max(.72, min(1.35, self.globe_zoom))
        except (TypeError, ValueError):
            self.globe_lon, self.globe_lat, self.globe_zoom = 0.0, 0.10, 1.0
        self._globe_drag_state = None
        self._globe_drag_moved = False
        self._globe_redraw_jobs = {}
        self._globe_resize_jobs = {}
        self._globe_resize_preview_jobs = {}
        self._globe_last_resize_preview = {}
        self._globe_settle_jobs = {}
        self._globe_bg_cache = {}
        self._globe_photo_refs = {}
        self._globe_image_items = {}
        # Last raster for each globe canvas. During live window resizing we scale
        # this snapshot rather than re-projecting thousands of globe points.
        self._globe_source_images = {}
        self._globe_snapshot_paste_boxes = {}
        self._globe_snapshot_canvas_sizes = {}
        self._window_resize_active = False
        self._window_resize_job = None
        self._globe_resize_min_interval = 0.12
        self._projection_context_key = None
        self._projection_context = None
        self._location_filter_job = None
        self._location_render_job = None
        self._location_render_queue = []
        self._last_location_render_signature = None
        self.location_visible_count = self._location_page_size()
        try:
            self.selected = int(self.prefs.get("_last_server_index", 0)) if self.prefs.get("remember_last_server") else 0
            if not 0 <= self.selected < len(SERVERS):
                self.selected = 0
        except (TypeError, ValueError):
            self.selected = 0
        self.active_nav = "Overview"
        self.page = "overview"
        self.profile_name = str(self.prefs.get("_profile_name", "Vibe User"))[:60]
        self.mascot_name = "Vibi"
        self.profile_email = str(self.prefs.get("_profile_email", "user@example.com"))[:120]
        self.profile_avatar = str(self.prefs.get("_profile_avatar", "V"))[:2]
        self.profile_accent = BLUE
        self.active_plan = str(self.prefs.get("_active_plan", "Free"))
        self.animation_tick = 0
        self.pulse = 0
        self._last_auto_rotate_at = time.monotonic()
        self.started_at = None
        self._server_rows = []
        self._map_redraw_job = None
        self._last_map_size = (0, 0)
        self._page_frames = {}
        self._built_pages = set()
        self._visible_page = None
        self._closing = False
        self._animation_job = None
        self._toast_job = None
        self._preferences_save_job = None
        self._theme_recolor_job = None
        self._theme_recolor_generation = 0
        self._theme_recolor_queue = []
        self._theme_recolor_map = {}
        self._plans_build_job = None
        self._plans_card_queue = []
        self._customize_build_job = None
        self._customize_theme_queue = []
        self._customize_icon_queue = []
        self._diagnostics_build_job = None
        self._diagnostics_queue = []
        self._activity_render_job = None
        self._activity_render_queue = []
        self._activity_view_signature = None
        self._last_location_render_signature = None
        self._globe_last_draw_ms = 0.0
        self._globe_avg_draw_ms = 0.0
        self._globe_peak_draw_ms = 0.0
        self._globe_draw_count = 0
        self.activity_entries = [
            item for item in self.prefs.get("_activity_log", [])
            if isinstance(item, dict) and "action" in item
        ][-120:]
        self._build_styles()
        self._build_layout()
        self.bind("<Configure>", self._on_window_configure, add="+")
        initial_page_name = self.prefs.get("dashboard_start_page", "Overview")
        initial_page_key = {"Overview":"overview","Locations":"locations","Security":"security"}.get(initial_page_name,"overview")
        self.page = initial_page_key
        self.active_nav = initial_page_name
        self._activate_page(initial_page_key)
        initial_renderers = {"overview":self._render_overview,"locations":self._render_locations,"security":self._render_security}
        initial_renderers[initial_page_key]()
        self._built_pages.add(initial_page_key)
        self.page_title.configure(text=initial_page_name)
        self._apply_visual_preferences(persist=False)
        self._apply_window_icon()
        for nav_name, button in self.nav_buttons.items():
            selected = nav_name == initial_page_name
            button.configure(bg=BLUE_DARK if selected else SIDEBAR,
                             fg=BLUE_BRIGHT if selected else MUTED)
        self._bind_shortcuts()
        self._record_activity("App started", "Vibe VPN UI opened; no VPN tunnel is active in this preview build.", persist=False)
        self._ensure_animation_loop()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ------------------------ Preferences / personalization -----------------
    def _load_preferences(self):
        data = {}
        try:
            if PREFERENCES_FILE.exists():
                with PREFERENCES_FILE.open("r", encoding="utf-8") as f:
                    raw = json.load(f)
                if isinstance(raw, dict):
                    data = raw
        except (OSError, ValueError, TypeError):
            data = {}
        prefs = dict(PREFERENCE_DEFAULTS)
        # Only accept values for known preferences; a corrupt file cannot break launch.
        for key, value in data.items():
            if key in PREFERENCE_DEFAULTS:
                prefs[key] = value
        for internal in ("_window_geometry", "_last_server_index", "_recent_servers",
                         "_profile_name", "_profile_email", "_profile_avatar", "_active_plan", "_favorite_codes",
                         "_location_search", "_globe_lon", "_globe_lat", "_globe_zoom",
                         "_activity_log"):
            if internal in data:
                prefs[internal] = data[internal]
        # Repair invalid enum values after an update.
        valid = {
            "theme": list(THEME_PALETTES),
            "accent_color": list(ACCENT_PALETTES),
            "app_icon": list(APP_ICON_STYLES),
            "font_family": ["Segoe UI", "Inter", "Arial", "Calibri", "Consolas", "Verdana"],
            "font_size": ["Small", "Standard", "Large", "Extra Large"],
            "ui_scale": ["90%", "100%", "110%", "120%"],
            "density": ["Compact", "Comfortable", "Spacious"],
            "map_density": ["Low", "Normal", "High"],
            "map_zoom": ["80%", "100%", "120%"],
            "animation_quality": ["Economy", "Balanced", "Smooth"],
            "preferred_protocol": ["Automatic", "WireGuard", "OpenVPN", "IKEv2"],
            "dns_mode": ["Automatic", "DNS-over-HTTPS", "Custom DNS"],
            "scroll_sensitivity": ["Low", "Normal", "High"],
            "dashboard_start_page": ["Overview", "Locations", "Security"],
            "server_sort_order": ["Recommended", "City A–Z", "Country A–Z", "Region", "Code", "Recently used"],
            "default_location_region": ["All regions", "Europe", "Asia Pacific", "Americas", "Middle East", "Africa", "Oceania", "★ Favorites"],
            "location_results_per_page": ["12", "24", "48", "All"],
            "globe_rotate_sensitivity": ["Low", "Normal", "High"],
            "globe_zoom_sensitivity": ["Low", "Normal", "High"],
            "globe_auto_rotate_speed": ["Slow", "Normal", "Fast"],
            "globe_marker_size": ["Small", "Normal", "Large"],
            "location_search_delay": ["Fast", "Balanced", "Power saver"],
        }
        for key, options in valid.items():
            if prefs.get(key) not in options:
                prefs[key] = PREFERENCE_DEFAULTS[key]
        for key, default in PREFERENCE_DEFAULTS.items():
            if isinstance(default, bool):
                prefs[key] = bool(prefs.get(key))
        if not prefs.get("remember_favorites", True):
            prefs.pop("_favorite_codes", None)
        if not prefs.get("remember_location_search", True):
            prefs.pop("_location_search", None)
        if not prefs.get("globe_remember_view", True):
            for key in ("_globe_lon", "_globe_lat", "_globe_zoom"):
                prefs.pop(key, None)
        return prefs

    def _queue_preferences_save(self, delay=240):
        if self._closing:
            return
        if self._preferences_save_job is not None:
            try: self.after_cancel(self._preferences_save_job)
            except tk.TclError: pass
        try:
            self._preferences_save_job = self.after(delay, self._commit_queued_preferences)
        except tk.TclError:
            self._preferences_save_job = None

    def _commit_queued_preferences(self):
        self._preferences_save_job = None
        if not self._closing:
            self._save_preferences()

    def _save_preferences(self):
        if self._preferences_save_job is not None:
            try: self.after_cancel(self._preferences_save_job)
            except tk.TclError: pass
            self._preferences_save_job = None
        try:
            APP_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            data = dict(self.prefs)
            if self.prefs.get("remember_window_size"):
                data["_window_geometry"] = self.geometry()
            else:
                data.pop("_window_geometry", None)
            if not self.prefs.get("remember_favorites", True):
                data.pop("_favorite_codes", None)
            if not self.prefs.get("remember_location_search", True):
                data.pop("_location_search", None)
            if not self.prefs.get("globe_remember_view", True):
                for key in ("_globe_lon", "_globe_lat", "_globe_zoom"):
                    data.pop(key, None)
            with PREFERENCES_FILE.open("w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            if self._setting_status is not None and self._setting_status.winfo_exists():
                self._setting_status.configure(text="All preferences saved", fg=GREEN)
            return True
        except (OSError, tk.TclError):
            if self._setting_status is not None and self._setting_status.winfo_exists():
                self._setting_status.configure(text="Could not save preferences", fg=RED)
            return False

    def _on_close(self):
        if self.prefs.get("confirm_exit"):
            if not messagebox.askyesno("Vibe VPN", "Close Vibe VPN?", parent=self):
                return
        self._closing = True
        for attr in ("_animation_job", "_window_resize_job", "_toast_job", "_preferences_save_job", "_location_filter_job", "_location_render_job", "_settings_build_job", "_settings_filter_job", "_theme_recolor_job", "_plans_build_job", "_customize_build_job", "_diagnostics_build_job", "_activity_render_job"):
            job = getattr(self, attr, None)
            if job is not None:
                try: self.after_cancel(job)
                except tk.TclError: pass
                setattr(self, attr, None)
        for job_map_name in ("_globe_redraw_jobs", "_globe_resize_jobs", "_globe_resize_preview_jobs", "_globe_settle_jobs"):
            job_map = getattr(self, job_map_name, {})
            for key in list(job_map): self._cancel_job(job_map, key)
        if self.prefs.get("remember_window_size"):
            self.prefs["_window_geometry"] = self.geometry()
        if self.prefs.get("globe_remember_view", True):
            self.prefs["_globe_lon"] = self.globe_lon
            self.prefs["_globe_lat"] = self.globe_lat
            self.prefs["_globe_zoom"] = self.globe_zoom
        self._save_preferences()
        self.destroy()

    def _bind_shortcuts(self):
        # The callbacks check the live preference, so the shortcut toggle applies immediately.
        for index, page_name in enumerate(("Overview","Locations","Security","Profile","Customize","Plans","Settings","Activity","Diagnostics"), 1):
            self.bind_all(f"<Control-Key-{index}>",
                          lambda event, n=page_name: self._shortcut_navigate(n))
        self.bind_all("<Control-Key-l>", lambda event: self._shortcut_focus_search())
        self.bind_all("<Escape>", lambda event: self._shortcut_navigate("Overview"))

    def _shortcut_navigate(self, name):
        if self.prefs.get("keyboard_shortcuts"):
            self._navigate(name)
        return "break"

    def _shortcut_focus_search(self):
        if self.prefs.get("keyboard_shortcuts"):
            self._navigate("Locations")
            if hasattr(self, "search_var_entry") and self.search_var_entry.winfo_exists():
                self.search_var_entry.focus_set()
        return "break"

    def _walk_widgets(self, root):
        yield root
        try:
            children = root.winfo_children()
        except (tk.TclError, AttributeError):
            children = []
        for child in children:
            yield from self._walk_widgets(child)

    def _apply_font_to_widget(self, widget):
        try:
            current = widget.cget("font")
            if not current:
                return
            key = str(widget)
            if key not in self._base_fonts:
                actual = tkfont.Font(root=self, font=current).actual()
                self._base_fonts[key] = (
                    abs(int(actual["size"] or 10)),
                    str(actual["weight"] or "normal"),
                    str(actual["slant"] or "roman"),
                    int(actual["underline"] or 0),
                    int(actual["overstrike"] or 0),
                )
            family = self._font_family()
            size_factor = {"Small": .90, "Standard": 1.0, "Large": 1.12, "Extra Large": 1.25}.get(
                self.prefs.get("font_size"), 1.0)
            scale_factor = {"90%": .90, "100%": 1.0, "110%": 1.10, "120%": 1.20}.get(
                self.prefs.get("ui_scale"), 1.0)
            if self.prefs.get("large_text"):
                size_factor *= 1.10
            base_size, weight, slant, underline, overstrike = self._base_fonts[key]
            desired_size = max(7, round(base_size * size_factor * scale_factor))
            font_obj = tkfont.Font(root=self, font=current)
            actual = font_obj.actual()
            if (str(actual.get("family", "")) != family
                    or abs(int(actual.get("size", 0))) != desired_size
                    or str(actual.get("weight", "normal")) != weight
                    or str(actual.get("slant", "roman")) != slant
                    or int(actual.get("underline", 0)) != underline
                    or int(actual.get("overstrike", 0)) != overstrike):
                widget.configure(font=(family, desired_size, weight, slant, underline, overstrike))
        except (tk.TclError, TypeError, ValueError):
            pass

    def _apply_font_preferences(self, root=None):
        # Used for explicit accessibility refreshes only; normal navigation creates
        # correctly-sized controls directly and does not walk the whole widget tree.
        for widget in self._walk_widgets(root if root is not None else self):
            self._apply_font_to_widget(widget)

    def _apply_window_icon(self):
        style = self.prefs.get("app_icon", "Vibe Classic")
        meta = APP_ICON_STYLES.get(style, APP_ICON_STYLES["Vibe Classic"])
        icon_dir = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent)) / "icons"
        icon_path = icon_dir / meta[0]
        try:
            if icon_path.exists():
                self.iconbitmap(str(icon_path))
        except (tk.TclError, OSError):
            pass  # Non-Windows platforms may not support .ico; UI icon preview still updates.
        if hasattr(self, "logo_canvas") and self.logo_canvas.winfo_exists():
            logo = self.logo_canvas
            logo.delete("all")
            _, glyph, bg_color, accent = meta
            logo.create_oval(4, 4, 38, 38, fill=bg_color, outline=accent, width=1.5)
            logo.create_text(21, 21, text=glyph, fill=accent, font=("Segoe UI Symbol", 18, "bold"))

    def _on_icon_choice(self, style_name):
        self.prefs["app_icon"] = style_name
        self._apply_window_icon()
        if self.prefs.get("auto_save_settings", True):
            self._save_preferences()
        if hasattr(self, "icon_gallery_cards"):
            for name, card in self.icon_gallery_cards.items():
                try:
                    card.configure(highlightbackground=BLUE if name == style_name else BORDER)
                except tk.TclError:
                    pass

    def _apply_visual_preferences(self, persist=True):
        old = {key: globals().get(key) for key in PALETTE_KEYS}
        palette = dict(THEME_PALETTES.get(self.prefs.get("theme"), THEME_PALETTES["Midnight Blue"]))
        accent = ACCENT_PALETTES.get(self.prefs.get("accent_color"), ACCENT_PALETTES["Ice Blue"])
        palette["BLUE"], palette["BLUE_BRIGHT"], palette["BLUE_DARK"], palette["CYAN"] = accent
        if self.prefs.get("high_contrast"):
            palette["TEXT"] = "#ffffff" if self.prefs.get("theme") != "Arctic Light" else "#0a1725"
            palette["MUTED"] = "#c7d5e4" if self.prefs.get("theme") != "Arctic Light" else "#30465b"

        # Map every known source-theme color to its semantic counterpart in the target
        # palette. This makes switching themes repeatedly while a recolor is in progress safe.
        color_map = {}
        for source_palette in THEME_PALETTES.values():
            for key in PALETTE_KEYS:
                source = source_palette.get(key)
                target = palette.get(key)
                if isinstance(source, str) and isinstance(target, str):
                    color_map[source.lower()] = target
        accent_roles = ("BLUE", "BLUE_BRIGHT", "BLUE_DARK", "CYAN")
        for source_accent in ACCENT_PALETTES.values():
            for key, source in zip(accent_roles, source_accent):
                if key in palette:
                    color_map[source.lower()] = palette[key]
        for key in PALETTE_KEYS:
            source, target = old.get(key), palette.get(key)
            if isinstance(source, str) and isinstance(target, str):
                color_map[source.lower()] = target

        for key, value in palette.items():
            globals()[key] = value
        try:
            self.configure(bg=BG)
            self.attributes("-topmost", bool(self.prefs.get("keep_on_top")))
        except tk.TclError:
            pass
        self._build_styles()
        self._apply_window_icon()
        self._projection_context_key = None
        self._globe_bg_cache.clear()

        # Process controls in small chunks. The visible page is prioritized; cached
        # off-screen pages are recolored later without freezing navigation.
        self._theme_recolor_generation += 1
        generation = self._theme_recolor_generation
        if self._theme_recolor_job is not None:
            try: self.after_cancel(self._theme_recolor_job)
            except tk.TclError: pass
            self._theme_recolor_job = None
        all_widgets = list(self._walk_widgets(self))
        active_frame = self._page_frames.get(self._visible_page) if hasattr(self, "_page_frames") else None
        priority = list(self._walk_widgets(active_frame)) if active_frame is not None else []
        seen = {str(widget) for widget in priority}
        self._theme_recolor_queue = priority + [widget for widget in all_widgets if str(widget) not in seen]
        self._theme_recolor_map = color_map
        self._recolor_widgets_batch(generation, immediate=True)

        if hasattr(self, "map_canvas") and self.map_canvas.winfo_exists() and self.page == "overview":
            self._schedule_globe_redraw(self.map_canvas, 0, quality="preview")
            self._schedule_globe_full_settle(self.map_canvas, 180)
        if hasattr(self, "geo_canvas") and self.geo_canvas.winfo_exists() and self.page == "locations":
            self._schedule_globe_redraw(self.geo_canvas, 0, quality="preview")
            self._schedule_globe_full_settle(self.geo_canvas, 180)
        if hasattr(self, "connect_canvas") and self.connect_canvas.winfo_exists():
            self._draw_connect_button()
        if persist:
            self._save_preferences()

    def _recolor_widgets_batch(self, generation, immediate=False):
        if self._closing or generation != self._theme_recolor_generation:
            return
        queue = self._theme_recolor_queue
        batch_size = 85 if immediate else 110
        batch = [queue.pop(0) for _ in range(min(batch_size, len(queue)))]
        options_by_class = {
            "Tk": ("bg",), "Toplevel": ("bg",), "Frame": ("bg", "highlightbackground", "highlightcolor"),
            "Labelframe": ("bg", "fg", "highlightbackground"),
            "Label": ("bg", "fg"),
            "Button": ("bg", "fg", "activebackground", "activeforeground", "highlightbackground"),
            "Checkbutton": ("bg", "fg", "activebackground", "activeforeground", "selectcolor"),
            "Radiobutton": ("bg", "fg", "activebackground", "activeforeground", "selectcolor"),
            "Canvas": ("bg", "highlightbackground", "highlightcolor"),
            "Entry": ("bg", "fg", "insertbackground", "selectbackground", "selectforeground"),
            "Text": ("bg", "fg", "insertbackground", "selectbackground", "selectforeground"),
            "Listbox": ("bg", "fg", "selectbackground", "selectforeground"),
            "Scale": ("bg", "fg", "activebackground", "troughcolor"),
            "Spinbox": ("bg", "fg", "insertbackground", "selectbackground", "selectforeground"),
        }
        for widget in batch:
            try:
                if not widget.winfo_exists():
                    continue
                for option in options_by_class.get(widget.winfo_class(), ()):
                    try:
                        current = widget.cget(option)
                        if isinstance(current, str):
                            mapped = self._theme_recolor_map.get(current.lower())
                            if mapped and current.lower() != mapped.lower():
                                widget.configure(**{option: mapped})
                    except (tk.TclError, TypeError):
                        pass
                self._apply_font_to_widget(widget)
            except tk.TclError:
                continue
        if queue:
            try:
                self._theme_recolor_job = self.after(2, lambda g=generation: self._recolor_widgets_batch(g))
            except tk.TclError:
                self._theme_recolor_job = None
        else:
            self._theme_recolor_job = None
            if self._setting_status is not None and self._setting_status.winfo_exists():
                self._setting_status.configure(text="Theme and typography applied", fg=GREEN)

    def _preference_changed(self, key, value):
        """Apply settings in place. Page navigation and setting edits never rebuild the whole window."""
        self.prefs[key] = value

        if key == "theme" and value in THEME_DEFAULT_ACCENTS:
            self.prefs["accent_color"] = THEME_DEFAULT_ACCENTS[value]

        if key == "app_icon":
            self._on_icon_choice(str(value))

        if key in {"theme", "accent_color", "font_family", "font_size", "ui_scale",
                   "high_contrast", "large_text"}:
            self._apply_visual_preferences(persist=False)

        if key == "show_advanced_settings":
            self._filter_settings_view()

        if key == "show_mascot" and hasattr(self, "mascot_card"):
            if value:
                self.mascot_card.pack(fill="x", pady=(10, 0))
            else:
                self.mascot_card.pack_forget()

        if key == "show_status_bar" and hasattr(self, "top_right"):
            if value:
                self.top_right.pack(side="right")
            else:
                self.top_right.pack_forget()

        if key == "keep_on_top":
            try:
                self.attributes("-topmost", bool(value))
            except tk.TclError:
                pass

        if key == "remember_last_server":
            if value:
                self.prefs["_last_server_index"] = self.selected
            else:
                self.prefs.pop("_last_server_index", None)

        if key == "remember_location_search" and not value:
            self.prefs.pop("_location_search", None)

        if key == "globe_remember_view" and not value:
            for internal_key in ("_globe_lon", "_globe_lat", "_globe_zoom"):
                self.prefs.pop(internal_key, None)
        elif key == "globe_remember_view" and value:
            self.prefs["_globe_lon"] = self.globe_lon
            self.prefs["_globe_lat"] = self.globe_lat
            self.prefs["_globe_zoom"] = self.globe_zoom

        if key == "default_location_region" and hasattr(self, "geo_region_var"):
            try:
                self.geo_region_var.set(value)
            except tk.TclError:
                pass

        location_list_keys = {
            "server_sort_order", "favorite_servers_first", "location_show_flags",
            "location_show_country", "location_show_server_code", "location_show_region",
            "search_server_code", "location_results_per_page", "show_ping",
            "default_location_region", "remember_favorites"
        }
        if key in location_list_keys and hasattr(self, "location_list_inner"):
            self._last_location_render_signature = None
            if key == "location_results_per_page":
                self.location_visible_count = self._location_page_size()
            self._filter_servers()

        if key == "show_copy_location_button" and hasattr(self, "copy_location_button"):
            if value and not self.copy_location_button.winfo_manager():
                self.copy_location_button.pack(side="left", padx=5)
            elif not value and self.copy_location_button.winfo_manager():
                self.copy_location_button.pack_forget()

        if key == "globe_auto_rotate":
            self._last_auto_rotate_at = time.monotonic()

        globe_options = {
            "globe_marker_size", "globe_show_coordinates", "globe_show_stars",
            "globe_show_equator", "globe_simplified_drag", "globe_auto_rotate_speed",
            "map_density", "map_grid", "map_dots", "map_glow", "map_routes", "map_labels",
            "show_server_nodes", "show_home_marker", "map_zoom"
        }
        if key in globe_options:
            if key == "map_zoom":
                zoom = {"80%": .80, "100%": 1.0, "120%": 1.20}.get(value, 1.0)
                self.globe_zoom = max(.72, min(1.35, zoom))
                self._projection_context_key = None
                if self.prefs.get("globe_remember_view", True):
                    self.prefs["_globe_zoom"] = self.globe_zoom
            if hasattr(self, "_globe_bg_cache"):
                self._globe_bg_cache.clear()
            if hasattr(self, "geo_canvas") and self.geo_canvas.winfo_exists():
                self._schedule_globe_redraw(self.geo_canvas, 0, quality="full")
            if hasattr(self, "map_canvas") and self.map_canvas.winfo_exists():
                self._schedule_map_redraw()

        if key in {"animations", "reduced_motion", "animation_quality", "cpu_saver"}:
            if hasattr(self, "connect_canvas") and self.connect_canvas.winfo_exists():
                self._draw_connect_button()

        if key == "traffic_graph" and hasattr(self, "bottom_graph"):
            if value and not self.bottom_graph.winfo_manager():
                self.bottom_graph.pack(side="right", padx=9, pady=7)
            elif not value and self.bottom_graph.winfo_manager():
                self.bottom_graph.pack_forget()
            self._draw_graph()

        if key == "show_server_load" and hasattr(self, "load_text"):
            if value:
                if not self.load_text.winfo_manager():
                    self.load_text.pack(side="right")
                if not self.loadbar.winfo_manager():
                    self.loadbar.pack(fill="x")
            else:
                self.load_text.pack_forget()
                self.loadbar.pack_forget()

        if key == "show_session_timer" and hasattr(self, "timer"):
            if value:
                if not self.timer.winfo_manager():
                    self.timer.pack(side="left")
                if not self.session_caption.winfo_manager():
                    self.session_caption.pack(side="right")
            else:
                self.timer.pack_forget()
                self.session_caption.pack_forget()

        if key in {"show_ping", "show_speed_stats", "show_server_load", "show_session_timer"}:
            if key == "show_ping" and self.page == "locations":
                self._filter_servers()
            self._sync_page(self.page)

        if self.prefs.get("auto_save_settings", True):
            self._save_preferences()

        if key in {"animations", "reduced_motion", "animation_quality", "cpu_saver", "globe_auto_rotate", "globe_auto_rotate_speed"}:
            self._ensure_animation_loop()
        if self._setting_status is not None and self._setting_status.winfo_exists():
            self._setting_status.configure(text="Applied · " + key.replace("_", " "), fg=GREEN)

    def _export_preferences(self):
        filename = filedialog.asksaveasfilename(
            parent=self, title="Export Vibe VPN preferences", defaultextension=".json",
            filetypes=[("JSON preferences", "*.json")], initialfile="vibe-vpn-settings.json")
        if not filename:
            return
        try:
            with open(filename, "w", encoding="utf-8") as f:
                json.dump(self.prefs, f, ensure_ascii=False, indent=2)
            messagebox.showinfo("Vibe VPN", "Preferences exported.", parent=self)
        except OSError as exc:
            messagebox.showerror("Vibe VPN", f"Export failed: {exc}", parent=self)

    def _import_preferences(self):
        filename = filedialog.askopenfilename(
            parent=self, title="Import Vibe VPN preferences",
            filetypes=[("JSON preferences", "*.json")])
        if not filename:
            return
        try:
            with open(filename, "r", encoding="utf-8") as f:
                incoming = json.load(f)
            if not isinstance(incoming, dict):
                raise ValueError("Settings file is not an object.")
            for key in PREFERENCE_DEFAULTS:
                if key in incoming:
                    self.prefs[key] = incoming[key]
            for key in ("_window_geometry", "_last_server_index", "_recent_servers"):
                if key in incoming:
                    self.prefs[key] = incoming[key]
            self._apply_visual_preferences(persist=False)
            self._rebuild_settings_page()
            self._save_preferences()
            messagebox.showinfo("Vibe VPN", "Preferences imported.", parent=self)
        except (OSError, ValueError, TypeError) as exc:
            messagebox.showerror("Vibe VPN", f"Import failed: {exc}", parent=self)

    def _reset_preferences(self):
        if not messagebox.askyesno("Reset preferences", "Restore all Vibe VPN preferences to defaults?", parent=self):
            return
        self.prefs = dict(PREFERENCE_DEFAULTS)
        self._apply_visual_preferences(persist=False)
        self._rebuild_settings_page()
        self._save_preferences()

    def _clear_local_history(self):
        self.prefs["_recent_servers"] = []
        self.prefs.pop("_last_server_index", None)
        self._save_preferences()
        if self._setting_status is not None and self._setting_status.winfo_exists():
            self._setting_status.configure(text="Local recent-server history cleared", fg=GREEN)

    def _rebuild_settings_page(self):
        # Explicit refresh only for import/reset actions; navigation itself remains cached.
        self._activate_page("settings")
        self._render_settings()
        self._built_pages.add("settings")

    def _preference_groups(self):
        T, C, X = "toggle", "choice", "text"
        regions = ["All regions", "Europe", "Asia Pacific", "Americas", "Middle East", "Africa", "Oceania", "★ Favorites"]
        return [
            ("Appearance & accessibility", [
                ("theme","Color theme","Apply a complete theme instantly.",C,list(THEME_PALETTES),"UI"),
                ("accent_color","Accent color","Change the highlight color.",C,list(ACCENT_PALETTES),"UI"),
                ("font_family","Font family","Change the typeface across the interface.",C,["Segoe UI","Inter","Arial","Calibri","Consolas","Verdana"],"UI"),
                ("font_size","Font size","Choose a comfortable base text size.",C,["Small","Standard","Large","Extra Large"],"UI"),
                ("ui_scale","Interface scale","Scale text and controls together.",C,["90%","100%","110%","120%"],"UI"),
                ("density","Layout density","Compact, comfortable or spacious spacing.",C,["Compact","Comfortable","Spacious"],"UI"),
                ("high_contrast","High contrast","Strengthen text contrast.",T,[],"UI"),
                ("large_text","Larger text","Increase text size for readability.",T,[],"UI"),
                ("compact_server_cards","Compact server cards","Reduce spacing in location rows.",T,[],"UI"),
                ("show_mascot","Show Vibi mascot","Show or hide the mascot card.",T,[],"UI"),
                ("show_status_bar","Show status indicator","Show or hide the small status indicator.",T,[],"UI"),
                ("remember_window_size","Remember window size","Restore the previous window geometry.",T,[],"UI"),
                ("keep_on_top","Keep window on top","Keep the app above other windows.",T,[],"UI"),
                ("compact_mode","Compact interface","Use tighter layout where supported.",T,[],"UI"),
            ]),
            ("Location browser", [
                ("default_location_region","Default region","Region selected whenever Locations opens.",C,regions,"UI"),
                ("location_results_per_page","Locations per page","Show fewer rows for lighter rendering.",C,["12","24","48","All"],"UI"),
                ("location_search_delay","Location search responsiveness","Choose instant matching or a gentler update cadence on slower PCs.",C,["Fast","Balanced","Power saver"],"Performance"),
                ("server_sort_order","Sort locations","Choose the ordering of the location catalogue.",C,
                 ["Recommended","City A–Z","Country A–Z","Region","Code","Recently used"],"UI"),
                ("favorite_servers_first","Favorites first","Move favorite locations to the top.",T,[],"UI"),
                ("remember_location_search","Remember search","Restore the last location query next time.",T,[],"Local"),
                ("location_show_flags","Country flags","Show flags beside city names.",T,[],"UI"),
                ("location_show_country","Country name","Show country in the location subtitle.",T,[],"UI"),
                ("location_show_server_code","Location code","Show the catalogue location code.",T,[],"UI"),
                ("location_show_region","Region label","Add the broader region to each row.",T,[],"UI"),
                ("search_server_code","Search by code","Include location codes in search matching.",T,[],"UI"),
                ("location_return_to_overview","Return to Overview after selection","Navigate home after picking a location.",T,[],"UI"),
                ("confirm_server_switch","Confirm location switch","Ask before changing locations while demo-connected.",T,[],"UI"),
                ("show_copy_location_button","Copy location details","Add a button to copy city, code and coordinates.",T,[],"UI"),
                ("show_ping","Show latency badge","Show catalogue latency values (demo only).",T,[],"UI"),
                ("remember_last_server","Remember last location","Restore the previously selected catalogue city.",T,[],"Local"),
                ("remember_favorites","Remember favorites","Keep favorite locations between launches.",T,[],"Local"),
            ]),
            ("Globe controls", [
                ("globe_rotate_sensitivity","Rotation sensitivity","Set how quickly drag rotates the globe.",C,["Low","Normal","High"],"UI"),
                ("globe_zoom_sensitivity","Zoom sensitivity","Set the wheel and zoom-button step size.",C,["Low","Normal","High"],"UI"),
                ("globe_auto_rotate","Auto-rotate globe","Slowly rotate the globe while Locations is open.",T,[],"UI"),
                ("globe_auto_rotate_speed","Auto-rotate speed","Choose rotation speed.",C,["Slow","Normal","Fast"],"UI"),
                ("globe_marker_size","Marker size","Adjust city markers on the globe.",C,["Small","Normal","Large"],"UI"),
                ("globe_show_coordinates","Show coordinates","Include latitude and longitude in the selected-city label.",T,[],"UI"),
                ("globe_show_stars","Background stars","Show the subtle stars outside the globe.",T,[],"UI"),
                ("globe_show_equator","Equator highlight","Show a highlighted equator line.",T,[],"UI"),
                ("show_server_nodes","Secondary server nodes","Show additional network points on the overview map.",T,[],"UI"),
                ("show_home_marker","Origin marker","Show the origin marker on the overview map.",T,[],"UI"),
                ("globe_simplified_drag","Fast drag preview","Render fewer map details during dragging to reduce lag.",T,[],"Performance"),
                ("globe_remember_view","Remember globe view","Restore longitude, latitude and zoom on next launch.",T,[],"Local"),
                ("globe_center_selected","Center selected location","Recenter the globe when selecting from the list.",T,[],"UI"),
                ("map_dots","Dotted land","Show the globe's dotted land texture.",T,[],"UI"),
                ("map_grid","Coordinate grid","Show latitude and longitude lines.",T,[],"UI"),
                ("map_routes","Route line","Show an illustrative path to the selected location.",T,[],"UI"),
                ("map_glow","Glow effects","Show the globe's outer glow and marker halos.",T,[],"UI"),
                ("map_labels","Map labels","Show the title and selected location label.",T,[],"UI"),
                ("map_density","Map detail","Choose the detail density for the globe texture.",C,["Low","Normal","High"],"UI"),
                ("map_zoom","Default map zoom","Choose the initial globe zoom.",C,["80%","100%","120%"],"UI"),
            ]),
            ("Performance", [
                ("animations","Animations","Enable subtle motion and connect-button animation.",T,[],"UI"),
                ("reduced_motion","Reduce motion","Limit motion for comfort and responsiveness.",T,[],"UI"),
                ("animation_quality","Animation quality","Choose how frequently visual animations refresh.",C,["Economy","Balanced","Smooth"],"UI"),
                ("cpu_saver","CPU saver","Use a slower refresh cadence.",T,[],"UI"),
                ("traffic_graph","Traffic graph","Show or hide the demo graph.",T,[],"UI"),
                ("show_speed_stats","Speed statistics","Show the demo throughput figures.",T,[],"UI"),
                ("show_server_load","Server load indicator","Show or hide the placeholder load display.",T,[],"UI"),
                ("show_session_timer","Session timer","Show or hide the demo session timer.",T,[],"UI"),
                ("scroll_sensitivity","Scroll sensitivity","Set scrolling speed in long settings pages.",C,["Low","Normal","High"],"UI"),
                ("auto_save_settings","Auto-save settings","Save changes immediately.",T,[],"Local"),
                ("keyboard_shortcuts","Keyboard shortcuts","Enable Ctrl+1…9, Ctrl+L and Escape shortcuts.",T,[],"UI"),
            ]),
            ("Local privacy", [
                ("save_server_history","Recent locations","Keep the recent location history locally.",T,[],"Local"),
                ("hide_ip_address","Hide IP label","Avoid displaying a real IP in the UI (lookup is not connected).",T,[],"UI"),
                ("confirm_exit","Confirm on exit","Ask before closing the app.",T,[],"UI"),
                ("dashboard_start_page","Startup page","Choose which main page opens first.",C,["Overview","Locations","Security"],"UI"),
                ("local_activity_history","Local activity history","Keep recent UI actions on this device only; nothing is uploaded.",T,[],"Local"),
            ]),
            ("Connection preferences · advanced", [
                ("preferred_protocol","Preferred protocol","Preference only; requires a real VPN backend.",C,["Automatic","WireGuard","OpenVPN","IKEv2"],"Backend"),
                ("auto_connect","Auto-connect","Requires the VPN service.",T,[],"Backend"),
                ("auto_best_server","Choose fastest location","Requires measured latency and a server API.",T,[],"Backend"),
                ("reconnect_on_drop","Reconnect after interruption","Requires a real tunnel monitor.",T,[],"Backend"),
                ("protocol_fallback","Protocol fallback","Requires multiple configured protocols.",T,[],"Backend"),
                ("minimize_on_connect","Minimize after connection","Requires real tunnel state.",T,[],"Backend"),
                ("ask_before_disconnect","Confirm disconnect","Ask before disconnecting the demo state.",T,[],"UI"),
            ]),
            ("Network protection · advanced", [
                ("kill_switch","Kill Switch","Requires OS firewall integration; this setting alone does not block traffic.",T,[],"Backend"),
                ("dns_protection","DNS leak protection","Requires DNS routing through the real tunnel.",T,[],"Backend"),
                ("ipv6_protection","IPv6 leak protection","Requires adapter/firewall integration.",T,[],"Backend"),
                ("malware_block","Malware blocking","Requires a trusted filter list and DNS/network integration.",T,[],"Backend"),
                ("ad_block","Ad blocking","Requires DNS filtering.",T,[],"Backend"),
                ("tracker_block","Tracker blocking","Requires DNS filtering.",T,[],"Backend"),
                ("split_tunneling","Split tunneling","Requires per-application routing.",T,[],"Backend"),
                ("allow_lan","Allow local network","Requires tunnel/firewall policy integration.",T,[],"Backend"),
                ("dns_mode","DNS mode","Actual DNS changes require backend integration.",C,["Automatic","DNS-over-HTTPS","Custom DNS"],"Backend"),
                ("custom_dns","Custom DNS address","Stored locally; not applied to system DNS.",X,[],"Backend"),
                ("block_suspicious","Block suspicious domains","Requires threat feeds and DNS filtering.",T,[],"Backend"),
                ("secure_dns_fallback","Secure DNS fallback","Requires configured secure DNS resolvers.",T,[],"Backend"),
            ]),
            ("Telegram trial · advanced", [
                ("telegram_bot_username","Telegram bot username","Public username only, without @. Key issuance and validation must be implemented by your bot/backend.",X,[],"Backend"),
            ]),
        ]

    # ------------------------ Helpers --------------------------------------
    def _build_styles(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TEntry", fieldbackground=PANEL2, foreground=TEXT,
                        bordercolor=BORDER, insertcolor=TEXT, padding=9)
        style.configure("TCombobox", fieldbackground=PANEL2, background=PANEL2,
                        foreground=TEXT, arrowcolor=BLUE, padding=7)
        style.map("TCombobox", fieldbackground=[("readonly", PANEL2)],
                  foreground=[("readonly", TEXT)])

    def panel(self, parent, bg=None, border=None):
        bg = bg or PANEL
        border = border or BORDER
        # Subtle double-edge treatment gives cards depth without heavy shadows or redraw cost.
        return tk.Frame(parent, bg=bg, highlightthickness=1, highlightbackground=border,
                        highlightcolor=border, bd=0, relief="flat")

    def _scaled_font_size(self, size):
        prefs = getattr(self, "prefs", {})
        size_factor = {"Small": .90, "Standard": 1.0, "Large": 1.12, "Extra Large": 1.25}.get(prefs.get("font_size"), 1.0)
        scale_factor = {"90%": .90, "100%": 1.0, "110%": 1.10, "120%": 1.20}.get(prefs.get("ui_scale"), 1.0)
        if prefs.get("large_text"):
            size_factor *= 1.10
        return max(7, round(size * size_factor * scale_factor))

    def _font_family(self):
        prefs = getattr(self, "prefs", {})
        return prefs.get("font_family", tkfont.nametofont("TkDefaultFont").actual("family"))

    def label(self, parent, text, size=10, color=None, bold=False, bg=None, **kw):
        weight = "bold" if bold else "normal"
        widget = tk.Label(parent, text=text,
                          font=(self._font_family(), self._scaled_font_size(size), weight),
                          fg=color or TEXT, bg=bg or parent.cget("bg"), **kw)
        if hasattr(self, "_base_fonts"):
            self._base_fonts[str(widget)] = (int(size), weight, "roman", 0, 0)
        return widget

    def button(self, parent, text, command, bg=None, fg=None, hover=None,
               padx=12, pady=8, font_size=9, anchor="center"):
        """Single consistent pill-button system used across all product pages."""
        bg = bg or PANEL2
        fg = fg or TEXT
        hover = hover or PANEL_HOVER
        widget = RoundedButton(parent, text=text, command=command, bg=bg, fg=fg, hover=hover,
                               padx=padx, pady=pady, font_size=self._scaled_font_size(font_size),
                               cursor="hand2", anchor=anchor)
        if hasattr(self, "_base_fonts"):
            self._base_fonts[str(widget)] = (int(font_size), "bold", "roman", 0, 0)
        return widget

    def _clear_content(self):
        for child in self.content.winfo_children():
            child.destroy()

    # ------------------------ Main shell -----------------------------------
    def _build_layout(self):
        self.configure(bg=BG)
        self.shell = tk.Frame(self, bg=BG)
        self.shell.pack(fill="both", expand=True, padx=12, pady=12)

        # Full-width editorial sidebar: no ambiguous icon-only navigation.
        self.sidebar = tk.Frame(self.shell, bg=SIDEBAR, width=214,
                                highlightthickness=1, highlightbackground=BORDER)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        brand = tk.Frame(self.sidebar, bg=SIDEBAR)
        brand.pack(fill="x", padx=17, pady=(18, 22))
        logo = tk.Canvas(brand, width=46, height=46, bg=SIDEBAR, highlightthickness=0)
        self.logo_canvas = logo
        logo.pack(side="left")
        logo.create_oval(3, 3, 43, 43, fill=BLUE_DARK, outline=CYAN, width=1.6)
        logo.create_oval(9, 9, 37, 37, outline="#31576B", width=1)
        logo.create_text(23, 23, text="V", fill=BLUE_BRIGHT, font=("Segoe UI", 19, "bold"))
        brand_text = tk.Frame(brand, bg=SIDEBAR)
        brand_text.pack(side="left", padx=(10, 0), fill="y")
        self.label(brand_text, "VIBE VPN", 13, TEXT, True, bg=SIDEBAR).pack(anchor="w", pady=(5, 0))
        self.label(brand_text, "AURORA EDITION", 7, CYAN, True, bg=SIDEBAR).pack(anchor="w", pady=(2, 0))

        self.label(self.sidebar, "WORKSPACE", 7, DIM, True, bg=SIDEBAR).pack(anchor="w", padx=20, pady=(0, 7))
        self.nav_buttons = {}
        self.nav_indicators = {}
        nav_groups = [
            ("⌂", "Overview", "Your connection"),
            ("◎", "Locations", "Global network"),
            ("◇", "Security", "Privacy center"),
            ("◷", "Activity", "Recent actions"),
            ("⌘", "Diagnostics", "System health"),
        ]
        for glyph, name, hint in nav_groups:
            slot = tk.Frame(self.sidebar, bg=SIDEBAR, height=45)
            slot.pack(fill="x", padx=10, pady=2)
            slot.pack_propagate(False)
            indicator = tk.Frame(slot, bg=BLUE if name == "Overview" else SIDEBAR, width=3)
            indicator.pack(side="left", fill="y", padx=(0, 7))
            self.nav_indicators[name] = indicator
            button = RoundedButton(slot, text=f"{glyph}    {name}",
                                   command=lambda n=name: self._navigate(n),
                                   bg=BLUE_DARK if name == "Overview" else SIDEBAR,
                                   fg=BLUE_BRIGHT if name == "Overview" else MUTED,
                                   hover=PANEL2, padx=12, pady=8, font_size=10, anchor="w")
            button.pack(side="left", fill="both", expand=True)
            self.nav_buttons[name] = button

        self.label(self.sidebar, "PERSONAL", 7, DIM, True, bg=SIDEBAR).pack(anchor="w", padx=20, pady=(18, 7))
        for glyph, name, hint in [
            ("◉", "Profile", "Account"), ("✦", "Customize", "Themes & identity"),
            ("♙", "Plans", "Membership"), ("⚙", "Settings", "Preferences"),
        ]:
            slot = tk.Frame(self.sidebar, bg=SIDEBAR, height=43)
            slot.pack(fill="x", padx=10, pady=2)
            slot.pack_propagate(False)
            indicator = tk.Frame(slot, bg=SIDEBAR, width=3)
            indicator.pack(side="left", fill="y", padx=(0, 7))
            self.nav_indicators[name] = indicator
            button = RoundedButton(slot, text=f"{glyph}    {name}",
                                   command=lambda n=name: self._navigate(n),
                                   bg=SIDEBAR, fg=MUTED, hover=PANEL2,
                                   padx=12, pady=7, font_size=10, anchor="w")
            button.pack(side="left", fill="both", expand=True)
            self.nav_buttons[name] = button

        sidebar_bottom = tk.Frame(self.sidebar, bg=SIDEBAR)
        sidebar_bottom.pack(side="bottom", fill="x", padx=14, pady=15)
        tk.Frame(sidebar_bottom, bg=BORDER, height=1).pack(fill="x", pady=(0, 12))
        mascot_row = tk.Frame(sidebar_bottom, bg=PANEL)
        mascot_row.pack(fill="x")
        mini_mascot = tk.Canvas(mascot_row, width=36, height=36, bg=PANEL, highlightthickness=0)
        mini_mascot.pack(side="left", padx=7, pady=7)
        mini_mascot.create_oval(3, 3, 33, 33, fill=BLUE_DARK, outline=CYAN, width=1)
        mini_mascot.create_text(18, 18, text="✦", fill=BLUE_BRIGHT, font=("Segoe UI Symbol", 15, "bold"))
        self.label(mascot_row, "Vibi assistant", 8, TEXT, True, bg=PANEL).pack(side="left", anchor="w")
        self.label(sidebar_bottom, "●  UI preview · VPN engine not connected", 7, ORANGE,
                   bg=SIDEBAR, wraplength=175, justify="left").pack(anchor="w", pady=(10, 0))

        self.workspace = tk.Frame(self.shell, bg=BG)
        self.workspace.pack(side="left", fill="both", expand=True, padx=(16, 0))
        self.topbar = tk.Frame(self.workspace, bg=BG, height=70)
        self.topbar.pack(fill="x", pady=(3, 12))
        self.topbar.pack_propagate(False)
        left = tk.Frame(self.topbar, bg=BG)
        left.pack(side="left", fill="y")
        self.page_title = self.label(left, "Overview", 22, TEXT, True, bg=BG)
        self.page_title.pack(anchor="w", pady=(1, 0))
        self.page_subtitle = self.label(left, "Your connection, at a glance.", 9, MUTED, bg=BG)
        self.page_subtitle.pack(anchor="w", pady=(3, 0))
        self.top_right = tk.Frame(self.topbar, bg=BG)
        self.top_right.pack(side="right", pady=(7, 0))
        self.preview_chip = tk.Frame(self.top_right, bg=PANEL, highlightthickness=1, highlightbackground=BORDER)
        self.preview_chip.pack(side="left", padx=(0, 10))
        self.label(self.preview_chip, "●  PREVIEW BUILD", 8, CYAN, True, bg=PANEL).pack(padx=11, pady=8)
        avatar_btn = self.button(self.top_right, "V  My profile  ↗", lambda: self._navigate("Profile"),
                                 bg=PANEL2, fg=TEXT, hover=PANEL_HOVER, padx=12, pady=8, font_size=8)
        avatar_btn.pack(side="left")
        tk.Frame(self.workspace, bg=BORDER, height=1).pack(fill="x", pady=(0, 14))

        self.page_host = tk.Frame(self.workspace, bg=BG)
        self.page_host.pack(fill="both", expand=True)
        self.content = None

    def _activate_page(self, page_key):
        """Show a previously built page instead of destroying/recreating its widgets."""
        if self._visible_page == page_key and page_key in self._page_frames:
            self.content = self._page_frames[page_key]
            return
        if self._visible_page in self._page_frames:
            self._page_frames[self._visible_page].pack_forget()
        frame = self._page_frames.get(page_key)
        if frame is None:
            frame = tk.Frame(self.page_host, bg=BG)
            self._page_frames[page_key] = frame
        frame.pack(fill="both", expand=True)
        self.content = frame
        self._visible_page = page_key

    def _navigate(self, name):
        page_map = {
            "Overview": "overview", "Locations": "locations", "Security": "security",
            "Activity": "activity", "Diagnostics": "diagnostics",
            "Profile": "profile", "Customize": "customize", "Plans": "plans",
            "Settings": "settings"
        }
        if name not in page_map:
            return
        old_page = self._visible_page
        target_page = page_map[name]
        if old_page and old_page != target_page:
            self._cancel_page_jobs(old_page)
        self.active_nav = name
        self.page = target_page
        self.page_title.configure(text=name)
        descriptions = {
            "Overview":"Your connection, at a glance.", "Locations":"Find your next point on the globe.",
            "Security":"Privacy tools and protection status.", "Activity":"A local timeline of app actions.",
            "Diagnostics":"Inspect performance and cache health.", "Profile":"Your Vibe identity and plan.",
            "Customize":"Make the interface feel like yours.", "Plans":"Memberships and trial access.",
            "Settings":"Fine-tune the Vibe experience.",
        }
        if hasattr(self, "page_subtitle"):
            self.page_subtitle.configure(text=descriptions.get(name, "Your private workspace."))
        for nav_name, button in self.nav_buttons.items():
            selected = nav_name == name
            button.configure(bg=BLUE_DARK if selected else SIDEBAR,
                             fg=BLUE_BRIGHT if selected else MUTED,
                             font=("Segoe UI", 10, "bold" if selected else "normal"))
            indicator = getattr(self, "nav_indicators", {}).get(nav_name)
            if indicator is not None:
                indicator.configure(bg=CYAN if selected else SIDEBAR)
        self._activate_page(self.page)
        renderers = {
            "overview": self._render_overview,
            "locations": self._render_locations,
            "security": self._render_security,
            "activity": self._render_activity,
            "diagnostics": self._render_diagnostics,
            "profile": self._render_profile,
            "customize": self._render_customize,
            "plans": self._render_plans,
            "settings": self._render_settings,
        }
        if self.page not in self._built_pages:
            renderers[self.page]()
            self._built_pages.add(self.page)
        else:
            self._sync_page(self.page)
        self._ensure_animation_loop()

    def _cancel_canvas_jobs(self, canvas):
        if canvas is None:
            return
        key = str(canvas)
        for attr in ("_globe_redraw_jobs", "_globe_resize_jobs", "_globe_resize_preview_jobs", "_globe_settle_jobs"):
            mapping = getattr(self, attr, {})
            self._cancel_job(mapping, key)
        self._globe_last_resize_preview.pop(key, None)
        if self._globe_drag_state and self._globe_drag_state.get("canvas") == canvas:
            self._globe_drag_state = None
        try:
            canvas.configure(cursor="hand2")
        except tk.TclError:
            pass

    def _cancel_page_jobs(self, page_key):
        """Cancel queued work owned by a page before that page is hidden."""
        if page_key == "locations":
            if self._location_filter_job:
                try: self.after_cancel(self._location_filter_job)
                except tk.TclError: pass
                self._location_filter_job = None
            self._cancel_canvas_jobs(getattr(self, "geo_canvas", None))
            job = getattr(self, "_location_render_job", None)
            if job is not None:
                try: self.after_cancel(job)
                except tk.TclError: pass
                self._location_render_job = None
            if getattr(self, "_location_render_queue", []):
                self._location_render_queue = []
                self._last_location_render_signature = None
        elif page_key == "overview":
            self._cancel_canvas_jobs(getattr(self, "map_canvas", None))
        elif page_key == "settings":
            for attr in ("_settings_build_job", "_settings_filter_job"):
                job = getattr(self, attr, None)
                if job is not None:
                    try: self.after_cancel(job)
                    except tk.TclError: pass
                    setattr(self, attr, None)
        elif page_key == "plans":
            job = getattr(self, "_plans_build_job", None)
            if job is not None:
                try: self.after_cancel(job)
                except tk.TclError: pass
                self._plans_build_job = None
        elif page_key == "customize":
            job = getattr(self, "_customize_build_job", None)
            if job is not None:
                try: self.after_cancel(job)
                except tk.TclError: pass
                self._customize_build_job = None
        elif page_key == "diagnostics":
            job = getattr(self, "_diagnostics_build_job", None)
            if job is not None:
                try: self.after_cancel(job)
                except tk.TclError: pass
                self._diagnostics_build_job = None
        elif page_key == "activity":
            job = getattr(self, "_activity_render_job", None)
            if job is not None:
                try: self.after_cancel(job)
                except tk.TclError: pass
                self._activity_render_job = None

    def _sync_page(self, page_key):
        """Update only dynamic widgets. Never rebuild an entire page for state changes."""
        if page_key == "overview":
            if hasattr(self, "selected_name") and self.selected_name.winfo_exists():
                server = SERVERS[self.selected]
                self.selected_name.configure(text=server["country"])
                self.selected_city.configure(text=server["city"] + " · " + server["code"])
                if hasattr(self, "selected_flag"):
                    self.selected_flag.configure(text=server["flag"])
                if hasattr(self, "latency_value"):
                    self.latency_value.configure(text=server["ping"] if self.prefs.get("show_ping", True) else "Hidden")
                if hasattr(self, "connect_btn"):
                    self.connect_btn.configure(text="Disconnect" if self.connected else "Connect")
                if hasattr(self, "connect_hint"):
                    self.connect_hint.configure(
                        text="Demo interface · VPN engine not connected",
                        fg=ORANGE if not self.connected else YELLOW)
                self._schedule_globe_redraw(self.map_canvas, 0, quality="preview")
                self._schedule_globe_full_settle(self.map_canvas, 220)
                self._draw_connect_button()
        elif page_key == "locations":
            self._filter_servers()
            if hasattr(self, "geo_canvas") and self.geo_canvas.winfo_exists():
                self._schedule_globe_redraw(self.geo_canvas, 0, quality="preview")
                self._schedule_globe_full_settle(self.geo_canvas, 180)
        elif page_key == "profile":
            if hasattr(self, "profile_name_display"):
                self.profile_name_display.configure(text=self.profile_name)
                self.profile_email_display.configure(text=self.profile_email)
                self.profile_plan_display.configure(text=f"VIBE MEMBER  ·  {self.active_plan.upper()} PLAN")
                self.profile_avatar_canvas.delete("all")
                self.profile_avatar_canvas.create_oval(4, 4, 72, 72, fill=BLUE_DARK,
                                                       outline=self.profile_accent, width=2)
                self.profile_avatar_canvas.create_text(38, 38, text=(self.profile_avatar or "V")[:2].upper(),
                                                       fill=BLUE_BRIGHT, font=("Segoe UI", 23, "bold"))
                if hasattr(self, "profile_plan_value"):
                    self.profile_plan_value.configure(text=self.active_plan)
        elif page_key == "plans":
            for plan_name, button in getattr(self, "plan_buttons", {}).items():
                is_active = plan_name == self.active_plan
                button.configure(text="Current plan" if is_active else "Choose " + plan_name)
                button.configure(bg=(GREEN if is_active else PANEL2),
                                 fg=("#111821" if is_active else TEXT))
        elif page_key == "activity":
            if self._activity_view_signature != self._current_activity_signature():
                self._refresh_activity_view()
            else:
                self._schedule_activity_render(initial_delay=1)
        elif page_key == "diagnostics":
            self._schedule_diagnostics_build(initial_delay=1)
        elif page_key == "customize":
            self._schedule_customize_build(initial_delay=1)
        elif page_key == "plans":
            self._schedule_plan_cards(initial_delay=1)
        elif page_key == "settings":
            self._schedule_settings_build(initial_delay=1)

    # ------------------------ Overview ------------------------------------
    def _render_overview(self):
        """Premium dashboard: globe + connect card, followed by compact insight cards."""
        self._clear_content()
        self.content.configure(bg=BG)

        # A compact welcome strip gives the page an editorial, branded hierarchy.
        welcome = self.panel(self.content, BG2, BORDER)
        welcome.pack(fill="x", pady=(0, 10))
        welcome_inner = tk.Frame(welcome, bg=BG2)
        welcome_inner.pack(fill="x", padx=16, pady=9)
        welcome_copy = tk.Frame(welcome_inner, bg=BG2)
        welcome_copy.pack(side="left", fill="x", expand=True)
        self.label(welcome_copy, "V I B E   /   A U R O R A   N E T W O R K", 7, CYAN, True, bg=BG2).pack(anchor="w")
        self.label(welcome_copy, "Your world. Your pace.", 13, TEXT, True, bg=BG2).pack(anchor="w", pady=(2, 0))
        self.label(welcome_copy, "A calm, clear view of your selected location and app state.", 8, MUTED, bg=BG2).pack(anchor="w", pady=(2, 0))
        self.button(welcome_inner, "Explore locations  ↗", lambda: self._navigate("Locations"),
                    bg=BLUE_DARK, fg=BLUE_BRIGHT, hover=PANEL_HOVER,
                    padx=13, pady=8, font_size=8).pack(side="right", padx=(10, 0))

        main = tk.Frame(self.content, bg=BG)
        main.pack(fill="both", expand=True)
        main.grid_columnconfigure(0, weight=7, uniform="hero")
        main.grid_columnconfigure(1, weight=4, uniform="hero")
        main.grid_rowconfigure(0, weight=1)

        # LEFT: large globe card with small toolbar.
        left = tk.Frame(main, bg=BG)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 9))
        map_card = self.panel(left, BG2, BORDER)
        map_card.pack(fill="both", expand=True)
        map_head = tk.Frame(map_card, bg=BG2)
        map_head.pack(fill="x", padx=15, pady=(12, 7))
        mh_left = tk.Frame(map_head, bg=BG2)
        mh_left.pack(side="left", fill="x", expand=True)
        self.label(mh_left, "GLOBAL NETWORK", 8, MUTED, True, bg=BG2).pack(anchor="w")
        self.label(mh_left, "Rotate the globe · choose a destination", 8, DIM, bg=BG2).pack(anchor="w", pady=(3, 0))
        mh_right = tk.Frame(map_head, bg=BG2)
        mh_right.pack(side="right")
        self.map_status = self.label(mh_right, "●  " + ("CONNECTED" if self.connected else "NETWORK PREVIEW"),
                                     7, GREEN if self.connected else BLUE, True, bg=BG2)
        self.map_status.pack(side="left", padx=(0, 7))
        self.button(mh_right, "Reset view", self._reset_globe_view,
                    bg=PANEL2, fg=MUTED, hover=PANEL_HOVER, padx=8, pady=5, font_size=7).pack(side="right")
        self.map_canvas = tk.Canvas(map_card, bg=BG2, highlightthickness=0, height=300, bd=0)
        self.map_canvas.pack(fill="both", expand=True, padx=7, pady=(0, 7))
        self.map_canvas.bind("<Configure>", self._schedule_map_redraw)
        self._bind_globe_gestures(self.map_canvas)
        self._schedule_globe_redraw(self.map_canvas, 45, quality="preview")

        # A small throughput rail sits directly under the globe rather than consuming another column.
        speeds = self.panel(left, PANEL, BORDER)
        speeds.pack(fill="x", pady=(8, 0))
        speed_inner = tk.Frame(speeds, bg=PANEL)
        speed_inner.pack(fill="x", padx=14, pady=9)
        speed_title = tk.Frame(speed_inner, bg=PANEL)
        speed_title.pack(side="left", fill="x", expand=True)
        self.label(speed_title, "TRAFFIC PREVIEW", 7, MUTED, True, bg=PANEL).pack(anchor="w")
        self.label(speed_title, "Sample UI values · not live traffic", 7, DIM, bg=PANEL).pack(anchor="w", pady=(2, 0))
        speed_numbers = tk.Frame(speed_inner, bg=PANEL)
        speed_numbers.pack(side="right")
        self.label(speed_numbers, "↑", 13, GREEN, True, bg=PANEL).pack(side="left")
        self.up_label = self.label(speed_numbers, "0.0 MB/s", 9, TEXT, True, bg=PANEL)
        self.up_label.pack(side="left", padx=(3, 12))
        self.label(speed_numbers, "↓", 13, BLUE, True, bg=PANEL).pack(side="left")
        self.down_label = self.label(speed_numbers, "0.0 MB/s", 9, TEXT, True, bg=PANEL)
        self.down_label.pack(side="left", padx=(3, 0))

        # RIGHT: one intentional connection card. Smaller auxiliary cards sit below across the page.
        right = tk.Frame(main, bg=BG)
        right.grid(row=0, column=1, sticky="nsew")
        hero = self.panel(right, PANEL, BORDER)
        hero.pack(fill="both", expand=True)
        pad = tk.Frame(hero, bg=PANEL)
        pad.pack(fill="both", expand=True, padx=15, pady=14)
        title_row = tk.Frame(pad, bg=PANEL)
        title_row.pack(fill="x")
        title_copy = tk.Frame(title_row, bg=PANEL)
        title_copy.pack(side="left", fill="x", expand=True)
        self.label(title_copy, "Your private space", 15, TEXT, True, bg=PANEL).pack(anchor="w")
        self.label(title_copy, "One click away from your next vibe.", 8, MUTED, bg=PANEL).pack(anchor="w", pady=(4, 0))
        self.label(title_row, "✦", 17, CYAN, True, bg=PANEL).pack(side="right", padx=(5, 0))

        selected = SERVERS[self.selected]
        self.server_pick = tk.Frame(pad, bg=PANEL2, highlightthickness=1, highlightbackground=BORDER)
        self.server_pick.pack(fill="x", pady=(13, 0))
        self.selected_flag = self.label(self.server_pick, selected["flag"], 19, TEXT, bg=PANEL2)
        self.selected_flag.pack(side="left", padx=(11, 8), pady=8)
        stext = tk.Frame(self.server_pick, bg=PANEL2)
        stext.pack(side="left", fill="x", expand=True, pady=8)
        self.selected_name = self.label(stext, selected["country"], 9, TEXT, True, bg=PANEL2)
        self.selected_name.pack(anchor="w")
        self.selected_city = self.label(stext, selected["city"] + " · " + selected["code"], 7, MUTED, bg=PANEL2)
        self.selected_city.pack(anchor="w", pady=(2, 0))
        self.button(self.server_pick, "Change", lambda: self._navigate("Locations"),
                    bg=PANEL2, fg=BLUE_BRIGHT, hover=PANEL_HOVER,
                    padx=9, pady=7, font_size=8).pack(side="right", padx=7)

        self.connect_canvas = tk.Canvas(pad, width=190, height=150, bg=PANEL, highlightthickness=0,
                                        cursor="hand2", bd=0)
        self.connect_canvas.pack(pady=(3, 0))
        self.connect_canvas.bind("<Button-1>", lambda e: self._toggle_connection())
        self.connect_btn = self.button(pad, "Disconnect" if self.connected else "Connect",
                    self._toggle_connection, bg=BLUE, fg="#081927", hover=BLUE_BRIGHT,
                    padx=18, pady=10, font_size=10)
        self.connect_btn.pack(fill="x", pady=(0, 0))
        self.connect_hint = self.label(pad, "PREVIEW ONLY · VPN engine not connected", 7, ORANGE, True, bg=PANEL)
        self.connect_hint.pack(pady=(7, 0))

        actions = tk.Frame(pad, bg=PANEL)
        actions.pack(fill="x", pady=(11, 0))
        self.button(actions, "Fastest*", self._select_lowest_demo_ping,
                    bg=PANEL2, fg=CYAN, hover=PANEL_HOVER, padx=7, pady=6, font_size=7).pack(side="left", fill="x", expand=True, padx=(0, 4))
        self.button(actions, "Recent", self._select_recent_location,
                    bg=PANEL2, fg=TEXT, hover=PANEL_HOVER, padx=7, pady=6, font_size=7).pack(side="left", fill="x", expand=True, padx=3)
        self.button(actions, "Favorite", self._select_favorite_location,
                    bg=PANEL2, fg=ORANGE, hover=PANEL_HOVER, padx=7, pady=6, font_size=7).pack(side="left", fill="x", expand=True, padx=(4, 0))

        # LOWER STRIP: readable compact data cards instead of a stack that overflows short screens.
        lower = tk.Frame(self.content, bg=BG)
        lower.pack(fill="x", pady=(9, 0))
        lower.grid_columnconfigure(0, weight=4, uniform="lower")
        lower.grid_columnconfigure(1, weight=4, uniform="lower")
        lower.grid_columnconfigure(2, weight=3, uniform="lower")

        session = self.panel(lower, PANEL, BORDER)
        session.grid(row=0, column=0, sticky="nsew", padx=(0, 7))
        sp = tk.Frame(session, bg=PANEL)
        sp.pack(fill="both", expand=True, padx=12, pady=10)
        self.label(sp, "SESSION SNAPSHOT", 7, MUTED, True, bg=PANEL).pack(anchor="w")
        statrow = tk.Frame(sp, bg=PANEL)
        statrow.pack(fill="x", pady=(8, 0))
        self.latency_value = self._mini_stat(statrow, "Latency", selected["ping"], "sample value")
        self._mini_stat(statrow, "Protocol", "—", "not configured")
        self._mini_stat(statrow, "Devices", "1 / 5", "preview plan")

        privacy = self.panel(lower, PANEL, BORDER)
        privacy.grid(row=0, column=1, sticky="nsew", padx=4)
        pp = tk.Frame(privacy, bg=PANEL)
        pp.pack(fill="both", expand=True, padx=12, pady=10)
        self.label(pp, "VIBE PRIVACY CENTER", 7, MUTED, True, bg=PANEL).pack(anchor="w")
        privacy_row = tk.Frame(pp, bg=PANEL)
        privacy_row.pack(fill="x", pady=(9, 0))
        self.label(privacy_row, "◇", 15, CYAN, True, bg=PANEL).pack(side="left", padx=(0, 7))
        privacy_copy = tk.Frame(privacy_row, bg=PANEL)
        privacy_copy.pack(side="left", fill="x", expand=True)
        self.label(privacy_copy, "Security controls", 9, TEXT, True, bg=PANEL).pack(anchor="w")
        self.label(privacy_copy, "Backend not connected", 7, ORANGE, bg=PANEL).pack(anchor="w", pady=(2, 0))
        self.button(pp, "Open security center  →", lambda: self._navigate("Security"),
                    bg=PANEL2, fg=BLUE_BRIGHT, hover=PANEL_HOVER,
                    padx=8, pady=6, font_size=7).pack(anchor="w", pady=(7, 0))

        mascot_card = self.panel(lower, BG2, BORDER)
        self.mascot_card = mascot_card
        if self.prefs.get("show_mascot", True):
            mascot_card.grid(row=0, column=2, sticky="nsew", padx=(7, 0))
        mascot_row = tk.Frame(mascot_card, bg=BG2)
        mascot_row.pack(fill="both", expand=True, padx=10, pady=8)
        mascot = tk.Canvas(mascot_row, width=54, height=52, bg=BG2, highlightthickness=0)
        mascot.pack(side="left", padx=(0, 7))
        self._draw_mascot(mascot, small=True)
        mascot_text = tk.Frame(mascot_row, bg=BG2)
        mascot_text.pack(side="left", fill="x", expand=True)
        self.label(mascot_text, "Meet Vibi", 9, TEXT, True, bg=BG2).pack(anchor="w")
        self.label(mascot_text, "Your tiny guide.", 7, MUTED, bg=BG2, wraplength=120).pack(anchor="w", pady=(3, 0))
        self._draw_connect_button()

    def _mini_stat(self, parent, title, value, sub):
        item = tk.Frame(parent, bg=PANEL)
        item.pack(side="left", fill="x", expand=True, padx=(0, 5))
        self.label(item, title, 8, MUTED, bg=PANEL).pack(anchor="w")
        value_label = self.label(item, value, 10, TEXT, True, bg=PANEL)
        value_label.pack(anchor="w", pady=(5, 2))
        self.label(item, sub, 7, DIM, bg=PANEL).pack(anchor="w")
        return value_label

    def _on_window_configure(self, event):
        """Suspend decorative animation during interactive top-level resizing."""
        if getattr(event, "widget", None) is not self or self._closing:
            return
        self._window_resize_active = True
        if self._window_resize_job is not None:
            try:
                self.after_cancel(self._window_resize_job)
            except tk.TclError:
                pass
        try:
            self._window_resize_job = self.after(500, self._on_window_resize_settled)
        except tk.TclError:
            self._window_resize_job = None

    def _on_window_resize_settled(self):
        self._window_resize_job = None
        self._window_resize_active = False
        # Trigger a crisp render from the top-level debounce as well. Canvas Configure
        # events can settle a little earlier/later than the window manager's events.
        active_canvas = None
        if self.page == "overview":
            active_canvas = getattr(self, "map_canvas", None)
        elif self.page == "locations":
            active_canvas = getattr(self, "geo_canvas", None)
        if active_canvas is not None and active_canvas.winfo_exists():
            # Cancel the canvas-level idle render so only one final high-detail frame
            # is rendered after the top-level and canvas size changes have settled.
            self._cancel_job(self._globe_settle_jobs, str(active_canvas))
            self._schedule_globe_redraw(active_canvas, 35, quality="full")
        self._ensure_animation_loop()

    def _is_globe_canvas_active(self, canvas):
        if canvas is getattr(self, "map_canvas", None):
            return self.page == "overview"
        if canvas is getattr(self, "geo_canvas", None):
            return self.page == "locations"
        return False

    def _schedule_map_redraw(self, event=None):
        """Throttle top-level resize events; scale the existing raster during drag-resize."""
        canvas = getattr(self, "map_canvas", None)
        if canvas is not None and canvas.winfo_exists():
            self._schedule_globe_resize_redraw(canvas)

    def _bind_globe_gestures(self, canvas):
        canvas.bind("<ButtonPress-1>", self._globe_press)
        canvas.bind("<B1-Motion>", self._globe_drag)
        canvas.bind("<ButtonRelease-1>", self._globe_release)
        canvas.bind("<MouseWheel>", self._globe_wheel)
        canvas.bind("<Button-4>", lambda e: self._globe_zoom_by(1.08, e.widget))
        canvas.bind("<Button-5>", lambda e: self._globe_zoom_by(0.92, e.widget))

    def _cancel_job(self, job_map, key):
        job = job_map.pop(key, None)
        if job:
            try:
                self.after_cancel(job)
            except tk.TclError:
                pass

    def _schedule_globe_redraw(self, canvas, delay=35, quality="full"):
        """Coalesce draw requests. Preview jobs are throttled, not reset on every motion event."""
        if not canvas or not canvas.winfo_exists():
            return
        key = str(canvas)
        if quality == "preview" and key in self._globe_redraw_jobs:
            return
        self._cancel_job(self._globe_redraw_jobs, key)
        try:
            self._globe_redraw_jobs[key] = self.after(
                max(0, int(delay)), lambda c=canvas, k=key, q=quality: self._run_globe_redraw(c, k, q))
        except tk.TclError:
            pass

    def _run_globe_redraw(self, canvas, key, quality="full"):
        self._globe_redraw_jobs.pop(key, None)
        if canvas.winfo_exists():
            self._draw_globe(canvas, preview=(quality == "preview"))

    def _schedule_globe_full_settle(self, canvas, delay=170):
        """After wheel zoom or resize activity stops, restore the full-detail globe."""
        if not canvas or not canvas.winfo_exists():
            return
        key = str(canvas)
        self._cancel_job(self._globe_settle_jobs, key)
        try:
            self._globe_settle_jobs[key] = self.after(
                delay, lambda c=canvas, k=key: self._run_globe_full_settle(c, k))
        except tk.TclError:
            pass

    def _run_globe_full_settle(self, canvas, key):
        self._globe_settle_jobs.pop(key, None)
        if (canvas.winfo_exists() and self._is_globe_canvas_active(canvas)
                and not self._window_resize_active
                and not (self._globe_drag_state and self._globe_drag_state.get("canvas") == canvas)):
            self._draw_globe(canvas, preview=False)

    def _schedule_globe_resize_redraw(self, canvas):
        """Resize fast: stretch the last raster during resize; render once after idle."""
        if not canvas or not canvas.winfo_exists() or not self._is_globe_canvas_active(canvas):
            return
        key = str(canvas)
        # A pending expensive projection should not run into the resize event storm.
        self._cancel_job(self._globe_redraw_jobs, key)
        now = time.monotonic()
        last = self._globe_last_resize_preview.get(key, 0.0)
        if key not in self._globe_resize_preview_jobs and now - last >= self._globe_resize_min_interval:
            try:
                self._globe_resize_preview_jobs[key] = self.after(
                    14, lambda c=canvas, k=key: self._run_globe_resize_preview(c, k))
            except tk.TclError:
                pass
        # Resizing can emit Configure for a long time while Windows tracks the edge.
        # A 520ms quiet window prevents an expensive full render in the middle of it.
        self._schedule_globe_full_settle(canvas, 520)

    def _run_globe_resize_preview(self, canvas, key):
        self._globe_resize_preview_jobs.pop(key, None)
        self._globe_last_resize_preview[key] = time.monotonic()
        if not canvas.winfo_exists() or not self._is_globe_canvas_active(canvas):
            return
        if not self._show_globe_resize_snapshot(canvas):
            # Only the very first frame has no snapshot yet; draw one low-cost frame.
            self._draw_globe(canvas, preview=True)

    def _show_globe_resize_snapshot(self, canvas):
        """Cheaply resize an existing globe raster without doing projection/dot work."""
        if not PIL_AVAILABLE or not canvas or not canvas.winfo_exists():
            return False
        key = str(canvas)
        source = self._globe_source_images.get(key)
        if source is None:
            return False
        canvas_w = max(1, canvas.winfo_width())
        canvas_h = max(1, canvas.winfo_height())
        size = (canvas_w, canvas_h)
        if self._globe_snapshot_canvas_sizes.get(key) == size:
            return True
        actual_w = max(240, canvas_w)
        actual_h = max(180, canvas_h)
        try:
            # Preserve the source aspect ratio while filling the target with a simple
            # background. It may be slightly letterboxed during live resize, then the
            # settled full render restores exact geometry.
            scale = min(actual_w / max(1, source.width), actual_h / max(1, source.height))
            target_w = max(1, int(source.width * scale))
            target_h = max(1, int(source.height * scale))
            resample = getattr(getattr(Image, "Resampling", Image), "BILINEAR")
            scaled = source.resize((target_w, target_h), resample)
            image = Image.new("RGB", (actual_w, actual_h), BG2)
            left = (actual_w - target_w) // 2
            top = (actual_h - target_h) // 2
            image.paste(scaled, (left, top))
            photo = ImageTk.PhotoImage(image)
            item = self._globe_image_items.get(key)
            if item is None or not canvas.type(item):
                item = canvas.create_image(0, 0, image=photo, anchor="nw", tags=("globe-raster",))
                self._globe_image_items[key] = item
            else:
                canvas.itemconfigure(item, image=photo)
                canvas.coords(item, 0, 0)
                canvas.tag_lower(item)
            self._globe_photo_refs[key] = photo
            self._globe_snapshot_paste_boxes[key] = (left, top, target_w, target_h)
            self._globe_snapshot_canvas_sizes[key] = size
            self._update_globe_overlay(canvas, actual_w, actual_h, target_w, target_h, left, top)
            return True
        except (tk.TclError, ValueError, OSError):
            return False

    def _update_globe_overlay(self, canvas, actual_w, actual_h, content_w=None, content_h=None, offset_x=0, offset_y=0):
        """Lightweight text overlays, kept separate from the raster during resizing."""
        canvas.delete("globe-ui-labels")
        if not self.prefs.get("map_labels", True):
            return
        content_w = content_w or actual_w
        content_h = content_h or actual_h
        canvas.create_text(offset_x + 12, offset_y + 12, text="VIBE AURORA · DRAG TO ROTATE",
                           anchor="nw", fill=MUTED, font=("Segoe UI", 8, "bold"), tags="globe-ui-labels")
        server = SERVERS[self.selected]
        radius = min(content_w * .47, content_h * .46) * self.globe_zoom
        radius = min(radius, content_w * .49, content_h * .48)
        globe_label = f"{server['flag']}  {server['city']} · {server['country']}"
        if self.prefs.get("globe_show_coordinates", False):
            globe_label += f"  ({server['lat']:.2f}°, {server['lon']:.2f}°)"
        canvas.create_text(offset_x + content_w/2, offset_y + content_h*.51 + radius*.93,
                           text=globe_label, anchor="s", fill=TEXT,
                           font=("Segoe UI", 9, "bold"), tags=("globe-ui-labels", "globe-city-label"))

    def _globe_press(self, event):
        self._globe_drag_state = {
            "canvas": event.widget, "x": event.x, "y": event.y,
            "last_x": event.x, "last_y": event.y,
        }
        self._globe_drag_moved = False
        try:
            event.widget.configure(cursor="fleur")
        except tk.TclError:
            pass

    def _globe_drag(self, event):
        state = self._globe_drag_state
        if not state or state.get("canvas") != event.widget:
            return
        dx = event.x - state["last_x"]
        dy = event.y - state["last_y"]
        state["last_x"], state["last_y"] = event.x, event.y
        if abs(event.x-state["x"]) + abs(event.y-state["y"]) > 4:
            self._globe_drag_moved = True
        canvas = event.widget
        radius = max(100, min(canvas.winfo_width(), canvas.winfo_height()) * .42 * self.globe_zoom)
        sensitivity = {"Low": .85, "Normal": 1.0, "High": 1.45}.get(
            self.prefs.get("globe_rotate_sensitivity", "Normal"), 1.0)
        self.globe_lon = (self.globe_lon - (dx / radius) * 1.75 * sensitivity) % (2 * math.pi)
        self.globe_lat = max(-1.38, min(1.38, self.globe_lat + (dy / radius) * 1.55 * sensitivity))
        # One low-detail raster frame per event-loop slice at most; users can disable preview simplification.
        self._projection_context_key = None
        # Clamp interaction rendering to ~20fps. A lower-resolution preview keeps
        # pointer handling ahead of the rasterizer on slower CPUs.
        quality = "preview" if self.prefs.get("globe_simplified_drag", True) else "full"
        self._schedule_globe_redraw(canvas, 40 if quality == "preview" else 60, quality=quality)

    def _globe_release(self, event):
        canvas = event.widget
        try:
            canvas.configure(cursor="hand2")
        except tk.TclError:
            pass
        state = self._globe_drag_state
        self._globe_drag_state = None
        key = str(canvas)
        self._cancel_job(self._globe_redraw_jobs, key)
        if not self._globe_drag_moved and state:
            idx, distance = self._nearest_visible_globe_location(canvas, event.x, event.y)
            if idx is not None and distance <= 19:
                self._choose_server(idx, return_to_overview=self.prefs.get("location_return_to_overview", False),
                                    focus_globe=self.prefs.get("globe_center_selected", True))
        # Tiny delay lets Tk finish the mouse-up event before the high-detail render.
        self._schedule_globe_redraw(canvas, 12, quality="full")

    def _globe_wheel(self, event):
        direction = 1 if event.delta > 0 else -1
        self._globe_zoom_step(direction, event.widget)
        return "break"

    def _globe_zoom_step(self, direction, canvas=None):
        step = {"Low": .045, "Normal": .08, "High": .14}.get(
            self.prefs.get("globe_zoom_sensitivity", "Normal"), .08)
        self._globe_zoom_by(1.0 + step if direction > 0 else 1.0 - step, canvas)

    def _globe_zoom_by(self, factor, canvas=None):
        self.globe_zoom = max(.72, min(1.35, self.globe_zoom * factor))
        self._projection_context_key = None
        if canvas is not None and canvas.winfo_exists():
            self._schedule_globe_redraw(canvas, 0, quality="preview")
            self._schedule_globe_full_settle(canvas, 180)
        else:
            self._draw_map(preview=True)
            if hasattr(self, "geo_canvas") and self.geo_canvas.winfo_exists():
                self._schedule_globe_redraw(self.geo_canvas, 0, quality="preview")
                self._schedule_globe_full_settle(self.geo_canvas, 180)

    def _get_globe_projection_context(self, width, height):
        key = (self.globe_lon, self.globe_lat, self.globe_zoom, width, height)
        if key != self._projection_context_key:
            radius = min(width * .47, height * .46) * self.globe_zoom
            radius = min(radius, width * .49, height * .48)
            self._projection_context = (
                radius, width * .5, height * .51,
                math.sin(self.globe_lon), math.cos(self.globe_lon),
                math.sin(self.globe_lat), math.cos(self.globe_lat),
            )
            self._projection_context_key = key
        return self._projection_context

    def _project_globe_trig(self, trig, width, height):
        radius, cx, cy, sin_rot, cos_rot, sin_view, cos_view = self._get_globe_projection_context(width, height)
        sin_lat, cos_lat, sin_lon, cos_lon = trig
        # Equivalent to sin(lon - rotation) / cos(lon - rotation), but avoids two trig calls per point.
        sin_dl = sin_lon * cos_rot - cos_lon * sin_rot
        cos_dl = cos_lon * cos_rot + sin_lon * sin_rot
        x = cos_lat * sin_dl
        y = sin_lat * cos_view - cos_lat * cos_dl * sin_view
        z = sin_lat * sin_view + cos_lat * cos_dl * cos_view
        return cx + radius * x, cy - radius * y, z, radius

    def _globe_projection(self, lat_deg, lon_deg, width, height):
        """Cached orthographic projection; latitude/longitude trigonometry is reused for catalogue points."""
        return self._project_globe_trig(_globe_trig(lat_deg, lon_deg), width, height)

    def _nearest_visible_globe_location(self, canvas, x, y):
        width, height = max(canvas.winfo_width(), 1), max(canvas.winfo_height(), 1)
        best_idx, best_dist = None, float("inf")
        self._get_globe_projection_context(width, height)
        for idx, server_trig in enumerate(SERVER_GLOBE_TRIG):
            sx, sy, depth, _ = self._project_globe_trig(server_trig, width, height)
            if depth < .035:
                continue
            dist = math.hypot(x - sx, y - sy)
            if dist < best_dist:
                best_idx, best_dist = idx, dist
        return best_idx, best_dist

    def _draw_map(self):
        """Overview uses the same rotatable globe as the location chooser."""
        self._map_redraw_job = None
        if hasattr(self, "map_canvas") and self.map_canvas.winfo_exists():
            self._draw_globe(self.map_canvas)

    def _draw_globe(self, canvas, preview=False):
        """Fast raster globe: a single Tk image item replaces thousands of Canvas shapes."""
        if not canvas or not canvas.winfo_exists():
            return
        if PIL_AVAILABLE:
            self._draw_globe_raster(canvas, preview=preview)
        else:
            self._draw_globe_canvas_fallback(canvas, preview=preview)

    def _build_globe_background(self, width, height):
        """Static sphere/star background cached by size and zoom so dragging redraws only dynamic data."""
        image = Image.new("RGB", (width, height), BG2)
        draw = ImageDraw.Draw(image)
        cx, cy = width * .5, height * .51
        radius = min(width * .47, height * .46) * self.globe_zoom
        radius = min(radius, width * .49, height * .48)
        # Repeatable sparse stars outside the globe.
        if self.prefs.get("globe_show_stars", True):
            seed = 2417
            for _ in range(44):
                seed = (seed * 1103515245 + 12345) & 0x7fffffff
                sx = seed % max(width, 1)
                seed = (seed * 1103515245 + 12345) & 0x7fffffff
                sy = seed % max(height, 1)
                if math.hypot(sx-cx, sy-cy) > radius + 5:
                    draw.ellipse((sx, sy, sx+1, sy+1), fill="#536678")
        if self.prefs.get("map_glow", True):
            for extra, color in ((12, "#1b303e"), (7, "#263d4b")):
                draw.ellipse((cx-radius-extra, cy-radius-extra, cx+radius+extra, cy+radius+extra),
                             outline=color, width=2 if extra == 7 else 1)
        draw.ellipse((cx-radius, cy-radius, cx+radius, cy+radius), fill="#081521", outline="#557287", width=2)
        # Layered off-center highlights create a subtle dimensional glass effect.
        draw.ellipse((cx-radius*.88, cy-radius*.90, cx+radius*.66, cy+radius*.64), fill="#0c2130")
        draw.ellipse((cx-radius*.72, cy-radius*.78, cx+radius*.40, cy+radius*.35), fill="#10283a")
        draw.ellipse((cx-radius*.48, cy-radius*.66, cx+radius*.08, cy+radius*.03), fill="#122d40")
        draw.arc((cx-radius*.95, cy-radius*.95, cx+radius*.95, cy+radius*.95),
                 start=275, end=100, fill="#050b11", width=max(3, int(radius*.075)))
        return image

    def _draw_globe_raster(self, canvas, preview=False):
        render_started = time.perf_counter()
        if not canvas.winfo_exists():
            return
        actual_w = max(canvas.winfo_width(), 240)
        actual_h = max(canvas.winfo_height(), 180)
        # Bound raster work on very large displays. During interaction, use a small
        # framebuffer; the source is upscaled for display and replaced by one crisp
        # render after input/resize settles. Quantized widths also improve cache hits.
        area = max(1, actual_w * actual_h)
        if preview:
            # Drag preview deliberately targets ~110k pixels; fine details return on release.
            scale = min(0.32, 440 / max(1, actual_w), 300 / max(1, actual_h), math.sqrt(110000 / area))
            target_w = max(160, int(actual_w * scale))
            width = max(160, int(round(target_w / 32.0) * 32))
            height = max(100, int(round(width * actual_h / max(1, actual_w))))
        else:
            scale = min(1.0, 1100 / max(1, actual_w), 800 / max(1, actual_h), math.sqrt(900000 / area))
            width = max(240, int(actual_w * scale))
            height = max(180, int(round(width * actual_h / max(1, actual_w))))
        key = str(canvas)
        bg_key = (width, height, round(self.globe_zoom, 3), bool(self.prefs.get("map_glow", True)),
                  bool(self.prefs.get("globe_show_stars", True)), BG2)
        cached = self._globe_bg_cache.setdefault(key, {})
        background = cached.get(bg_key)
        if background is None:
            background = self._build_globe_background(width, height)
            cached[bg_key] = background
            # Keep only a small cache per canvas to prevent memory growth during continuous resize.
            while len(cached) > 3:
                cached.pop(next(iter(cached)))
        image = background.copy()
        draw = ImageDraw.Draw(image)
        radius, cx, cy, sin_rot, cos_rot, sin_view, cos_view = self._get_globe_projection_context(width, height)

        def project(trig):
            sin_lat, cos_lat, sin_lon, cos_lon = trig
            sin_dl = sin_lon * cos_rot - cos_lon * sin_rot
            cos_dl = cos_lon * cos_rot + sin_lon * sin_rot
            x = cos_lat * sin_dl
            y = sin_lat * cos_view - cos_lat * cos_dl * sin_view
            z = sin_lat * sin_view + cos_lat * cos_dl * cos_view
            return cx + radius * x, cy - radius * y, z

        def paint_curve(curve, color, line_width=1, stride=1):
            segment = []
            for index in range(0, len(curve), stride):
                x, y, depth = project(curve[index])
                if depth > 0.005:
                    segment.append((int(x), int(y)))
                else:
                    if len(segment) > 1:
                        draw.line(segment, fill=color, width=line_width, joint="curve")
                    segment = []
            if len(segment) > 1:
                draw.line(segment, fill=color, width=line_width, joint="curve")

        # The graticule is intentionally sparse during interaction, full-detail when settled.
        if self.prefs.get("map_grid", True):
            if preview:
                for index in (0, 2, 4, 6, 8):
                    curve = GLOBE_GRID_CURVES[index]
                    paint_curve(curve, "#223b49", 1, stride=3)
            else:
                for curve in GLOBE_GRID_CURVES:
                    paint_curve(curve, "#26404e" if len(curve) < 70 else "#203746", 1)

        if self.prefs.get("globe_show_equator", True):
            paint_curve(GLOBE_GRID_CURVES[2], "#3b7c8c", 2 if not preview else 1,
                        stride=3 if preview else 1)

        # Batch most land dots into a few native Pillow draw calls. The old version
        # issued thousands of draw.ellipse() calls per frame; draw.point() handles
        # a whole coordinate list in C and accent ellipses are limited to every 7th dot.
        if self.prefs.get("map_dots", True):
            base_stride = {"Low": 6, "Normal": 3, "High": 2}.get(self.prefs.get("map_density", "High"), 2)
            stride = base_stride * (12 if preview else 1)
            land_points = GLOBE_LAND_TRIG
            dark_points, mid_points, light_points = [], [], []
            accent_dots = []
            for ordinal, index in enumerate(range(0, len(land_points), stride)):
                sx, sy, depth = project(land_points[index])
                if depth <= .015:
                    continue
                pt = (int(round(sx)), int(round(sy)))
                if preview:
                    (dark_points if depth < .5 else light_points).append(pt)
                elif depth < .35:
                    dark_points.append(pt)
                    if ordinal % 7 == 0: accent_dots.append((sx, sy, 1.0, "#284554"))
                elif depth < .75:
                    mid_points.append(pt)
                    if ordinal % 7 == 0: accent_dots.append((sx, sy, 1.25, "#3b6674"))
                else:
                    light_points.append(pt)
                    if ordinal % 7 == 0: accent_dots.append((sx, sy, 1.55, "#4a7a87"))
            if dark_points: draw.point(dark_points, fill="#355969" if preview else "#284554")
            if mid_points: draw.point(mid_points, fill="#3b6674")
            if light_points: draw.point(light_points, fill="#4a7b89" if preview else "#4a7a87")
            if not preview:
                for sx, sy, dot_radius, color in accent_dots:
                    draw.ellipse((sx-dot_radius, sy-dot_radius, sx+dot_radius, sy+dot_radius), fill=color)

        # A geodesic path from Frankfurt to the selected city. Fewer segments in preview mode.
        if self.prefs.get("map_routes", True):
            origin = (50.11, 8.68)
            target = (SERVERS[self.selected]["lat"], SERVERS[self.selected]["lon"])
            def vec(lat_d, lon_d):
                la, lo = math.radians(lat_d), math.radians(lon_d)
                return math.cos(la)*math.cos(lo), math.cos(la)*math.sin(lo), math.sin(la)
            a, b = vec(*origin), vec(*target)
            dotv = max(-1.0, min(1.0, sum(a[i]*b[i] for i in range(3))))
            omega = math.acos(dotv)
            count = 12 if preview else 35
            route_segment = []
            for k in range(count):
                t = k / max(1, count-1)
                if omega < 1e-5:
                    v = a
                else:
                    denom = math.sin(omega)
                    va = math.sin((1-t)*omega) / denom
                    vb = math.sin(t*omega) / denom
                    v = tuple(va*a[i] + vb*b[i] for i in range(3))
                lat_d = math.degrees(math.atan2(v[2], math.sqrt(v[0]*v[0]+v[1]*v[1])))
                lon_d = math.degrees(math.atan2(v[1], v[0]))
                sx, sy, depth = project(_globe_trig(lat_d, lon_d))
                if depth > 0.01:
                    route_segment.append((int(sx), int(sy)))
                else:
                    if len(route_segment) > 1:
                        draw.line(route_segment, fill=BLUE if self.connected else "#4f7e8d",
                                  width=2 if self.connected else 1, joint="curve")
                    route_segment = []
            if len(route_segment) > 1:
                draw.line(route_segment, fill=BLUE if self.connected else "#4f7e8d",
                          width=2 if self.connected else 1, joint="curve")

        # Server points. Preview renders one out of every four except the selected city.
        marker_scale = {"Small": .72, "Normal": 1.0, "Large": 1.45}.get(
            self.prefs.get("globe_marker_size", "Normal"), 1.0)
        for index, (server, trig) in enumerate(zip(SERVERS, SERVER_GLOBE_TRIG)):
            if preview and index % 4 != 0 and index != self.selected:
                continue
            sx, sy, depth = project(trig)
            if depth <= .08:
                continue
            if index == self.selected:
                glow_r = 9 * marker_scale
                marker_r = 5 * marker_scale
                if self.prefs.get("map_glow", True):
                    draw.ellipse((sx-glow_r, sy-glow_r, sx+glow_r, sy+glow_r), outline="#2c6c78", width=1)
                draw.ellipse((sx-marker_r, sy-marker_r, sx+marker_r, sy+marker_r), fill=CYAN, outline="#e0fffa", width=1)
                core_r = 1.5 * marker_scale
                draw.ellipse((sx-core_r, sy-core_r, sx+core_r, sy+core_r), fill="#ffffff")
            else:
                dot_r = (1.5 if depth < .4 else 2.0) * marker_scale
                draw.ellipse((sx-dot_r, sy-dot_r, sx+dot_r, sy+dot_r),
                             fill="#7cabbc" if depth < .5 else BLUE_BRIGHT)

        # Keep the low-level rendered raster as the resize snapshot. Subsequent
        # Configure events resize this image only, and do not reproject the globe.
        self._globe_source_images[key] = image
        self._globe_snapshot_canvas_sizes.pop(key, None)
        # Scale the frame for the current canvas. Full renders are pixel-capped above
        # on high-DPI / very large windows, so this final resize is bounded as well.
        if image.size != (actual_w, actual_h):
            try:
                resample = Image.Resampling.BILINEAR
            except AttributeError:
                resample = Image.BILINEAR
            image = image.resize((actual_w, actual_h), resample)
        photo = ImageTk.PhotoImage(image)
        item = self._globe_image_items.get(key)
        try:
            if item is None or not canvas.type(item):
                item = canvas.create_image(0, 0, image=photo, anchor="nw", tags=("globe-raster",))
                self._globe_image_items[key] = item
            else:
                canvas.itemconfigure(item, image=photo)
                canvas.coords(item, 0, 0)
                canvas.tag_lower(item)
        except tk.TclError:
            item = canvas.create_image(0, 0, image=photo, anchor="nw", tags=("globe-raster",))
            self._globe_image_items[key] = item
        self._globe_photo_refs[key] = photo

        # Lightweight vector labels are kept separately from the cached raster.
        self._update_globe_overlay(canvas, actual_w, actual_h)
        if hasattr(self, "map_status") and canvas == getattr(self, "map_canvas", None):
            self.map_status.configure(
                text="●  " + ("CONNECTED" if self.connected else "PREVIEW NETWORK"),
                fg=GREEN if self.connected else BLUE)
        elapsed_ms = (time.perf_counter() - render_started) * 1000.0
        self._globe_last_draw_ms = elapsed_ms
        self._globe_avg_draw_ms = elapsed_ms if not self._globe_draw_count else (self._globe_avg_draw_ms * .85 + elapsed_ms * .15)
        self._globe_peak_draw_ms = max(self._globe_peak_draw_ms, elapsed_ms)
        self._globe_draw_count += 1

    def _draw_globe_canvas_fallback(self, canvas, preview=False):
        if not canvas or not canvas.winfo_exists():
            return
        c = canvas
        w, h = max(c.winfo_width(), 240), max(c.winfo_height(), 180)
        c.delete("globe")
        c.configure(scrollregion=(0, 0, w, h))
        _, _, _, r = self._globe_projection(0, 0, w, h)
        cx, cy = w*.5, h*.51
        # Tiny stars remain static-looking while the globe rotates beneath them.
        seed = 2417
        for j in range(38):
            seed = (seed * 1103515245 + 12345) & 0x7fffffff
            sx = (seed % max(w, 1))
            seed = (seed * 1103515245 + 12345) & 0x7fffffff
            sy = (seed % max(h, 1))
            if math.hypot(sx-cx, sy-cy) > r + 5:
                c.create_oval(sx, sy, sx+1.5, sy+1.5, fill="#536678", outline="", tags="globe")
        if self.prefs.get("map_glow", True):
            c.create_oval(cx-r-9, cy-r-9, cx+r+9, cy+r+9, outline="#263d4b", width=2, tags="globe")
        # Ocean shell with a soft upper-left highlight.
        c.create_oval(cx-r, cy-r, cx+r, cy+r, fill="#091622", outline="#557287", width=1.5, tags="globe")
        c.create_oval(cx-r*.88, cy-r*.90, cx+r*.66, cy+r*.64, fill="#102638", outline="", tags="globe")
        c.create_oval(cx-r*.72, cy-r*.78, cx+r*.40, cy+r*.35, fill="#112a3b", outline="", tags="globe")
        if self.prefs.get("map_grid", True):
            # Render fewer grid lines during mouse movement on the fallback renderer.
            def draw_geo_curve(coords, color="#2d4a5b", width=1, dash=(2, 5)):
                segment = []
                for lat_d, lon_d in coords:
                    sx, sy, depth, _ = self._globe_projection(lat_d, lon_d, w, h)
                    if depth >= 0.01:
                        segment.extend((sx, sy))
                    elif len(segment) >= 4:
                        c.create_line(*segment, fill=color, width=width, dash=dash, smooth=True, tags="globe")
                        segment = []
                    else:
                        segment = []
                if len(segment) >= 4:
                    c.create_line(*segment, fill=color, width=width, dash=dash, smooth=True, tags="globe")
            latitudes = (-60, 0, 60) if preview else (-60, -30, 0, 30, 60)
            longitudes = range(-120, 181, 60) if preview else range(-150, 181, 30)
            lon_step = 12 if preview else 4
            lat_step = 9 if preview else 3
            for lat_d in latitudes:
                draw_geo_curve([(lat_d, lon) for lon in range(-180, 181, lon_step)], "#26404e", 1, (1, 5))
            for lon_d in longitudes:
                draw_geo_curve([(lat, lon_d) for lat in range(-86, 87, lat_step)], "#203746", 1, (1, 5))
        if self.prefs.get("map_dots", True):
            density = {"Low": 6, "Normal": 3, "High": 2}.get(self.prefs.get("map_density", "High"), 2)
            if preview:
                density *= 7
            for index, (lat_d, lon_d) in enumerate(GLOBE_LAND_POINTS):
                if index % density:
                    continue
                sx, sy, depth, _ = self._globe_projection(lat_d, lon_d, w, h)
                if depth <= .015:
                    continue
                radius = 1.0 if depth < .35 else (1.35 if depth < .75 else 1.65)
                color = "#284554" if depth < .35 else ("#3b6674" if depth < .75 else "#4a7a87")
                c.create_oval(sx-radius, sy-radius, sx+radius, sy+radius,
                              fill=color, outline="", tags="globe")
        # Selected server route: interpolate a short great-circle arc and clip it at the horizon.
        origin = (50.11, 8.68)
        target = (SERVERS[self.selected]["lat"], SERVERS[self.selected]["lon"])
        if self.prefs.get("map_routes", True):
            def vec(lat_d, lon_d):
                la, lo = math.radians(lat_d), math.radians(lon_d)
                return (math.cos(la)*math.cos(lo), math.cos(la)*math.sin(lo), math.sin(la))
            a, b = vec(*origin), vec(*target)
            dot = max(-1.0, min(1.0, sum(a[i]*b[i] for i in range(3))))
            omega = math.acos(dot)
            pts = []
            for k in range(35):
                t = k / 34
                if omega < 1e-5:
                    v = a
                else:
                    denom = math.sin(omega)
                    va = math.sin((1-t)*omega) / denom
                    vb = math.sin(t*omega) / denom
                    v = tuple(va*a[i] + vb*b[i] for i in range(3))
                lat_d = math.degrees(math.atan2(v[2], math.sqrt(v[0]*v[0]+v[1]*v[1])))
                lon_d = math.degrees(math.atan2(v[1], v[0]))
                sx, sy, depth, _ = self._globe_projection(lat_d, lon_d, w, h)
                if depth > 0.01:
                    pts.extend((sx, sy))
                elif len(pts) >= 4:
                    c.create_line(*pts, fill=BLUE if self.connected else "#4f7e8d",
                                  width=2 if self.connected else 1, smooth=True, tags="globe")
                    pts = []
                else:
                    pts = []
            if len(pts) >= 4:
                c.create_line(*pts, fill=BLUE if self.connected else "#4f7e8d",
                              width=2 if self.connected else 1, smooth=True, tags="globe")
        # City/server nodes. All 100+ geolocations can be selected from the sphere.
        for idx, server in enumerate(SERVERS):
            if preview and idx % 4 != 0 and idx != self.selected:
                continue
            sx, sy, depth, _ = self._globe_projection(server["lat"], server["lon"], w, h)
            if depth <= .08:
                continue
            if idx == self.selected:
                if self.prefs.get("map_glow", True):
                    c.create_oval(sx-10, sy-10, sx+10, sy+10, outline="#2c6c78", width=1, tags="globe")
                c.create_oval(sx-5.5, sy-5.5, sx+5.5, sy+5.5, fill=CYAN, outline="#e0fffa", width=1, tags="globe")
                c.create_oval(sx-1.7, sy-1.7, sx+1.7, sy+1.7, fill="#ffffff", outline="", tags="globe")
            else:
                radius = 1.7 if depth < .4 else 2.2
                c.create_oval(sx-radius, sy-radius, sx+radius, sy+radius,
                              fill="#7cabbc" if depth < .5 else BLUE_BRIGHT,
                              outline="", tags="globe")
        # Soft terminator/shadow to reinforce the globe rather than a flat map.
        c.create_arc(cx-r*.95, cy-r*.95, cx+r*.95, cy+r*.95,
                     start=275, extent=185, style="arc", outline="#070e17", width=max(3, int(r*.08)), tags="globe")
        if self.prefs.get("map_labels", True):
            c.create_text(12, 12, text="VIBE AURORA · DRAG TO ROTATE",
                          anchor="nw", fill=MUTED, font=("Segoe UI", 8, "bold"), tags="globe")
            selected = SERVERS[self.selected]
            label = f"{selected['flag']}  {selected['city']} · {selected['country']}"
            c.create_text(w/2, h-r*.04, text=label, anchor="s", fill=TEXT,
                          font=("Segoe UI", 9, "bold"), tags="globe")
        if hasattr(self, "map_status") and c == getattr(self, "map_canvas", None):
            self.map_status.configure(text="●  " + ("CONNECTED" if self.connected else "PREVIEW NETWORK"),
                                      fg=GREEN if self.connected else BLUE)

    def _map_click(self, event):
        # Kept for compatibility with earlier builds; current maps use drag/release gestures.
        canvas = event.widget
        idx, distance = self._nearest_visible_globe_location(canvas, event.x, event.y)
        if idx is not None and distance < 19:
            self._choose_server(idx, return_to_overview=False)

    def _draw_mascot(self, c, small=False):
        """Draw Vibi, a friendly arctic-fox mascot in the Vibe palette."""
        c.delete("all")
        w = int(c.cget("width")); h = int(c.cget("height"))
        cx, cy = w * .50, h * .53
        scale = min(w, h) / 100.0
        def xy(x, y): return (cx + (x-50)*scale, cy + (y-50)*scale)
        def poly(points, fill, outline=""):
            coords=[]
            for x,y in points: coords.extend(xy(x,y))
            c.create_polygon(*coords, fill=fill, outline=outline, smooth=True, splinesteps=16)
        # soft halo + ears
        c.create_oval(*xy(7,7), *xy(93,93), fill="#1d2d3c", outline="#2c4c65", width=1)
        poly([(24,38),(25,12),(43,27),(57,27),(76,12),(77,39),(83,53),(78,72),(65,83),(35,83),(22,72),(17,53)], "#dbe9f4", "#8ab8d8")
        poly([(30,34),(30,22),(40,31)], "#83b9e8")
        poly([(70,34),(70,22),(60,31)], "#83b9e8")
        # face mask and cheeks
        poly([(23,47),(35,40),(50,44),(65,40),(77,47),(70,66),(58,73),(50,75),(42,73),(30,66)], "#f4f8fc")
        # eyes, nose and smile
        ex1,ey1=xy(39,51); ex2,ey2=xy(61,51)
        r=max(1.5,3.2*scale)
        c.create_oval(ex1-r,ey1-r,ex1+r,ey1+r,fill="#182330",outline="")
        c.create_oval(ex2-r,ey2-r,ex2+r,ey2+r,fill="#182330",outline="")
        nx,ny=xy(50,59); nr=max(1.5,2.4*scale)
        c.create_oval(nx-nr,ny-nr,nx+nr,ny+nr,fill="#5f8eb4",outline="")
        x1,y1=xy(45,63); x2,y2=xy(50,66); x3,y3=xy(55,63)
        c.create_line(x1,y1,x2,y2,x3,y3,fill="#5f8eb4",width=max(1,scale*1.6),smooth=True)
        # tiny Vibe badge
        bx,by=xy(71,76); br=7*scale
        c.create_oval(bx-br,by-br,bx+br,by+br,fill=BLUE_DARK,outline=BLUE)
        c.create_text(bx,by,text="V",fill=BLUE_BRIGHT,font=("Segoe UI",max(6,int(8*scale)),"bold"))

    def _draw_connect_button(self):
        if not hasattr(self, "connect_canvas") or not self.connect_canvas.winfo_exists():
            return
        c = self.connect_canvas
        c.delete("all")
        phase = self.pulse / 10.0
        cx, cy = 95, 86
        # Airy luminous rings, then a soft shadow and an ice-glass center.
        ring_colors = ("#31586b", "#254455", "#1c3547", "#172b3a")
        for ring in range(4):
            r = 45 + ring*12 + (math.sin(phase + ring*1.15)+1)*1.7
            c.create_oval(cx-r, cy-r, cx+r, cy+r, outline=ring_colors[ring], width=1)
        r = 36 + (math.sin(phase)*1.2 if self.prefs.get("animations", True) and not self.prefs.get("reduced_motion", False) else 0)
        c.create_oval(cx-r-2, cy-r+2, cx+r+2, cy+r+6, fill="#09131d", outline="")
        c.create_oval(cx-r, cy-r, cx+r, cy+r, fill=BLUE, outline=BLUE_BRIGHT, width=2)
        c.create_arc(cx-r+4, cy-r+4, cx+r-4, cy+r-4, start=28, extent=118,
                     style="arc", outline="#e2f7ff", width=2)
        c.create_text(cx, cy-3, text="Ⅱ" if self.connected else "⏻",
                      fill="#082033", font=("Segoe UI Symbol", 24, "bold"))
        c.create_text(cx, cy+22, text="CONNECTED" if self.connected else "READY",
                      fill="#082033", font=("Segoe UI", 7, "bold"))

    def _select_lowest_demo_ping(self):
        def score(item):
            try:
                return int(re.search(r"\d+", item[1].get("ping", "9999")).group(0))
            except (AttributeError, ValueError):
                return 9999
        idx = min(range(len(SERVERS)), key=lambda i: score((i, SERVERS[i])))
        self._choose_server(idx, return_to_overview=False, focus_globe=False)
        server = SERVERS[idx]
        self._record_activity("Quick pick", f"Selected {server['city']} from demo catalogue latency ({server['ping']}).")
        self._toast(f"Sample fastest location: {server['city']} · demo latency only")

    def _select_recent_location(self):
        recent = self.prefs.get("_recent_servers", [])
        for idx in recent:
            if isinstance(idx, int) and 0 <= idx < len(SERVERS) and idx != self.selected:
                self._choose_server(idx, return_to_overview=False, focus_globe=False)
                self._toast(f"Recent location: {SERVERS[idx]['city']}")
                return
        self._toast("No recent location yet — choose a server first")

    def _select_favorite_location(self):
        favorites = set(self.prefs.get("_favorite_codes", []))
        idx = next((i for i, server in enumerate(SERVERS)
                    if server.get("code") in favorites and i != self.selected), None)
        if idx is None:
            self._toast("No favorite locations yet — tap ☆ in Locations")
            self._navigate("Locations")
            return
        self._choose_server(idx, return_to_overview=False, focus_globe=False)
        self._toast(f"Favorite location: {SERVERS[idx]['city']}")

    def _toggle_connection(self):
        if self.connected and self.prefs.get("ask_before_disconnect"):
            if not messagebox.askyesno("Vibe VPN", "Disconnect the demo session?", parent=self):
                return
        self.connected = not self.connected
        self._record_activity("Connection preview changed", "Demo state is now " + ("on" if self.connected else "off") + "; no VPN tunnel is active.")
        if self.page != "overview":
            self._navigate("Overview")
        else:
            self._sync_page("overview")

    # ------------------------ Locations ------------------------------------
    def _toast(self, message):
        """A single managed toast timer; replacing a toast cancels the previous callback."""
        try:
            if self._toast_job is not None:
                try: self.after_cancel(self._toast_job)
                except tk.TclError: pass
                self._toast_job = None
            existing = getattr(self, "_toast_label", None)
            if existing is not None and existing.winfo_exists():
                existing.destroy()
            toast = tk.Label(
                self, text=str(message), bg="#263a43", fg=TEXT,
                font=("Segoe UI", 9, "bold"), padx=14, pady=8,
                highlightthickness=1, highlightbackground=BLUE_DARK
            )
            self._toast_label = toast
            toast.place(relx=.5, rely=.965, anchor="s")
            def dismiss(expected=toast):
                self._toast_job = None
                try:
                    if expected.winfo_exists(): expected.destroy()
                except tk.TclError:
                    pass
            self._toast_job = self.after(2200, dismiss)
        except tk.TclError:
            pass

    def _location_page_size(self):
        raw = self.prefs.get("location_results_per_page", "24")
        if raw == "All":
            return 100000
        try:
            return max(12, min(500, int(raw)))
        except (TypeError, ValueError):
            return 24

    def _copy_selected_location_details(self):
        server = SERVERS[self.selected]
        details = (
            f"{server['city']}, {server['country']}\n"
            f"Code: {server['code']}\n"
            f"Region: {server['region']}\n"
            f"Coordinates: {server['lat']:.4f}, {server['lon']:.4f}\n"
            f"Displayed latency: {server['ping']} (demo catalogue, not measured)"
        )
        try:
            self.clipboard_clear()
            self.clipboard_append(details)
            self.update_idletasks()
            self._toast("Location details copied")
        except tk.TclError:
            messagebox.showerror("Vibe VPN", "Could not access the clipboard.", parent=self)

    def _render_locations(self):
        self._clear_content()
        header = tk.Frame(self.content, bg=BG)
        header.pack(fill="x", pady=(0, 10))
        self.label(header, "Explore the globe", 19, TEXT, True, bg=BG).pack(anchor="w")
        self.label(header, f"{len(SERVERS)} selectable city locations · drag the Earth to rotate, click a node or search a city. Preview catalogue, not live server inventory.",
                   9, MUTED, bg=BG).pack(anchor="w", pady=(4, 0))

        body = tk.Frame(self.content, bg=BG)
        body.pack(fill="both", expand=True)
        body.grid_columnconfigure(0, weight=7, uniform="geo")
        body.grid_columnconfigure(1, weight=5, uniform="geo")
        body.grid_rowconfigure(0, weight=1)

        globe_card = self.panel(body, BG2, BORDER)
        globe_card.grid(row=0, column=0, sticky="nsew", padx=(0, 9))
        gh = tk.Frame(globe_card, bg=BG2)
        gh.pack(fill="x", padx=16, pady=(13, 5))
        self.label(gh, "INTERACTIVE EARTH", 9, MUTED, True, bg=BG2).pack(side="left")
        self.globe_location_status = self.label(gh, "● PREVIEW CATALOGUE", 8, CYAN, True, bg=BG2)
        self.globe_location_status.pack(side="right")
        self.geo_canvas = tk.Canvas(globe_card, bg=BG2, highlightthickness=0, cursor="hand2")
        self.geo_canvas.pack(fill="both", expand=True, padx=5, pady=(0, 3))
        self.geo_canvas.bind("<Configure>", lambda e: self._schedule_globe_resize_redraw(self.geo_canvas))
        self._bind_globe_gestures(self.geo_canvas)

        map_tools = tk.Frame(globe_card, bg=BG2)
        map_tools.pack(fill="x", padx=12, pady=(0, 10))
        self.button(map_tools, "−", lambda: self._globe_zoom_by(.88),
                    bg=PANEL2, fg=TEXT, hover=PANEL_HOVER, padx=12, pady=6, font_size=11).pack(side="left", padx=(0, 5))
        self.button(map_tools, "+", lambda: self._globe_zoom_by(1.14),
                    bg=PANEL2, fg=TEXT, hover=PANEL_HOVER, padx=12, pady=6, font_size=11).pack(side="left", padx=5)
        self.button(map_tools, "Reset view", self._reset_globe_view,
                    bg=PANEL2, fg=TEXT, hover=PANEL_HOVER, padx=10, pady=7).pack(side="left", padx=5)
        self.copy_location_button = self.button(map_tools, "Copy details", self._copy_selected_location_details,
                    bg=PANEL2, fg=TEXT, hover=PANEL_HOVER, padx=9, pady=7, font_size=8)
        if self.prefs.get("show_copy_location_button", True):
            self.copy_location_button.pack(side="left", padx=5)
        self.location_current_label = self.label(map_tools,
            f"Selected · {SERVERS[self.selected]['city']}, {SERVERS[self.selected]['country']}",
            8, BLUE_BRIGHT, True, bg=BG2)
        self.location_current_label.pack(side="right", padx=4)
        self.button(globe_card, "Use selected location  →", lambda: self._navigate("Overview"),
                    bg=BLUE, fg="#101821", hover=BLUE_BRIGHT, padx=15, pady=10, font_size=10).pack(
                        fill="x", padx=12, pady=(0, 12))

        list_card = self.panel(body, PANEL, BORDER)
        list_card.grid(row=0, column=1, sticky="nsew")
        list_head = tk.Frame(list_card, bg=PANEL)
        list_head.pack(fill="x", padx=13, pady=(13, 8))
        self.label(list_head, "Locations", 13, TEXT, True, bg=PANEL).pack(side="left")
        self.location_count_label = self.label(list_head, f"{len(SERVERS)} cities", 8, MUTED, bg=PANEL)
        self.location_count_label.pack(side="right")

        searchbox = tk.Frame(list_card, bg=PANEL2)
        searchbox.pack(fill="x", padx=12, pady=(0, 8))
        self.label(searchbox, "⌕", 15, MUTED, bg=PANEL2).pack(side="left", padx=(9, 4), pady=4)
        saved_query = self.prefs.get("_location_search", "") if self.prefs.get("remember_location_search", True) else ""
        self.search_var = tk.StringVar(value=str(saved_query))
        self.search_var_entry = ttk.Entry(searchbox, textvariable=self.search_var)
        self.search_var_entry.pack(side="left", fill="x", expand=True, padx=(0, 8), pady=5)
        self.search_var_entry.insert(0, "")
        self.search_var_entry.bind("<KeyRelease>", self._schedule_location_filter)

        filters = tk.Frame(list_card, bg=PANEL)
        filters.pack(fill="x", padx=12, pady=(0, 8))
        allowed_regions = {"All regions", "Europe", "Asia Pacific", "Americas", "Middle East", "Africa", "Oceania", "★ Favorites"}
        saved_region = self.prefs.get("default_location_region", "All regions")
        if saved_region not in allowed_regions:
            saved_region = "All regions"
        self.geo_region_var = tk.StringVar(value=saved_region)
        regions = ["All regions", "Europe", "Asia Pacific", "Americas", "Middle East", "Africa", "Oceania", "★ Favorites"]
        combo = ttk.Combobox(filters, textvariable=self.geo_region_var, values=regions,
                             state="readonly", width=17)
        combo.pack(side="left", fill="x", expand=True)
        combo.bind("<<ComboboxSelected>>", self._schedule_location_filter)
        self.button(filters, "Clear", self._clear_location_search,
                    bg=PANEL2, fg=MUTED, hover=PANEL_HOVER, padx=9, pady=6, font_size=8).pack(side="right", padx=(6, 0))

        self.location_list_canvas = tk.Canvas(list_card, bg=PANEL, highlightthickness=0, bd=0)
        location_scroll = ttk.Scrollbar(list_card, orient="vertical", command=self.location_list_canvas.yview)
        self.location_list_canvas.configure(yscrollcommand=location_scroll.set)
        location_scroll.pack(side="right", fill="y", pady=(0, 8))
        self.location_list_canvas.pack(side="left", fill="both", expand=True, padx=(8, 0), pady=(0, 8))
        self.location_list_inner = tk.Frame(self.location_list_canvas, bg=PANEL)
        self._location_list_window = self.location_list_canvas.create_window(
            (0, 0), window=self.location_list_inner, anchor="nw")
        self.location_list_inner.bind("<Configure>", lambda e: self.location_list_canvas.configure(
            scrollregion=self.location_list_canvas.bbox("all")))
        self.location_list_canvas.bind("<Configure>", lambda e: self.location_list_canvas.itemconfigure(
            self._location_list_window, width=e.width))
        self.location_list_canvas.bind("<MouseWheel>", lambda e: self._scroll_location_list(e))
        self.location_list_inner.bind("<MouseWheel>", lambda e: self._scroll_location_list(e))
        self.location_visible_count = self._location_page_size()
        self._last_location_render_signature = None
        self._filter_servers()
        self._schedule_globe_redraw(self.geo_canvas, 0, quality="preview")
        self._schedule_globe_full_settle(self.geo_canvas, 240)

    def _scroll_location_list(self, event):
        if event.delta:
            units = int(-event.delta / 120) if abs(event.delta) >= 120 else (-1 if event.delta > 0 else 1)
            self.location_list_canvas.yview_scroll(units, "units")
        return "break"

    def _clear_location_search(self):
        self.search_var.set("")
        if hasattr(self, "geo_region_var"):
            self.geo_region_var.set(self.prefs.get("default_location_region", "All regions"))
        self.location_visible_count = self._location_page_size()
        if self.prefs.get("remember_location_search", True):
            self.prefs["_location_search"] = ""
            if self.prefs.get("auto_save_settings", True): self._save_preferences()
        self._filter_servers()

    def _schedule_location_filter(self, event=None):
        if self._location_filter_job:
            try: self.after_cancel(self._location_filter_job)
            except tk.TclError: pass
        self.location_visible_count = self._location_page_size()
        delay = {"Fast": 55, "Balanced": 140, "Power saver": 280}.get(
            self.prefs.get("location_search_delay", "Balanced"), 140)

        def apply_filter():
            self._location_filter_job = None
            self._filter_servers()
            if self.prefs.get("remember_location_search", True) and hasattr(self, "search_var"):
                self.prefs["_location_search"] = self.search_var.get()[:120]
                if self.prefs.get("auto_save_settings", True):
                    self._save_preferences()
        self._location_filter_job = self.after(delay, apply_filter)

    def _filter_servers(self, event=None):
        if hasattr(self, "location_list_inner") and self.location_list_inner.winfo_exists():
            inner = self.location_list_inner
            query = self.search_var.get().lower().strip() if hasattr(self, "search_var") else ""
            region = self.geo_region_var.get() if hasattr(self, "geo_region_var") else "All regions"
            favorites = set(self.prefs.get("_favorite_codes", []))
            recent = list(self.prefs.get("_recent_servers", []))
            signature = (
                query, region, tuple(sorted(favorites)), tuple(recent), self.selected,
                self.location_visible_count, self.prefs.get("server_sort_order"),
                self.prefs.get("favorite_servers_first"), self.prefs.get("search_server_code"),
                self.prefs.get("location_show_flags"), self.prefs.get("location_show_country"),
                self.prefs.get("location_show_server_code"), self.prefs.get("location_show_region"),
                self.prefs.get("show_ping"), self.prefs.get("compact_server_cards"),
                self.prefs.get("density"), self.prefs.get("remember_favorites"),
            )
            if signature == self._last_location_render_signature:
                return
            self._last_location_render_signature = signature
            for child in inner.winfo_children():
                child.destroy()
            filtered = []
            for index, server in enumerate(SERVERS):
                searchable = [server["country"], server["city"], server["region"]]
                if self.prefs.get("search_server_code", True):
                    searchable.append(server["code"])
                haystack = " ".join(searchable).lower()
                if query and query not in haystack: continue
                if region == "★ Favorites" and server["code"] not in favorites: continue
                if region not in ("All regions", "★ Favorites") and server["region"] != region: continue
                filtered.append((index, server))

            sort_mode = self.prefs.get("server_sort_order", "Recommended")
            if sort_mode == "City A–Z":
                filtered.sort(key=lambda pair: pair[1]["city"].casefold())
            elif sort_mode == "Country A–Z":
                filtered.sort(key=lambda pair: (pair[1]["country"].casefold(), pair[1]["city"].casefold()))
            elif sort_mode == "Region":
                filtered.sort(key=lambda pair: (pair[1]["region"].casefold(), pair[1]["country"].casefold(), pair[1]["city"].casefold()))
            elif sort_mode == "Code":
                filtered.sort(key=lambda pair: pair[1]["code"].casefold())
            elif sort_mode == "Recently used":
                recent_order = {idx: pos for pos, idx in enumerate(recent)}
                filtered.sort(key=lambda pair: (recent_order.get(pair[0], 100000), pair[1]["city"].casefold()))
            if self.prefs.get("favorite_servers_first", True) and sort_mode != "Recently used":
                filtered.sort(key=lambda pair: (pair[1]["code"] not in favorites, pair[0] != self.selected))

            if hasattr(self, "location_count_label") and self.location_count_label.winfo_exists():
                self.location_count_label.configure(text=f"{len(filtered)} results")
            visible = filtered[:self.location_visible_count]
            if self._location_render_job is not None:
                try: self.after_cancel(self._location_render_job)
                except tk.TclError: pass
                self._location_render_job = None
            self._location_render_queue = list(visible)
            self._location_render_target = inner
            self._location_render_remaining = max(0, len(filtered) - len(visible))
            self._location_render_total = len(filtered)
            if not filtered:
                self.label(inner, "No locations match. Try another city or region.", 9, MUTED, bg=PANEL).pack(pady=24)
                return
            self._schedule_location_rows(initial_delay=1)
            return
        # Backwards-safe fallback in case an older cached page shape is present.
        if not hasattr(self, "server_list") or not self.server_list.winfo_exists(): return
        for w in self.server_list.winfo_children(): w.destroy()
        query = self.search_var.get().lower().strip()
        for i, server in enumerate(SERVERS):
            if query and query not in (server["country"] + server["city"] + server["code"]).lower(): continue
            self.label(self.server_list, f"{server['flag']}  {server['city']} · {server['country']}", 9, TEXT, bg=BG).pack(anchor="w")

    def _schedule_location_rows(self, initial_delay=1):
        if self._closing or self.page != "locations" or self._location_render_job is not None:
            return
        if not self._location_render_queue:
            return
        try:
            self._location_render_job = self.after(initial_delay, self._build_location_rows_batch)
        except tk.TclError:
            self._location_render_job = None

    def _build_location_rows_batch(self):
        self._location_render_job = None
        if self._closing or self.page != "locations":
            return
        inner = getattr(self, "_location_render_target", None)
        if inner is None or not inner.winfo_exists():
            return
        batch = [self._location_render_queue.pop(0) for _ in range(min(2, len(self._location_render_queue)))]
        favorites = set(self.prefs.get("_favorite_codes", []))
        for index, server in batch:
            selected = index == self.selected
            row_bg = PANEL2 if selected else PANEL
            row = tk.Frame(inner, bg=row_bg, highlightthickness=1 if selected else 0,
                           highlightbackground=BLUE if selected else PANEL)
            row.pack(fill="x", pady=2, padx=2)
            row.bind("<Button-1>", lambda e, idx=index: self._choose_server(idx, return_to_overview=self.prefs.get("location_return_to_overview", False), focus_globe=self.prefs.get("globe_center_selected", True)))
            if self.prefs.get("location_show_flags", True):
                self.label(row, server["flag"], 18, TEXT, bg=row_bg).pack(side="left", padx=(7, 6), pady=7)
            text = tk.Frame(row, bg=row_bg)
            text.pack(side="left", fill="x", expand=True, pady=6)
            self.label(text, server["city"], 9, TEXT, True, bg=row_bg).pack(anchor="w")
            detail_parts = []
            if self.prefs.get("location_show_country", True): detail_parts.append(server["country"])
            if self.prefs.get("location_show_server_code", True): detail_parts.append(server["code"])
            if self.prefs.get("location_show_region", False): detail_parts.append(server["region"])
            if detail_parts:
                self.label(text, "  ·  ".join(detail_parts), 7, MUTED, bg=row_bg).pack(anchor="w", pady=(2, 0))
            if self.prefs.get("show_ping", True):
                self.label(row, server["ping"], 8, BLUE_BRIGHT, True, bg=row_bg).pack(side="left", padx=5)
            fav_label = "★" if server["code"] in favorites else "☆"
            self.button(row, fav_label, lambda code=server["code"]: self._toggle_location_favorite(code),
                        bg=row_bg, fg=ORANGE if fav_label == "★" else MUTED,
                        hover=PANEL_HOVER, padx=6, pady=5, font_size=11).pack(side="right", padx=(0, 4))
            self.button(row, "Select" if not selected else "Selected ✓",
                        lambda idx=index: self._choose_server(idx, return_to_overview=self.prefs.get("location_return_to_overview", False), focus_globe=self.prefs.get("globe_center_selected", True)),
                        bg=BLUE_DARK if selected else PANEL_HOVER,
                        fg=BLUE_BRIGHT if selected else TEXT, hover=PANEL_HOVER,
                        padx=7, pady=6, font_size=8).pack(side="right", padx=4)
            for child in row.winfo_children():
                child.bind("<MouseWheel>", lambda e: self._scroll_location_list(e))
        if self._location_render_queue:
            self._schedule_location_rows(initial_delay=8)
            return
        if self._location_render_remaining > 0:
            page_size = self._location_page_size()
            self.button(inner, f"Show {min(page_size, self._location_render_remaining)} more of {self._location_render_remaining} locations  ↓",
                        lambda: self._show_more_locations(), bg=PANEL2, fg=BLUE_BRIGHT,
                        hover=PANEL_HOVER, padx=8, pady=9, font_size=8).pack(fill="x", pady=(7, 3), padx=2)
        self._location_render_queue = []
        self._last_location_render_signature = self._last_location_render_signature

    def _show_more_locations(self):
        self.location_visible_count += self._location_page_size()
        self._filter_servers()

    def _toggle_location_favorite(self, code):
        favorites = set(self.prefs.get("_favorite_codes", []))
        if code in favorites: favorites.remove(code)
        else: favorites.add(code)
        self.prefs["_favorite_codes"] = sorted(favorites)
        self._last_location_render_signature = None
        self._save_preferences()
        self._record_activity("Favorite updated", code + (" added to favorites" if code in favorites else " removed from favorites"))
        self._filter_servers()

    def _reset_globe_view(self):
        self.globe_lon, self.globe_lat, self.globe_zoom = 0.0, 0.10, 1.0
        if self.prefs.get("globe_remember_view", True):
            self.prefs["_globe_lon"], self.prefs["_globe_lat"], self.prefs["_globe_zoom"] = self.globe_lon, self.globe_lat, self.globe_zoom
            self._save_preferences()
        self._schedule_globe_redraw(self.map_canvas, 0, quality="preview") if hasattr(self, "map_canvas") else None
        if hasattr(self, "map_canvas") and self.map_canvas.winfo_exists():
            self._schedule_globe_full_settle(self.map_canvas, 220)
        if hasattr(self, "geo_canvas") and self.geo_canvas.winfo_exists():
            self._schedule_globe_redraw(self.geo_canvas, 0, quality="preview")
            self._schedule_globe_full_settle(self.geo_canvas, 220)

    def _choose_server(self, idx, return_to_overview=True, focus_globe=False):
        if not 0 <= idx < len(SERVERS): return
        if self.connected and idx != self.selected and self.prefs.get("confirm_server_switch", True):
            if not messagebox.askyesno("Vibe VPN", "Switch location while the demo session is connected?", parent=self):
                return
        previous_code = SERVERS[self.selected]["code"] if 0 <= self.selected < len(SERVERS) else ""
        self.selected = idx
        selected = SERVERS[idx]
        if previous_code != selected["code"]:
            self._record_activity("Location selected", f"{selected['city']}, {selected['country']} ({selected['code']})")
        if focus_globe and self.prefs.get("globe_center_selected", True):
            self.globe_lon = math.radians(selected["lon"])
            self.globe_lat = max(-1.25, min(1.25, math.radians(selected["lat"])))
        if self.prefs.get("remember_last_server"):
            self.prefs["_last_server_index"] = idx
            if self.prefs.get("auto_save_settings", True): self._save_preferences()
        if self.prefs.get("save_server_history"):
            recent = list(self.prefs.get("_recent_servers", []))
            recent = [n for n in recent if n != idx]
            recent.insert(0, idx)
            self.prefs["_recent_servers"] = recent[:10]
        if self.prefs.get("globe_remember_view", True):
            self.prefs["_globe_lon"], self.prefs["_globe_lat"], self.prefs["_globe_zoom"] = self.globe_lon, self.globe_lat, self.globe_zoom
        if hasattr(self, "location_current_label") and self.location_current_label.winfo_exists():
            self.location_current_label.configure(text=f"Selected · {selected['city']}, {selected['country']}")
        if "locations" in self._built_pages:
            self._filter_servers()
            if hasattr(self, "geo_canvas") and self.geo_canvas.winfo_exists():
                self._schedule_globe_redraw(self.geo_canvas, 0, quality="preview")
                self._schedule_globe_full_settle(self.geo_canvas, 220)
        if self.page == "overview":
            self._sync_page("overview")
        elif return_to_overview:
            self._navigate("Overview")
        else:
            self._sync_page(self.page)
            if hasattr(self, "map_canvas") and self.map_canvas.winfo_exists(): self._draw_map()

    # ------------------------ Security / Settings --------------------------
    def _record_activity(self, action, details="", persist=True):
        """Record local UI actions only; no telemetry is sent anywhere."""
        if not getattr(self, "prefs", {}).get("local_activity_history", True):
            return
        entry = {
            "time": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),
            "action": str(action)[:100],
            "details": str(details)[:300],
        }
        self.activity_entries = (getattr(self, "activity_entries", []) + [entry])[-120:]
        self.prefs["_activity_log"] = self.activity_entries
        if persist and self.prefs.get("auto_save_settings", True):
            self._queue_preferences_save()
        if getattr(self, "page", None) == "activity":
            self._refresh_activity_view()

    def _render_activity(self):
        self._clear_content()
        self._section_heading(self.content, "Activity & recent actions",
                              "A local-only timeline of app actions. It is stored on this device and is never uploaded.")
        controls = self.panel(self.content, PANEL, BORDER)
        controls.pack(fill="x", pady=(0, 10))
        cp = tk.Frame(controls, bg=PANEL)
        cp.pack(fill="x", padx=12, pady=10)
        self.activity_search_var = tk.StringVar()
        search = ttk.Entry(cp, textvariable=self.activity_search_var)
        search.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self.activity_search_var.trace_add("write", lambda *_: self._refresh_activity_view())
        self.button(cp, "Export log", self._export_activity_log,
                    bg=PANEL2, fg=TEXT, hover=PANEL_HOVER, padx=9, pady=7).pack(side="left", padx=4)
        self.button(cp, "Clear history", self._clear_activity_log,
                    bg=PANEL2, fg=ORANGE, hover=PANEL_HOVER, padx=9, pady=7).pack(side="left", padx=4)
        self.activity_summary = self.label(self.content, "", 8, MUTED, bg=BG)
        self.activity_summary.pack(anchor="w", pady=(0, 6))
        shell = tk.Frame(self.content, bg=BG)
        shell.pack(fill="both", expand=True)
        self.activity_canvas = tk.Canvas(shell, bg=BG, highlightthickness=0, bd=0)
        scroll = ttk.Scrollbar(shell, orient="vertical", command=self.activity_canvas.yview)
        self.activity_canvas.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        self.activity_canvas.pack(side="left", fill="both", expand=True)
        self.activity_inner = tk.Frame(self.activity_canvas, bg=BG)
        self.activity_window = self.activity_canvas.create_window((0, 0), window=self.activity_inner, anchor="nw")
        self.activity_inner.bind("<Configure>", lambda e: self.activity_canvas.configure(scrollregion=self.activity_canvas.bbox("all")))
        self.activity_canvas.bind("<Configure>", lambda e: self.activity_canvas.itemconfigure(self.activity_window, width=e.width))
        self.activity_canvas.bind("<MouseWheel>", lambda e: self._scroll_canvas(e, self.activity_canvas))
        self.activity_inner.bind("<MouseWheel>", lambda e: self._scroll_canvas(e, self.activity_canvas))
        self._refresh_activity_view()

    def _scroll_canvas(self, event, canvas):
        try:
            delta = -1 if event.delta > 0 else 1
            if abs(event.delta) >= 120:
                delta = int(-event.delta / 120)
            canvas.yview_scroll(delta, "units")
        except tk.TclError:
            pass
        return "break"

    def _current_activity_signature(self):
        query = self.activity_search_var.get().strip().casefold() if hasattr(self, "activity_search_var") else ""
        last = self.activity_entries[-1] if self.activity_entries else {}
        return (query, len(self.activity_entries), last.get("time", ""), last.get("action", ""), last.get("details", ""))

    def _refresh_activity_view(self):
        if not hasattr(self, "activity_inner") or not self.activity_inner.winfo_exists():
            return
        if self._activity_render_job is not None:
            try: self.after_cancel(self._activity_render_job)
            except tk.TclError: pass
            self._activity_render_job = None
        for child in self.activity_inner.winfo_children():
            child.destroy()
        query = self.activity_search_var.get().strip().casefold() if hasattr(self, "activity_search_var") else ""
        entries = list(reversed(self.activity_entries[-100:]))
        if query:
            entries = [item for item in entries if query in (item.get("action", "") + " " + item.get("details", "")).casefold()]
        self.activity_summary.configure(text=f"{len(entries)} entries shown · local history · newest first")
        self._activity_view_signature = self._current_activity_signature()
        self._activity_render_queue = list(entries)
        if not entries:
            card = self.panel(self.activity_inner, PANEL, BORDER)
            card.pack(fill="x", pady=4)
            self.label(card, "No activity matches this filter", 10, MUTED, bg=PANEL).pack(anchor="w", padx=18, pady=22)
            return
        self._schedule_activity_render(initial_delay=1)

    def _schedule_activity_render(self, initial_delay=1):
        if self._closing or self.page != "activity" or not self._activity_render_queue:
            return
        if self._activity_render_job is not None:
            return
        try:
            self._activity_render_job = self.after(initial_delay, self._build_activity_rows_batch)
        except tk.TclError:
            self._activity_render_job = None

    def _build_activity_rows_batch(self):
        self._activity_render_job = None
        if self._closing or self.page != "activity":
            return
        batch = [self._activity_render_queue.pop(0) for _ in range(min(5, len(self._activity_render_queue)))]
        for item in batch:
            card = self.panel(self.activity_inner, PANEL, BORDER)
            card.pack(fill="x", pady=4)
            row = tk.Frame(card, bg=PANEL)
            row.pack(fill="x", padx=14, pady=10)
            tk.Frame(row, bg=BLUE, width=3, height=34).pack(side="left", fill="y", padx=(0, 11))
            txt = tk.Frame(row, bg=PANEL)
            txt.pack(side="left", fill="x", expand=True)
            self.label(txt, item.get("action", "Activity"), 9, TEXT, True, bg=PANEL).pack(anchor="w")
            self.label(txt, item.get("details", ""), 8, MUTED, bg=PANEL,
                       wraplength=760, justify="left").pack(anchor="w", pady=(3, 0))
            self.label(row, item.get("time", ""), 8, DIM, bg=PANEL).pack(side="right", padx=(12, 0))
        if self._activity_render_queue:
            self._schedule_activity_render(initial_delay=8)

    def _export_activity_log(self):
        filename = filedialog.asksaveasfilename(parent=self, title="Export Vibe VPN activity",
            defaultextension=".txt", filetypes=[("Text file", "*.txt"), ("JSON file", "*.json")],
            initialfile="vibe-activity.txt")
        if not filename: return
        try:
            if filename.lower().endswith(".json"):
                with open(filename, "w", encoding="utf-8") as handle:
                    json.dump(self.activity_entries, handle, ensure_ascii=False, indent=2)
            else:
                with open(filename, "w", encoding="utf-8") as handle:
                    for row in self.activity_entries:
                        handle.write(f"[{row.get('time','')}] {row.get('action','')}: {row.get('details','')}\n")
            self._toast("Activity log exported")
        except OSError as exc:
            messagebox.showerror("Vibe VPN", f"Could not export log: {exc}", parent=self)

    def _clear_activity_log(self):
        if not messagebox.askyesno("Clear activity", "Delete local activity history?", parent=self):
            return
        self.activity_entries = []
        self.prefs["_activity_log"] = []
        self._save_preferences()
        self._refresh_activity_view()
        self._toast("Local activity cleared")

    def _collect_diagnostics(self):
        bundle_root = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
        eula_path = bundle_root / "EULA.exe"
        config_ok = False
        try:
            APP_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            probe = APP_CONFIG_DIR / ".vibe_write_test"
            probe.write_text("ok", encoding="utf-8")
            probe.unlink(missing_ok=True)
            config_ok = True
        except OSError:
            config_ok = False
        try:
            from PIL import __version__ as pillow_version
        except Exception:
            pillow_version = "unavailable"
        cache_count = sum(len(items) for items in self._globe_bg_cache.values())
        return [
            ("Application", "Vibe VPN UI preview", "OK", GREEN),
            ("Python runtime", sys.version.split()[0], "OK", GREEN),
            ("Tk runtime", str(self.tk.call("info", "patchlevel")), "OK", GREEN),
            ("Globe renderer", f"Pillow {pillow_version}" if PIL_AVAILABLE else "Canvas fallback", "OK" if PIL_AVAILABLE else "FALLBACK", GREEN if PIL_AVAILABLE else ORANGE),
            ("Location catalogue", f"{len(SERVERS)} selectable city records", "CATALOGUE ONLY", ORANGE),
            ("EULA resource", str(eula_path), "FOUND" if eula_path.is_file() else "NOT FOUND", GREEN if eula_path.is_file() else RED),
            ("Local preferences", str(PREFERENCES_FILE), "WRITABLE" if config_ok else "NOT WRITABLE", GREEN if config_ok else RED),
            ("Active page", self.page, "ACTIVE", BLUE),
            ("Globe rendering", f"last {self._globe_last_draw_ms:.1f} ms · avg {self._globe_avg_draw_ms:.1f} ms · peak {self._globe_peak_draw_ms:.1f} ms", "MEASURED UI", GREEN if self._globe_avg_draw_ms < 35 else ORANGE),
            ("Globe frames", f"{self._globe_draw_count} rendered", f"background cache: {cache_count} entries", GREEN),
            ("VPN backend", "Not connected in this build", "UI ONLY", ORANGE),
        ]

    def _render_diagnostics(self):
        self._clear_content()
        self._section_heading(self.content, "Diagnostics & performance",
                              "Checks the local UI, resources, preferences and globe-render timings. It does not test VPN tunnel security.")
        controls = self.panel(self.content, PANEL, BORDER)
        controls.pack(fill="x", pady=(0, 10))
        bar = tk.Frame(controls, bg=PANEL)
        bar.pack(fill="x", padx=12, pady=10)
        self.button(bar, "Refresh checks", self._refresh_diagnostics_view,
                    bg=BLUE, fg="#111821", hover=BLUE_BRIGHT, padx=10, pady=7).pack(side="left", padx=(0, 6))
        self.button(bar, "Copy report", self._copy_diagnostic_report,
                    bg=PANEL2, fg=TEXT, hover=PANEL_HOVER, padx=10, pady=7).pack(side="left", padx=6)
        self.button(bar, "Clear render cache", self._clear_render_cache,
                    bg=PANEL2, fg=TEXT, hover=PANEL_HOVER, padx=10, pady=7).pack(side="left", padx=6)
        self.button(bar, "Open settings folder", self._open_preferences_folder,
                    bg=PANEL2, fg=TEXT, hover=PANEL_HOVER, padx=10, pady=7).pack(side="right", padx=6)
        self.diagnostics_summary = self.label(self.content, "", 8, MUTED, bg=BG)
        self.diagnostics_summary.pack(anchor="w", pady=(0, 7))
        self.diagnostics_list = tk.Frame(self.content, bg=BG)
        self.diagnostics_list.pack(fill="both", expand=True)
        self._refresh_diagnostics_view()

    def _refresh_diagnostics_view(self):
        if not hasattr(self, "diagnostics_list") or not self.diagnostics_list.winfo_exists():
            return
        if self._diagnostics_build_job is not None:
            try: self.after_cancel(self._diagnostics_build_job)
            except tk.TclError: pass
            self._diagnostics_build_job = None
        for child in self.diagnostics_list.winfo_children():
            child.destroy()
        checks = self._collect_diagnostics()
        self.diagnostics_summary.configure(text=f"{len(checks)} local checks · no VPN security claims · report generated {time.strftime('%H:%M:%S')}")
        self._diagnostics_queue = list(checks)
        self._schedule_diagnostics_build(initial_delay=1)

    def _schedule_diagnostics_build(self, initial_delay=1):
        if self._closing or self.page != "diagnostics" or not self._diagnostics_queue:
            return
        if self._diagnostics_build_job is not None:
            return
        try:
            self._diagnostics_build_job = self.after(initial_delay, self._build_diagnostics_batch)
        except tk.TclError:
            self._diagnostics_build_job = None

    def _build_diagnostics_batch(self):
        self._diagnostics_build_job = None
        if self._closing or self.page != "diagnostics":
            return
        batch = [self._diagnostics_queue.pop(0) for _ in range(min(3, len(self._diagnostics_queue)))]
        for title, value, status, color in batch:
            card = self.panel(self.diagnostics_list, PANEL, BORDER)
            card.pack(fill="x", pady=3)
            row = tk.Frame(card, bg=PANEL)
            row.pack(fill="x", padx=12, pady=8)
            text = tk.Frame(row, bg=PANEL)
            text.pack(side="left", fill="x", expand=True)
            self.label(text, title, 9, TEXT, True, bg=PANEL).pack(anchor="w")
            self.label(text, value, 8, MUTED, bg=PANEL,
                       wraplength=680, justify="left").pack(anchor="w", pady=(2, 0))
            self.label(row, status, 8, color, True, bg=PANEL).pack(side="right", padx=(10, 0))
        if self._diagnostics_queue:
            self._schedule_diagnostics_build(initial_delay=8)

    def _copy_diagnostic_report(self):
        lines = ["Vibe VPN local diagnostics", time.strftime("Generated: %Y-%m-%d %H:%M:%S"), ""]
        for title, value, status, _color in self._collect_diagnostics():
            lines.append(f"{title}: {value} [{status}]")
        report = "\n".join(lines)
        try:
            self.clipboard_clear(); self.clipboard_append(report)
            self._toast("Diagnostics report copied")
        except tk.TclError:
            messagebox.showerror("Vibe VPN", "Could not access the clipboard.", parent=self)

    def _clear_render_cache(self):
        self._globe_bg_cache.clear()
        self._projection_context_key = None
        self._globe_peak_draw_ms = 0.0
        if self.page == "overview" and hasattr(self, "map_canvas"):
            self._schedule_globe_redraw(self.map_canvas, 0, quality="full")
        elif self.page == "locations" and hasattr(self, "geo_canvas"):
            self._schedule_globe_redraw(self.geo_canvas, 0, quality="full")
        self._record_activity("Render cache cleared", "Cleared cached globe backgrounds.")
        self._toast("Render cache cleared")
        if self.page == "diagnostics":
            self._refresh_diagnostics_view()

    def _open_preferences_folder(self):
        try:
            APP_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            if hasattr(os, "startfile"):
                os.startfile(str(APP_CONFIG_DIR))
            else:
                webbrowser.open(APP_CONFIG_DIR.resolve().as_uri())
        except (OSError, tk.TclError) as exc:
            messagebox.showerror("Vibe VPN", f"Could not open preferences folder: {exc}", parent=self)

    def _render_security(self):
        self._clear_content()
        card = self.panel(self.content, PANEL)
        card.pack(fill="x", pady=(0, 12))
        pad = tk.Frame(card, bg=PANEL)
        pad.pack(fill="x", padx=22, pady=22)
        self.label(pad, "Privacy controls", 16, TEXT, True, bg=PANEL).pack(anchor="w")
        self.label(pad, "These protections need operating-system integration and a real VPN backend.",
                   9, MUTED, bg=PANEL).pack(anchor="w", pady=(6, 18))
        for name, desc in [
            ("Kill Switch", "Block internet traffic if the VPN tunnel drops."),
            ("DNS leak protection", "Route DNS requests through trusted VPN DNS."),
            ("Malware / tracker blocking", "Requires a trusted filtering list and network integration."),
        ]:
            row = tk.Frame(pad, bg=PANEL2)
            row.pack(fill="x", pady=5)
            txt = tk.Frame(row, bg=PANEL2)
            txt.pack(side="left", fill="x", expand=True, padx=14, pady=12)
            self.label(txt, name, 10, TEXT, True, bg=PANEL2).pack(anchor="w")
            self.label(txt, desc, 8, MUTED, bg=PANEL2).pack(anchor="w", pady=(4, 0))
            self.label(row, "NOT ACTIVE", 8, ORANGE, True, bg=PANEL2).pack(side="right", padx=14)
        self.label(self.content, "No protection is claimed by these visual controls.",
                   9, ORANGE, bg=BG).pack(anchor="w", pady=12)

    def _render_settings(self):
        old_job = getattr(self, "_settings_build_job", None)
        if old_job is not None:
            try: self.after_cancel(old_job)
            except tk.TclError: pass
        self._settings_build_job = None
        self._settings_build_queue = []
        self._clear_content()
        groups = self._preference_groups()
        total = sum(len(rows) for _, rows in groups)
        header = tk.Frame(self.content, bg=BG)
        header.pack(fill="x", pady=(0, 10))
        self.label(header, "Settings", 20, TEXT, True, bg=BG).pack(anchor="w")
        self.label(header, f"{total} options · common controls first; advanced network options are hidden until requested.",
                   9, MUTED, bg=BG).pack(anchor="w", pady=(4, 0))

        actionbar = self.panel(self.content, PANEL, BORDER)
        actionbar.pack(fill="x", pady=(0, 10))
        actions = tk.Frame(actionbar, bg=PANEL)
        actions.pack(fill="x", padx=12, pady=9)
        # Settings search is a live filter: it hides rows in-place without rebuilding the page.
        search_wrap = tk.Frame(actions, bg=PANEL2)
        search_wrap.pack(side="left", fill="x", expand=True, padx=(0, 10))
        self.label(search_wrap, "⌕", 14, MUTED, bg=PANEL2).pack(side="left", padx=(8, 5), pady=4)
        self.settings_search_var = tk.StringVar()
        self.settings_search_entry = ttk.Entry(search_wrap, textvariable=self.settings_search_var)
        self.settings_search_entry.pack(side="left", fill="x", expand=True, padx=(0, 8), pady=5)
        self.settings_search_entry.configure(width=24)
        self.settings_search_var.trace_add("write", lambda *_: self._schedule_settings_filter())

        self.show_advanced_var = tk.BooleanVar(value=bool(self.prefs.get("show_advanced_settings", False)))
        advanced_toggle = tk.Checkbutton(
            actions, text="Advanced", variable=self.show_advanced_var,
            command=lambda: self._preference_changed("show_advanced_settings", bool(self.show_advanced_var.get())),
            bg=PANEL, fg=TEXT, selectcolor=PANEL2, activebackground=PANEL,
            activeforeground=TEXT, font=("Segoe UI", 8, "bold"), cursor="hand2")
        advanced_toggle.pack(side="left", padx=(0, 8))

        self.button(actions, "Export", self._export_preferences,
                    bg=PANEL2, fg=TEXT, hover=PANEL_HOVER, padx=8, pady=6, font_size=8).pack(side="left", padx=3)
        self.button(actions, "Import", self._import_preferences,
                    bg=PANEL2, fg=TEXT, hover=PANEL_HOVER, padx=8, pady=6, font_size=8).pack(side="left", padx=3)
        self.button(actions, "Reset", self._reset_preferences,
                    bg=PANEL2, fg=ORANGE, hover=PANEL_HOVER, padx=8, pady=6, font_size=8).pack(side="left", padx=3)

        self._setting_status = self.label(self.content, "Preferences are stored locally on this device.",
                                          8, MUTED, bg=BG)
        self._setting_status.pack(anchor="w", pady=(0, 6))

        shell = tk.Frame(self.content, bg=BG)
        shell.pack(fill="both", expand=True)
        canvas = tk.Canvas(shell, bg=BG, highlightthickness=0, bd=0)
        scrollbar = ttk.Scrollbar(shell, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        inner = tk.Frame(canvas, bg=BG)
        window_id = canvas.create_window((0, 0), window=inner, anchor="nw")

        def on_inner_configure(_event=None):
            try:
                canvas.configure(scrollregion=canvas.bbox("all"))
            except tk.TclError:
                pass

        def on_canvas_configure(event):
            try:
                canvas.itemconfigure(window_id, width=event.width)
            except tk.TclError:
                pass

        def on_mousewheel(event):
            if event.delta:
                amount = int(-event.delta / 120) if abs(event.delta) >= 120 else (-1 if event.delta > 0 else 1)
                if self.prefs.get("scroll_sensitivity") == "High":
                    amount *= 2
                elif self.prefs.get("scroll_sensitivity") == "Low":
                    amount = -1 if amount < 0 else 1
                canvas.yview_scroll(amount, "units")
            return "break"

        inner.bind("<Configure>", on_inner_configure)
        canvas.bind("<Configure>", on_canvas_configure)
        canvas.bind("<MouseWheel>", on_mousewheel)
        inner.bind("<MouseWheel>", on_mousewheel)

        self._setting_vars = {}
        self._settings_sections = []
        self._settings_rows = []
        for group_title, rows in groups:
            card = self.panel(inner, PANEL, BORDER)
            body = tk.Frame(card, bg=PANEL)
            body.pack(fill="x", padx=15, pady=13)
            title = self.label(body, group_title, 11, TEXT, True, bg=PANEL)
            title.pack(anchor="w", pady=(0, 7))
            section = {"title": group_title, "card": card, "body": body, "rows": []}
            self._settings_sections.append(section)

        # Store the canvas for live filtering/scrollregion updates.
        self._settings_canvas = canvas
        self._settings_inner = inner
        self._settings_total_count = total
        self._settings_build_queue = [(section, entry) for section, rows in zip(self._settings_sections, [rows for _, rows in groups]) for entry in rows]
        self._settings_build_job = None
        self._settings_filter_job = None
        self._filter_settings_view()
        self._schedule_settings_build(initial_delay=10)

    def _schedule_settings_build(self, initial_delay=1):
        if self._closing or getattr(self, "page", None) != "settings":
            return
        if getattr(self, "_settings_build_job", None) is not None:
            return
        if not getattr(self, "_settings_build_queue", []):
            return
        try:
            self._settings_build_job = self.after(initial_delay, self._build_settings_rows_batch)
        except tk.TclError:
            self._settings_build_job = None

    def _build_settings_rows_batch(self):
        self._settings_build_job = None
        if self._closing or getattr(self, "page", None) != "settings":
            return
        queue = getattr(self, "_settings_build_queue", [])
        batch = [queue.pop(0) for _ in range(min(5, len(queue)))]
        created_sections = set()
        query = self.settings_search_var.get().strip().casefold() if hasattr(self, "settings_search_var") else ""
        show_advanced = bool(self.prefs.get("show_advanced_settings", False)) or bool(query)
        for section, entry in batch:
            key, label_text, description, kind, options, state_tag = entry
            row = tk.Frame(section["body"], bg=PANEL)
            row.pack(fill="x", pady=4)
            left = tk.Frame(row, bg=PANEL)
            left.pack(side="left", fill="x", expand=True, padx=(0, 12))
            self.label(left, label_text, 9, TEXT, True, bg=PANEL).pack(anchor="w")
            self.label(left, description, 8, MUTED, bg=PANEL,
                       wraplength=610, justify="left").pack(anchor="w", pady=(2, 0))
            state_color = GREEN if state_tag in ("UI", "Local", "Performance") else ORANGE
            self.label(row, state_tag.upper(), 7, state_color, True, bg=PANEL).pack(side="right", padx=(0, 8))
            control = tk.Frame(row, bg=PANEL)
            control.pack(side="right")
            if kind == "toggle":
                var = tk.BooleanVar(value=bool(self.prefs.get(key, False)))
                self._setting_vars[key] = var
                widget = tk.Checkbutton(
                    control, text="ON" if var.get() else "OFF", variable=var,
                    onvalue=True, offvalue=False, bg=PANEL, fg=BLUE_BRIGHT,
                    selectcolor=PANEL2, activebackground=PANEL, activeforeground=TEXT,
                    font=(self._font_family(), self._scaled_font_size(8), "bold"), cursor="hand2",
                    indicatoron=False, padx=9, pady=5, relief="flat", bd=0, width=5)
                widget.configure(command=lambda k=key, v=var, b=widget: self._toggle_preference(k, v, b))
                widget.pack()
            elif kind == "choice":
                var = tk.StringVar(value=str(self.prefs.get(key, PREFERENCE_DEFAULTS.get(key, ""))))
                self._setting_vars[key] = var
                widget = ttk.Combobox(control, textvariable=var, values=options,
                                      state="readonly", width=17)
                widget.bind("<<ComboboxSelected>>",
                            lambda event, k=key, v=var: self._preference_changed(k, v.get()))
                widget.pack()
            elif kind == "text":
                var = tk.StringVar(value=str(self.prefs.get(key, "")))
                self._setting_vars[key] = var
                widget = ttk.Entry(control, textvariable=var, width=18)
                widget.pack(side="left")
                self.button(control, "Save", lambda k=key, v=var: self._preference_changed(k, v.get().strip()),
                            bg=PANEL2, fg=TEXT, hover=PANEL_HOVER, padx=7, pady=5, font_size=8).pack(side="left", padx=(5,0))
            is_advanced = state_tag == "Backend"
            visible = (not query or query in f"{key} {label_text} {description} {state_tag}".casefold()) and (show_advanced or not is_advanced)
            if not visible:
                row.pack_forget()
            row_meta = {
                "widget": row, "section": section, "key": key,
                "text": f"{key.replace('_', ' ')} {key} {label_text} {description} {state_tag}".casefold(),
                "state_tag": state_tag, "visible": visible,
            }
            section["rows"].append(row_meta)
            self._settings_rows.append(row_meta)
            created_sections.add(section["title"])
        # Manage only touched sections; no global repack on each construction batch.
        for section in self._settings_sections:
            if section["title"] not in created_sections:
                continue
            has_visible = any(meta.get("visible", True) for meta in section["rows"])
            if has_visible:
                if not section["card"].winfo_manager():
                    section["card"].pack(fill="x", pady=(0, 9), padx=(0, 5))
            else:
                section["card"].pack_forget()
        visible_count = sum(1 for meta in self._settings_rows if meta.get("visible", True))
        total = getattr(self, "_settings_total_count", len(self._settings_rows))
        pending = len(queue)
        suffix = f" · preparing {total-pending}/{total}" if pending else " · saved locally"
        self._setting_status.configure(text=f"{visible_count} shown / {total} settings{suffix}",
                                        fg=GREEN if visible_count else BLUE)
        # Scroll bounds are updated once after a group of changes rather than for each row.
        try:
            self._settings_canvas.configure(scrollregion=self._settings_canvas.bbox("all"))
        except tk.TclError:
            pass
        if queue:
            self._schedule_settings_build(initial_delay=8)
        else:
            self._settings_status_complete = True
            self._setting_status.configure(text=f"All {self._settings_total_count} settings are ready · saved locally", fg=GREEN)

    def _schedule_settings_filter(self):
        if getattr(self, "_settings_filter_job", None) is not None:
            try: self.after_cancel(self._settings_filter_job)
            except tk.TclError: pass
        try:
            self._settings_filter_job = self.after(90, self._run_settings_filter)
        except tk.TclError:
            self._settings_filter_job = None

    def _run_settings_filter(self):
        self._settings_filter_job = None
        self._filter_settings_view()

    def _filter_settings_view(self):
        if not hasattr(self, "_settings_rows"):
            return
        query = ""
        try:
            query = self.settings_search_var.get().strip().casefold()
        except (AttributeError, tk.TclError):
            pass
        # A search exposes matching advanced options even when the Advanced checkbox is off.
        show_advanced = bool(self.prefs.get("show_advanced_settings", False)) or bool(query)
        visible_count = 0
        visible_sections = set()
        for meta in self._settings_rows:
            matches_query = not query or query in meta["text"]
            is_advanced = meta["state_tag"] == "Backend"
            visible = matches_query and (show_advanced or not is_advanced)
            meta["visible"] = visible
            row = meta["widget"]
            try:
                row.pack_forget()
                if visible:
                    row.pack(fill="x", pady=4)
                    visible_count += 1
                    visible_sections.add(id(meta["section"]))
            except tk.TclError:
                pass
        for section in self._settings_sections:
            card = section["card"]
            try:
                card.pack_forget()
                if id(section) in visible_sections:
                    card.pack(fill="x", pady=(0, 9), padx=(0, 5))
            except tk.TclError:
                pass
        if hasattr(self, "_setting_status") and self._setting_status.winfo_exists():
            total = getattr(self, "_settings_total_count", len(self._settings_rows))
            pending = len(getattr(self, "_settings_build_queue", []))
            suffix = f" · building {total-pending}/{total}" if pending else " · local preferences save automatically"
            self._setting_status.configure(
                text=f"{visible_count} shown / {total} settings{suffix}",
                fg=GREEN if visible_count else (BLUE if pending else ORANGE))
        try:
            if hasattr(self, "_settings_inner"):
                self._settings_inner.update_idletasks()
                self._settings_canvas.configure(scrollregion=self._settings_canvas.bbox("all"))
        except tk.TclError:
            pass

    # ------------------------ Profile / Appearance / Plans -----------------
    def _section_heading(self, parent, title, subtitle):
        heading = tk.Frame(parent, bg=parent.cget("bg"))
        heading.pack(fill="x", pady=(0, 14))
        accent = tk.Frame(heading, bg=CYAN, width=4, height=42)
        accent.pack(side="left", fill="y", padx=(0, 12))
        copy = tk.Frame(heading, bg=parent.cget("bg"))
        copy.pack(side="left", fill="x", expand=True)
        self.label(copy, title, 20, TEXT, True, bg=parent.cget("bg")).pack(anchor="w")
        self.label(copy, subtitle, 9, MUTED, bg=parent.cget("bg"),
                   wraplength=860, justify="left").pack(anchor="w", pady=(4, 0))

    def _field(self, parent, title, variable, show=None):
        wrap = tk.Frame(parent, bg=PANEL)
        wrap.pack(fill="x", pady=6)
        self.label(wrap, title, 9, MUTED, True, bg=PANEL).pack(anchor="w", pady=(0, 5))
        entry = ttk.Entry(wrap, textvariable=variable, show=show)
        entry.pack(fill="x", ipady=3)
        return entry

    def _render_profile(self):
        self._clear_content()
        self._section_heading(self.content, "Your profile", "Your Vibe identity, the little details, and your personal corner of the network.")
        card = self.panel(self.content, PANEL)
        card.pack(fill="x", pady=(0, 12))
        pad = tk.Frame(card, bg=PANEL)
        pad.pack(fill="x", padx=22, pady=22)
        hero = tk.Frame(pad, bg=PANEL)
        hero.pack(fill="x", pady=(0, 18))
        avatar = tk.Canvas(hero, width=76, height=76, bg=PANEL, highlightthickness=0)
        avatar.pack(side="left", padx=(0, 16))
        avatar.create_oval(4, 4, 72, 72, fill=BLUE_DARK, outline=self.profile_accent, width=2)
        avatar.create_text(38, 38, text=(self.profile_avatar or "V")[:2].upper(),
                           fill=BLUE_BRIGHT, font=("Segoe UI", 23, "bold"))
        info = tk.Frame(hero, bg=PANEL)
        info.pack(side="left", fill="x", expand=True, pady=9)
        self.profile_name_display = self.label(info, self.profile_name, 14, TEXT, True, bg=PANEL)
        self.profile_name_display.pack(anchor="w")
        self.profile_email_display = self.label(info, self.profile_email, 9, MUTED, bg=PANEL)
        self.profile_email_display.pack(anchor="w", pady=(4, 7))
        self.profile_plan_display = self.label(info, f"VIBE MEMBER  ·  {self.active_plan.upper()} PLAN",
                                               8, GREEN, True, bg=PANEL)
        self.profile_plan_display.pack(anchor="w")
        self.profile_avatar_canvas = avatar

        self.profile_name_var = tk.StringVar(value=self.profile_name)
        self.profile_email_var = tk.StringVar(value=self.profile_email)
        self.profile_avatar_var = tk.StringVar(value=self.profile_avatar)
        self._field(pad, "DISPLAY NAME", self.profile_name_var)
        self._field(pad, "EMAIL (DISPLAY ONLY)", self.profile_email_var)
        self._field(pad, "AVATAR INITIALS (1–2 CHARACTERS)", self.profile_avatar_var)
        row = tk.Frame(pad, bg=PANEL)
        row.pack(fill="x", pady=(12, 0))
        self.button(row, "Save profile", self._save_profile, bg=BLUE, fg="#101821",
                    hover=BLUE_BRIGHT, padx=18, pady=10).pack(side="left")
        self.profile_save_status = self.label(row, "Changes stay in this session in this UI preview.",
                                              8, MUTED, bg=PANEL)
        self.profile_save_status.pack(side="left", padx=12)

        account = self.panel(self.content, PANEL)
        account.pack(fill="x", pady=(2, 0))
        ap = tk.Frame(account, bg=PANEL)
        ap.pack(fill="x", padx=18, pady=16)
        self.label(ap, "Your Vibe account", 11, TEXT, True, bg=PANEL).pack(anchor="w")
        line = tk.Frame(ap, bg=BORDER, height=1)
        line.pack(fill="x", pady=12)
        self.profile_plan_value = None
        for label, value in [("Current plan", self.active_plan), ("Devices", "1 device · preview"),
                             ("Account security", "Not connected to an account service")]:
            r = tk.Frame(ap, bg=PANEL)
            r.pack(fill="x", pady=4)
            self.label(r, label, 9, MUTED, bg=PANEL).pack(side="left")
            value_label = self.label(r, value, 9, TEXT, True, bg=PANEL)
            value_label.pack(side="right")
            if label == "Current plan":
                self.profile_plan_value = value_label

    def _save_profile(self):
        self.profile_name = self.profile_name_var.get().strip() or "Vibe User"
        self.profile_email = self.profile_email_var.get().strip() or "No email added"
        self.profile_avatar = self.profile_avatar_var.get().strip()[:2] or "V"
        self.prefs["_profile_name"] = self.profile_name
        self.prefs["_profile_email"] = self.profile_email
        self.prefs["_profile_avatar"] = self.profile_avatar
        self._save_preferences()
        self._record_activity("Profile updated", f"Local profile name: {self.profile_name}")
        self.profile_save_status.configure(text="Profile saved on this device.", fg=GREEN)
        self._sync_page("profile")

    def _render_customize(self):
        self._clear_content()
        self._section_heading(self.content, "Vibe Studio",
                              "Choose a complete color world in one click, then personalize the app icon and motion.")
        theme_card = self.panel(self.content, PANEL, BORDER)
        theme_card.pack(fill="x", pady=(0, 12))
        tp = tk.Frame(theme_card, bg=PANEL)
        tp.pack(fill="x", padx=16, pady=14)
        self.label(tp, f"{len(THEME_PALETTES)} COMPLETE THEMES", 11, TEXT, True, bg=PANEL).pack(anchor="w")
        self.label(tp, "Each preset changes the whole palette — no need to pick every color manually.",
                   8, MUTED, bg=PANEL).pack(anchor="w", pady=(3, 10))
        self.theme_grid = tk.Frame(tp, bg=PANEL)
        self.theme_grid.pack(fill="x")
        for col in range(5): self.theme_grid.grid_columnconfigure(col, weight=1, uniform="theme")
        self.theme_gallery_cards = {}
        self._customize_theme_queue = list(THEME_PALETTES.items())

        icon_card = self.panel(self.content, PANEL, BORDER)
        icon_card.pack(fill="x", pady=(0, 12))
        ip = tk.Frame(icon_card, bg=PANEL)
        ip.pack(fill="x", padx=16, pady=14)
        self.label(ip, "CUSTOM APP ICON", 11, TEXT, True, bg=PANEL).pack(anchor="w")
        self.label(ip, "Seasonal and holographic window/taskbar icons. The packaged EXE file icon is chosen at build time.",
                   8, MUTED, bg=PANEL).pack(anchor="w", pady=(3, 9))
        self.icon_grid = tk.Frame(ip, bg=PANEL)
        self.icon_grid.pack(fill="x")
        for col in range(5): self.icon_grid.grid_columnconfigure(col, weight=1, uniform="iconstyle")
        self.icon_gallery_cards = {}
        self._customize_icon_queue = list(APP_ICON_STYLES.items())

        extras = self.panel(self.content, BG2, BORDER)
        extras.pack(fill="x")
        ep = tk.Frame(extras, bg=BG2)
        ep.pack(fill="x", padx=15, pady=12)
        self.label(ep, "Motion profile", 10, TEXT, True, bg=BG2).pack(side="left")
        motion = ttk.Combobox(ep, values=["Economy", "Balanced", "Smooth"], state="readonly", width=12)
        motion.set(self.prefs.get("animation_quality", "Balanced"))
        motion.pack(side="left", padx=10)
        motion.bind("<<ComboboxSelected>>", lambda e: self._preference_changed("animation_quality", motion.get()))
        self.button(ep, "Open all settings", lambda: self._navigate("Settings"),
                    bg=PANEL2, fg=TEXT, hover=PANEL_HOVER, padx=12, pady=8).pack(side="right")
        self._customize_build_job = None
        self._schedule_customize_build(initial_delay=1)

    def _schedule_customize_build(self, initial_delay=1):
        if self._closing or self.page != "customize":
            return
        if self._customize_build_job is not None:
            return
        if not self._customize_theme_queue and not self._customize_icon_queue:
            return
        try:
            self._customize_build_job = self.after(initial_delay, self._build_customize_batch)
        except tk.TclError:
            self._customize_build_job = None

    def _build_customize_batch(self):
        self._customize_build_job = None
        if self._closing or self.page != "customize":
            return
        # Four cards per batch keep theme/icon browsing responsive on slower PCs.
        if self._customize_theme_queue:
            for _ in range(min(4, len(self._customize_theme_queue))):
                theme_name, palette = self._customize_theme_queue.pop(0)
                idx = list(THEME_PALETTES).index(theme_name)
                row, col = divmod(idx, 5)
                chosen = theme_name == self.prefs.get("theme")
                card = tk.Frame(self.theme_grid, bg=PANEL2,
                                highlightthickness=2 if chosen else 1,
                                highlightbackground=BLUE if chosen else BORDER, cursor="hand2")
                card.grid(row=row, column=col, sticky="nsew", padx=4, pady=4)
                self.theme_gallery_cards[theme_name] = card
                preview = tk.Canvas(card, width=116, height=34, bg=PANEL2, highlightthickness=0, cursor="hand2")
                preview.pack(fill="x", padx=5, pady=(5, 2))
                preview.create_rectangle(2, 2, 114, 32, fill=palette["BG"], outline=palette["BORDER"])
                preview.create_rectangle(8, 8, 33, 26, fill=palette["PANEL"], outline="")
                preview.create_rectangle(37, 8, 82, 26, fill=palette["PANEL2"], outline="")
                preview.create_oval(91, 8, 109, 26, fill=palette["BLUE"], outline=palette["BLUE_BRIGHT"])
                name_label = tk.Label(card, text=("✓ " if chosen else "") + theme_name,
                                      bg=PANEL2, fg=TEXT if chosen else MUTED,
                                      font=(self._font_family(), self._scaled_font_size(8), "bold"),
                                      cursor="hand2", wraplength=130)
                name_label.pack(fill="x", padx=3, pady=(2, 7))
                for widget in (card, preview, name_label):
                    widget.bind("<Button-1>", lambda e, name=theme_name: self._choose_theme_preset(name))
        elif self._customize_icon_queue:
            for _ in range(min(5, len(self._customize_icon_queue))):
                idx = len(APP_ICON_STYLES) - len(self._customize_icon_queue)
                icon_name, meta = self._customize_icon_queue.pop(0)
                row, col = divmod(idx, 5)
                chosen = icon_name == self.prefs.get("app_icon")
                card = tk.Frame(self.icon_grid, bg=PANEL2, highlightthickness=2 if chosen else 1,
                                highlightbackground=BLUE if chosen else BORDER, cursor="hand2")
                card.grid(row=row, column=col, sticky="nsew", padx=4, pady=4)
                self.icon_gallery_cards[icon_name] = card
                sample = tk.Canvas(card, width=58, height=54, bg=PANEL2, highlightthickness=0, cursor="hand2")
                sample.pack(pady=(5, 1))
                self._draw_icon_preview(sample, icon_name)
                tk.Label(card, text=icon_name, bg=PANEL2, fg=TEXT if chosen else MUTED,
                         font=(self._font_family(), self._scaled_font_size(8), "bold"),
                         wraplength=100, cursor="hand2").pack(fill="x", padx=3, pady=(2, 7))
                for widget in card.winfo_children():
                    widget.bind("<Button-1>", lambda e, name=icon_name: self._choose_icon_preset(name))
                card.bind("<Button-1>", lambda e, name=icon_name: self._choose_icon_preset(name))
        self._schedule_customize_build(initial_delay=6)

    def _draw_icon_preview(self, canvas, icon_name):
        _, glyph, bg_color, accent = APP_ICON_STYLES[icon_name]
        canvas.delete("all")
        canvas.create_oval(5, 2, 53, 50, fill=bg_color, outline=accent, width=2)
        canvas.create_text(29, 26, text=glyph, fill=accent, font=("Segoe UI Symbol", 20, "bold"))
        if icon_name == "Holographic":
            canvas.create_arc(10, 8, 48, 44, start=210, extent=220, style="arc", outline="#ff9ad5", width=2)
        elif icon_name == "Halloween":
            canvas.create_oval(17, 20, 22, 25, fill="#ffb65c", outline="")
            canvas.create_oval(36, 20, 41, 25, fill="#ffb65c", outline="")
        elif icon_name == "Winter Glow":
            for dx, dy in ((0,-20),(0,20),(-20,0),(20,0)):
                canvas.create_line(29,26,29+dx,26+dy,fill="#dff8ff",width=1)

    def _choose_theme_preset(self, theme_name):
        if theme_name not in THEME_PALETTES: return
        self.prefs["theme"] = theme_name
        self.prefs["accent_color"] = THEME_DEFAULT_ACCENTS.get(theme_name, "Ice Blue")
        self._apply_visual_preferences(persist=True)
        self._record_activity("Theme changed", theme_name)
        for name, card in getattr(self, "theme_gallery_cards", {}).items():
            chosen = name == theme_name
            try:
                card.configure(highlightbackground=BLUE if chosen else BORDER,
                               highlightthickness=2 if chosen else 1)
                for child in card.winfo_children():
                    if isinstance(child, tk.Label):
                        child.configure(text=("✓ " if chosen else "") + name,
                                        fg=TEXT if chosen else MUTED)
            except tk.TclError: pass

    def _choose_icon_preset(self, icon_name):
        self._preference_changed("app_icon", icon_name)
        self._record_activity("Window icon changed", icon_name)
        for name, card in getattr(self, "icon_gallery_cards", {}).items():
            chosen = name == icon_name
            try: card.configure(highlightbackground=BLUE if chosen else BORDER,
                                highlightthickness=2 if chosen else 1)
            except tk.TclError: pass

    def _apply_appearance(self):
        self._apply_visual_preferences(persist=True)

    def _open_trial_bot(self):
        username = str(self.prefs.get("telegram_bot_username", "")).strip().lstrip("@").strip()
        if not username:
            username = simpledialog.askstring(
                "Vibe VPN · 3-day trial",
                "Enter your public Telegram bot username (without @):",
                parent=self)
            if not username:
                return
            username = username.strip().lstrip("@").strip()
            if not re.fullmatch(r"[A-Za-z0-9_]{5,32}", username):
                messagebox.showerror("Vibe VPN", "Telegram username should contain 5–32 letters, numbers or underscores.", parent=self)
                return
            self.prefs["telegram_bot_username"] = username
            if self.prefs.get("auto_save_settings", True):
                self._save_preferences()
        if not re.fullmatch(r"[A-Za-z0-9_]{5,32}", username):
            messagebox.showerror("Vibe VPN", "Telegram bot username should contain 5–32 letters, numbers or underscores.", parent=self)
            return
        opened = webbrowser.open("https://t.me/" + username)
        messagebox.showinfo("Vibe VPN · 3-day trial",
            f"Open @{username} in Telegram, press Start, then request the 3-day trial key.\n\n"
            "Key issuance and activation are not connected in this preview build; the bot and VPN backend must validate keys server-side.", parent=self)

    def _render_plans(self):
        self._clear_content()
        self._section_heading(
            self.content, "Plans & access",
            "Choose a tier or request a free 3-day trial key through your Telegram bot. Pricing and entitlements are preview-only until backend integration."
        )
        banner = self.panel(self.content, BG2)
        banner.pack(fill="x", pady=(0, 12))
        bp = tk.Frame(banner, bg=BG2)
        bp.pack(fill="x", padx=18, pady=13)
        self.label(bp, "Find your Vibe.", 15, TEXT, True, bg=BG2).pack(anchor="w")
        self.label(bp, "Start free, then upgrade whenever you need more speed, locations or devices.",
                   9, MUTED, bg=BG2).pack(anchor="w", pady=(4, 0))
        trial_row = tk.Frame(bp, bg=BG2)
        trial_row.pack(fill="x", pady=(12, 0))
        trial_text = tk.Frame(trial_row, bg=BG2)
        trial_text.pack(side="left", fill="x", expand=True)
        self.label(trial_text, "✦  3 DAYS FREE · VIA TELEGRAM", 10, GREEN, True, bg=BG2).pack(anchor="w")
        self.label(trial_text, "Open the Vibe bot → Start → Get trial key. The bot issues a temporary key; activation requires server-side verification.",
                   8, MUTED, bg=BG2, wraplength=640, justify="left").pack(anchor="w", pady=(4, 0))
        self.button(trial_row, "Get trial key  ↗", self._open_trial_bot, bg=GREEN, fg="#101821",
                    hover=BLUE_BRIGHT, padx=13, pady=9).pack(side="right", padx=(10, 0))

        plans = [
            {"name":"3-Day Telegram Trial", "price":"€0", "period":"3 days · one-time key", "tag":"FREE TRIAL", "color":GREEN,
             "features":["Request a key from the Telegram bot", "Open bot and press Start", "Temporary access for 72 hours", "Secure server-side key validation"]},
            {"name":"Free", "price":"€0", "period":"forever", "tag":"START HERE", "color":GREEN,
             "features":["Starter locations", "1 device", "Standard priority", "Basic connection stats"]},
            {"name":"Basic", "price":"€2.49", "period":"per month · example", "tag":"EVERYDAY", "color":BLUE,
             "features":["More server locations", "2 devices", "Ad-free app concept", "Standard support"]},
            {"name":"Plus", "price":"€4.99", "period":"per month · example", "tag":"MOST POPULAR", "color":BLUE_BRIGHT,
             "features":["All standard locations", "5 devices", "Priority server selection", "Advanced controls"]},
            {"name":"Pro", "price":"€7.99", "period":"per month · example", "tag":"POWER USER", "color":CYAN,
             "features":["Up to 10 devices", "Premium locations", "Multi-hop concept", "Priority support"]},
            {"name":"Ultimate", "price":"€11.99", "period":"per month · example", "tag":"MAXIMUM", "color":"#c5b5ff",
             "features":["Up to 20 devices", "All premium locations", "Dedicated IP concept", "Fastest support queue"]},
        ]
        grid = tk.Frame(self.content, bg=BG)
        grid.pack(fill="both", expand=True)
        for col in range(3):
            grid.grid_columnconfigure(col, weight=1, uniform="plan_cards")
        self.plan_buttons = {}
        self._plans_data = plans
        area = tk.Frame(self.content, bg=BG)
        area.pack(fill="both", expand=True)
        self.plans_loading_label = self.label(area, "Preparing plan cards…", 9, MUTED, bg=BG)
        self.plans_loading_label.pack(anchor="w", pady=(0, 8))
        self.plan_card_grid = tk.Frame(area, bg=BG)
        self.plan_card_grid.pack(fill="both", expand=True)
        for col in range(3):
            self.plan_card_grid.grid_columnconfigure(col, weight=1, uniform="plan_cards")
        self._plans_card_queue = list(enumerate(plans))
        self._plans_build_job = None
        self._schedule_plan_cards(initial_delay=1)
        note = self.panel(self.content, BG2)
        note.pack(fill="x", pady=(3, 0))
        self.label(note, "ⓘ  Preview only", 9, ORANGE, True, bg=BG2).pack(anchor="w", padx=12, pady=(8, 2))
        self.label(note, "Plan selection is local UI only. No payment is taken and paid features are not unlocked. Prices and limits are sample values.",
                   8, MUTED, bg=BG2, wraplength=900, justify="left").pack(anchor="w", padx=12, pady=(0, 8))

    def _schedule_plan_cards(self, initial_delay=1):
        if self._closing or self.page != "plans" or not self._plans_card_queue:
            return
        if self._plans_build_job is not None:
            return
        try:
            self._plans_build_job = self.after(initial_delay, self._build_plan_cards_batch)
        except tk.TclError:
            self._plans_build_job = None

    def _build_plan_cards_batch(self):
        self._plans_build_job = None
        if self._closing or self.page != "plans":
            return
        if not self._plans_card_queue:
            return
        # One card per callback avoids a half-second pause while constructing the plan grid.
        idx, plan = self._plans_card_queue.pop(0)
        row, col = divmod(idx, 3)
        active = self.active_plan == plan["name"]
        card = self.panel(self.plan_card_grid, PANEL,
                          plan["color"] if active or plan["name"] == "Plus" else BORDER)
        card.grid(row=row, column=col, sticky="nsew",
                  padx=(0 if col == 0 else 5, 0 if col == 2 else 5),
                  pady=(0, 8), ipadx=1, ipady=1)
        inner = tk.Frame(card, bg=PANEL)
        inner.pack(fill="both", expand=True, padx=13, pady=13)
        self.label(inner, "✦  " + plan["tag"], 8, plan["color"], True, bg=PANEL).pack(anchor="w")
        self.label(inner, plan["name"], 14, TEXT, True, bg=PANEL).pack(anchor="w", pady=(8, 0))
        self.label(inner, plan["price"], 23, TEXT, True, bg=PANEL).pack(anchor="w", pady=(3, 0))
        self.label(inner, plan["period"], 8, MUTED, bg=PANEL).pack(anchor="w", pady=(0, 7))
        tk.Frame(inner, bg=BORDER, height=1).pack(fill="x", pady=(2, 7))
        for feature in plan["features"]:
            self.label(inner, "✓  " + feature, 8, TEXT, bg=PANEL, anchor="w",
                       wraplength=230, justify="left").pack(anchor="w", pady=4)
        button_bg = plan["color"] if plan["name"] == "Plus" or active else PANEL2
        button_fg = "#111821" if button_bg != PANEL2 else TEXT
        plan_button = self.button(inner, "Current plan" if active else ("Choose " + plan["name"]),
                                  lambda n=plan["name"]: self._select_plan(n),
                                  bg=button_bg, fg=button_fg, hover=PANEL_HOVER,
                                  padx=8, pady=8, font_size=8)
        plan_button.pack(fill="x", pady=(9, 0))
        self.plan_buttons[plan["name"]] = plan_button
        if self.plans_loading_label.winfo_manager():
            self.plans_loading_label.pack_forget()
        if self._plans_card_queue:
            self._schedule_plan_cards(initial_delay=8)

    def _select_plan(self, plan):
        if plan == "3-Day Telegram Trial":
            self._open_trial_bot()
            return
        old_plan = self.active_plan
        self.active_plan = plan
        self.prefs["_active_plan"] = plan
        self._save_preferences()
        if old_plan != plan:
            self._record_activity("Plan preview changed", f"Selected {plan}; this does not process payment or activate backend features.")
        self._sync_page("plans")
        if "profile" in self._built_pages:
            self._sync_page("profile")

    # ------------------------ Animation loop -------------------------------
    def _animation_needed(self):
        if self._closing or self.prefs.get("reduced_motion", False) or self.prefs.get("cpu_saver", False):
            return False
        if not self.prefs.get("animations", True):
            return False
        if self.page == "overview":
            return True
        if self.page == "locations" and self.prefs.get("globe_auto_rotate", False) and not self._globe_drag_state:
            return True
        return False

    def _ensure_animation_loop(self):
        """Run the animation timer only while the visible page needs animation."""
        needed = self._animation_needed()
        if needed and self._animation_job is None and not self._closing:
            delay = 65 if self.prefs.get("animation_quality") == "Smooth" else 100
            try:
                self._animation_job = self.after(delay, self._animate)
            except tk.TclError:
                self._animation_job = None
        elif not needed and self._animation_job is not None:
            try: self.after_cancel(self._animation_job)
            except tk.TclError: pass
            self._animation_job = None

    def _animate(self):
        self._animation_job = None
        if self._closing:
            return
        if self._window_resize_active:
            # Do not compete with the WM's interactive resize loop for CPU time.
            try:
                self._animation_job = self.after(240, self._animate)
            except tk.TclError:
                self._animation_job = None
            return
        if self.page == "overview":
            self.animation_tick += 1
            self.pulse += 1
            self._draw_connect_button()
            if hasattr(self, "up_label") and self.up_label.winfo_exists():
                if self.prefs.get("show_speed_stats", True):
                    # Placeholder values are explicitly UI-demo metrics, not measured throughput.
                    v = 0.3 + (math.sin(self.animation_tick / 8) + 1) * 0.35 if self.connected else 0.0
                    new_up, new_down = f"{v:.1f} MB/s", f"{v*1.7:.1f} MB/s"
                else:
                    new_up = new_down = "Hidden"
                if self.up_label.cget("text") != new_up: self.up_label.configure(text=new_up)
                if self.down_label.cget("text") != new_down: self.down_label.configure(text=new_down)
        elif (self.page == "locations" and self.prefs.get("globe_auto_rotate", False)
              and not self._globe_drag_state and not self._window_resize_active):
            now = time.monotonic()
            elapsed = min(.18, max(0.0, now - getattr(self, "_last_auto_rotate_at", now)))
            self._last_auto_rotate_at = now
            deg_per_second = {"Slow": 4.0, "Normal": 9.0, "Fast": 18.0}.get(
                self.prefs.get("globe_auto_rotate_speed", "Slow"), 4.0)
            if elapsed:
                self.globe_lon = (self.globe_lon + math.radians(deg_per_second * elapsed)) % (2 * math.pi)
                if hasattr(self, "geo_canvas") and self.geo_canvas.winfo_exists():
                    self._schedule_globe_redraw(self.geo_canvas, 65, quality="preview")
        if self._animation_needed():
            quality_delay = {"Economy": 300, "Balanced": 160, "Smooth": 100}.get(
                self.prefs.get("animation_quality"), 160)
            if self.prefs.get("cpu_saver") or self.prefs.get("reduced_motion"):
                quality_delay = max(quality_delay, 300)
            try:
                self._animation_job = self.after(quality_delay, self._animate)
            except tk.TclError:
                self._animation_job = None


if __name__ == "__main__":
    app = HorizonVPN()
    app.mainloop()
